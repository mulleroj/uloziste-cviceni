import React, { useState, useEffect, useMemo } from 'react';
import { QRCodeSVG } from 'qrcode.react';
import { 
  BookOpen, 
  Edit3, 
  QrCode, 
  X, 
  CheckCircle, 
  AlertCircle, 
  RefreshCw, 
  ChevronRight, 
  Check, 
  AlertOctagon, 
  Share2, 
  Volume2, 
  Filter, 
  Search, 
  Copy, 
  Award, 
  ArrowRight,
  HelpCircle,
  RotateCcw,
  Sparkles,
  Zap,
  Layers,
  Compass,
  ArrowLeftRight,
  Lightbulb,
  WifiOff,
  AlertTriangle,
  Trash2,
  CheckCircle2,
  BookmarkX
} from 'lucide-react';
import { sentencesDB, theoryTraps, Sentence, TheoryTrap, SentenceToken } from './data/sentences';

export default function App() {
  const [activeTab, setActiveTab] = useState<'theory' | 'practice' | 'mistakes'>('theory');
  const [showQR, setShowQR] = useState(false);
  const [activeTheoryStep, setActiveTheoryStep] = useState(0);
  const [theorySearch, setTheorySearch] = useState('');
  const [copiedLink, setCopiedLink] = useState(false);

  // OSOBNÍ SEZNAM CHYB (ukládá se do localStorage pro 100% offline provoz)
  const [savedMistakes, setSavedMistakes] = useState<Sentence[]>(() => {
    try {
      const local = localStorage.getItem('gramaticke_pasti_mistakes');
      return local ? JSON.parse(local) : [];
    } catch (e) {
      return [];
    }
  });

  const addMistake = (sentence: Sentence) => {
    setSavedMistakes(prev => {
      if (prev.some(s => s.text === sentence.text)) return prev;
      const updated = [sentence, ...prev];
      try {
        localStorage.setItem('gramaticke_pasti_mistakes', JSON.stringify(updated));
      } catch (e) {
        console.warn('Failed to save to localStorage:', e);
      }
      return updated;
    });
  };

  const removeMistake = (sentenceText: string) => {
    setSavedMistakes(prev => {
      const updated = prev.filter(s => s.text !== sentenceText);
      try {
        localStorage.setItem('gramaticke_pasti_mistakes', JSON.stringify(updated));
      } catch (e) {
        console.warn('Failed to update localStorage:', e);
      }
      return updated;
    });
  };

  const clearAllMistakes = () => {
    setSavedMistakes([]);
    try {
      localStorage.removeItem('gramaticke_pasti_mistakes');
    } catch (e) {
      console.warn('Failed to clear localStorage:', e);
    }
  };

  const startPracticeMistakesOnly = () => {
    if (savedMistakes.length === 0) return;
    const shuffled = [...savedMistakes];
    for (let i = shuffled.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
    }
    setTestSentences(shuffled);
    setCurrentIndex(0);
    setScore(0);
    setIsFinished(false);
    setHasAnswered(false);
    setUserWasCorrect(null);
    setAnswersHistory([]);
    setSelectedCategory('mistakes_only');
    setActiveTab('practice');
  };

  // Interaktivní stav v teorii
  const [theoryViewMode, setTheoryViewMode] = useState<'trap' | 'fix'>('trap');
  const [selectedToken, setSelectedToken] = useState<SentenceToken | null>(null);
  const [isTrapFixedLive, setIsTrapFixedLive] = useState(false);
  const [quizAnswered, setQuizAnswered] = useState<number | null>(null);
  const [showDiagnosticTool, setShowDiagnosticTool] = useState(false);
  const [diagnosticStep, setDiagnosticStep] = useState(0);

  // --- STAV PROCVIČOVÁNÍ ---
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [testSentences, setTestSentences] = useState<Sentence[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [score, setScore] = useState(0);
  const [hasAnswered, setHasAnswered] = useState(false);
  const [isFinished, setIsFinished] = useState(false);
  const [userWasCorrect, setUserWasCorrect] = useState<boolean | null>(null);
  
  // Historie odpovědí pro závěrečný přehled
  const [answersHistory, setAnswersHistory] = useState<{
    sentence: Sentence;
    userChoiceCorrect: boolean;
    isUserRight: boolean;
  }[]>([]);

  // Text-to-speech výslovnost (lokální prohlížečové API)
  const [speakingText, setSpeakingText] = useState<string | null>(null);

  const speakSentence = (text: string) => {
    if ('speechSynthesis' in window) {
      try {
        window.speechSynthesis.cancel();
        const utterance = new SpeechSynthesisUtterance(text);
        utterance.lang = 'en-US';
        utterance.rate = 0.88;
        
        utterance.onstart = () => setSpeakingText(text);
        utterance.onend = () => setSpeakingText(null);
        utterance.onerror = () => setSpeakingText(null);

        window.speechSynthesis.speak(utterance);
      } catch (err) {
        console.warn('Speech synthesis unavailable or restricted:', err);
        setSpeakingText(null);
      }
    }
  };

  // Seznam unikátních kategorií pro filtr
  const categories = useMemo(() => {
    const set = new Set<string>();
    sentencesDB.forEach(s => {
      if (s.trap) set.add(s.trap);
    });
    return Array.from(set);
  }, []);

  // Funkce na výběr 15 vět (nebo podle kategorie)
  const startNewPractice = (categoryFilter: string = selectedCategory) => {
    if (categoryFilter === 'mistakes_only') {
      startPracticeMistakesOnly();
      return;
    }

    let pool = sentencesDB;
    if (categoryFilter !== 'all') {
      pool = sentencesDB.filter(s => s.trap === categoryFilter || s.isCorrect);
    }

    const shuffled = [...pool];
    for (let i = shuffled.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
    }

    const count = Math.min(15, shuffled.length);
    setTestSentences(shuffled.slice(0, count));
    setCurrentIndex(0);
    setScore(0);
    setIsFinished(false);
    setHasAnswered(false);
    setUserWasCorrect(null);
    setAnswersHistory([]);
  };

  useEffect(() => {
    startNewPractice('all');
  }, []);

  // Resetovat stav interaktivní teorie při změně kroku
  useEffect(() => {
    setTheoryViewMode('trap');
    setIsTrapFixedLive(false);
    setSelectedToken(null);
    setQuizAnswered(null);
  }, [activeTheoryStep]);

  const handleAnswer = (userSaysCorrect: boolean) => {
    if (hasAnswered) return;

    const currentSentence = testSentences[currentIndex];
    const isActuallyCorrect = currentSentence.isCorrect;
    const isUserRight = userSaysCorrect === isActuallyCorrect;

    setUserWasCorrect(isUserRight);
    if (isUserRight) {
      setScore(s => s + 1);
    } else {
      // Automatické uložení chyby do paměti uživatele
      addMistake(currentSentence);
    }

    setAnswersHistory(prev => [
      ...prev,
      {
        sentence: currentSentence,
        userChoiceCorrect: userSaysCorrect,
        isUserRight
      }
    ]);

    setHasAnswered(true);
  };

  const handleNext = () => {
    if (currentIndex < testSentences.length - 1) {
      setCurrentIndex(curr => curr + 1);
      setHasAnswered(false);
      setUserWasCorrect(null);
    } else {
      setIsFinished(true);
    }
  };

  const handleCategoryChange = (cat: string) => {
    setSelectedCategory(cat);
    startNewPractice(cat);
  };

  // Filtrovaná teorie podle vyhledávání
  const filteredTheoryTraps = useMemo(() => {
    if (!theorySearch.trim()) return theoryTraps;
    const q = theorySearch.toLowerCase();
    return theoryTraps.filter(
      t =>
        t.title.toLowerCase().includes(q) ||
        t.short.toLowerCase().includes(q) ||
        t.explanation.toLowerCase().includes(q) ||
        t.trap.toLowerCase().includes(q)
    );
  }, [theorySearch]);

  const copyAppUrl = () => {
    navigator.clipboard.writeText(window.location.href);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2000);
  };

  const currentTheory = theoryTraps[activeTheoryStep];

  // Pomocný styl pro tokeny v rozboru věty
  const getTokenStyle = (role: SentenceToken['role'], isFaulty?: boolean, isSelected?: boolean) => {
    let base = "px-3 py-2 rounded-xl border font-bold text-sm md:text-base cursor-pointer transition-all duration-200 transform hover:-translate-y-0.5 active:scale-95 flex items-center gap-1.5 ";
    
    if (isSelected) {
      base += "ring-2 ring-indigo-600 shadow-md scale-105 ";
    }

    if (isFaulty) {
      return base + "bg-rose-100 border-rose-400 text-rose-900 shadow-sm animate-pulse";
    }

    switch (role) {
      case 'subject':
        return base + "bg-blue-50 border-blue-300 text-blue-900";
      case 'verb':
        return base + "bg-indigo-50 border-indigo-300 text-indigo-900";
      case 'trap':
        return base + "bg-amber-50 border-amber-300 text-amber-900";
      case 'correct':
        return base + "bg-emerald-100 border-emerald-400 text-emerald-950 font-extrabold";
      case 'modifier':
        return base + "bg-purple-50 border-purple-300 text-purple-900";
      case 'time':
        return base + "bg-sky-50 border-sky-300 text-sky-900";
      case 'preposition':
        return base + "bg-orange-50 border-orange-300 text-orange-900";
      default:
        return base + "bg-slate-100 border-slate-200 text-slate-800";
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 font-sans flex flex-col">
      
      {/* HLAVIČKA */}
      <header className="bg-slate-900 text-white shadow-lg sticky top-0 z-30 border-b border-slate-800">
        <div className="max-w-6xl mx-auto px-4 py-3.5 flex items-center justify-between">
          <div className="flex items-center gap-3">
            {/* Geometrická ikona z Geometric Balance témata */}
            <div className="h-9 w-9 bg-blue-600 rounded-md rotate-45 flex items-center justify-center shadow-md flex-shrink-0">
              <AlertOctagon className="w-5 h-5 text-white -rotate-45" />
            </div>
            <div>
              <h1 className="text-lg md:text-xl font-black tracking-tight flex items-center gap-2">
                Gramatické Pasti
                <span className="text-[11px] bg-emerald-950/80 text-emerald-400 border border-emerald-800/80 px-2 py-0.5 rounded flex items-center gap-1 font-bold">
                  <WifiOff className="w-3 h-3 text-emerald-400" />
                  Offline
                </span>
              </h1>
              <p className="text-slate-400 text-xs font-medium hidden sm:block">
                Interaktivní trenažér a vizuální rozbor anglické gramatiky
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button 
              id="share-app-btn"
              onClick={() => setShowQR(true)}
              className="px-3 py-2 bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded-lg transition-all flex items-center gap-2 text-xs font-semibold active:scale-95 text-slate-200"
              title="Sdílet aplikaci"
            >
              <QrCode className="w-4 h-4 text-blue-400" />
              <span className="hidden sm:inline">Sdílet QR</span>
            </button>
          </div>
        </div>
        
        {/* NAVIGACE TABS */}
        <div className="max-w-6xl mx-auto px-4 flex border-t border-slate-800 overflow-x-auto">
          <button 
            id="tab-theory-btn"
            onClick={() => setActiveTab('theory')}
            className={`px-4 md:px-5 py-3 border-b-2 transition-all font-bold flex items-center gap-2 text-xs md:text-sm whitespace-nowrap ${
              activeTab === 'theory' 
                ? 'border-blue-500 text-white bg-slate-800/80' 
                : 'border-transparent text-slate-400 hover:text-white hover:bg-slate-800/40'
            }`}
          >
            <BookOpen className="w-4 h-4 text-blue-400" />
            Vizuální Teorie & Laboratoř
          </button>
          <button 
            id="tab-practice-btn"
            onClick={() => setActiveTab('practice')}
            className={`px-4 md:px-5 py-3 border-b-2 transition-all font-bold flex items-center gap-2 text-xs md:text-sm whitespace-nowrap ${
              activeTab === 'practice' 
                ? 'border-blue-500 text-white bg-slate-800/80' 
                : 'border-transparent text-slate-400 hover:text-white hover:bg-slate-800/40'
            }`}
          >
            <Edit3 className="w-4 h-4 text-emerald-400" />
            Interaktivní Test ({sentencesDB.length} vět)
          </button>
          <button 
            id="tab-mistakes-btn"
            onClick={() => setActiveTab('mistakes')}
            className={`px-4 md:px-5 py-3 border-b-2 transition-all font-bold flex items-center gap-2 text-xs md:text-sm whitespace-nowrap ${
              activeTab === 'mistakes' 
                ? 'border-amber-500 text-white bg-slate-800/80' 
                : 'border-transparent text-slate-400 hover:text-white hover:bg-slate-800/40'
            }`}
          >
            <AlertTriangle className="w-4 h-4 text-amber-400" />
            <span>Seznam mých chyb</span>
            {savedMistakes.length > 0 && (
              <span className="ml-0.5 bg-amber-500 text-slate-950 font-black text-[11px] px-2 py-0.5 rounded-full">
                {savedMistakes.length}
              </span>
            )}
          </button>
        </div>
      </header>

      {/* HLAVNÍ OBSAH */}
      <main className="max-w-6xl mx-auto px-4 py-8 flex-1 w-full">
        
        {/* === ZÁLOŽKA TEORIE & LABORATOŘ === */}
        {activeTab === 'theory' && (
          <div className="space-y-8 animate-fade-in">
            
            {/* HERO / RIŠTĚ INTERAKTIVITY */}
            <div className="bg-white p-6 md:p-8 rounded-2xl shadow-sm border border-slate-200">
              
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6 pb-6 border-b border-slate-100">
                <div>
                  <div className="inline-flex items-center gap-2 px-3 py-1 bg-blue-50 text-blue-700 rounded-md text-xs font-bold uppercase tracking-wider mb-2 border border-blue-100">
                    <Sparkles className="w-3.5 h-3.5 text-blue-600" />
                    Interaktivní Anatomie Vět
                  </div>
                  <h2 className="text-2xl md:text-3xl font-black text-slate-900 tracking-tight">
                    7 Klíčových Gramatických Pastí
                  </h2>
                  <p className="text-slate-600 text-sm md:text-base mt-1">
                    Klikni na jakékoli slovo ve větě pro okamžitý rozbor jeho syntaktické role a pravidla!
                  </p>
                </div>

                <button
                  onClick={() => setShowDiagnosticTool(!showDiagnosticTool)}
                  className="px-4 py-2.5 bg-slate-900 hover:bg-slate-800 text-white text-xs md:text-sm font-bold rounded-xl transition-all flex items-center justify-center gap-2 shadow-sm self-start md:self-auto"
                >
                  <Compass className="w-4 h-4 text-blue-400" />
                  <span>{showDiagnosticTool ? 'Skrýt Rozhodovací Strom' : '⚡ Rychlý Diagnostický Průvodce'}</span>
                </button>
              </div>

              {/* Bleskový diagnostický strom (pokud je zapnut) */}
              {showDiagnosticTool && (
                <div className="bg-slate-900 text-white p-6 rounded-2xl mb-8 animate-fade-in border border-slate-800 shadow-xl">
                  <div className="flex items-center justify-between mb-4 pb-3 border-b border-slate-800">
                    <div className="flex items-center gap-2">
                      <Zap className="w-5 h-5 text-amber-400" />
                      <h3 className="font-extrabold text-base md:text-lg">Krok za krokem: Jak otestovat jakoukoli větu</h3>
                    </div>
                    <span className="text-xs text-slate-400 font-mono">Krok {diagnosticStep + 1} ze 7</span>
                  </div>

                  <div className="space-y-4">
                    <div className="bg-slate-800/90 p-5 rounded-xl border border-slate-700">
                      <h4 className="text-blue-400 font-bold text-sm md:text-base mb-1">
                        Otázka #{diagnosticStep + 1}: {theoryTraps[diagnosticStep]?.title}
                      </h4>
                      <p className="text-slate-200 text-sm mb-3">
                        {theoryTraps[diagnosticStep]?.short}
                      </p>
                      <div className="bg-slate-950 p-3.5 rounded-lg border border-slate-800 font-mono text-xs text-amber-300">
                        Příklad pasti: "{theoryTraps[diagnosticStep]?.trap}"
                      </div>
                    </div>

                    <div className="flex flex-wrap items-center justify-between gap-3 pt-2">
                      <button
                        onClick={() => {
                          setActiveTheoryStep(diagnosticStep);
                          setShowDiagnosticTool(false);
                        }}
                        className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-lg text-xs font-bold transition-all"
                      >
                        Otevřít detailní rozbor k tomuto pravidlu →
                      </button>

                      <div className="flex gap-2">
                        <button
                          disabled={diagnosticStep === 0}
                          onClick={() => setDiagnosticStep(s => Math.max(0, s - 1))}
                          className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 disabled:opacity-40 text-xs font-semibold rounded-lg text-slate-300"
                        >
                          ← Předchozí
                        </button>
                        <button
                          disabled={diagnosticStep === theoryTraps.length - 1}
                          onClick={() => setDiagnosticStep(s => Math.min(theoryTraps.length - 1, s + 1))}
                          className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 disabled:opacity-40 text-xs font-semibold rounded-lg text-slate-300"
                        >
                          Další krok →
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* Vyhledávací lišta */}
              <div className="mb-6 max-w-lg relative">
                <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  placeholder="Hledat pravidlo (např. 'podmět', 'členy', 'did', 'good at')..."
                  value={theorySearch}
                  onChange={(e) => setTheorySearch(e.target.value)}
                  className="w-full pl-10 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs md:text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all"
                />
                {theorySearch && (
                  <button 
                    onClick={() => setTheorySearch('')}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
                  >
                    <X className="w-4 h-4" />
                  </button>
                )}
              </div>

              {filteredTheoryTraps.length === 0 ? (
                <div className="text-center py-12 bg-slate-50 rounded-xl border border-dashed border-slate-200">
                  <HelpCircle className="w-8 h-8 text-slate-400 mx-auto mb-2" />
                  <p className="font-semibold text-slate-600 text-sm">Nebylo nalezeno žádné pravidlo odpovídající hledání.</p>
                  <button 
                    onClick={() => setTheorySearch('')}
                    className="mt-2 text-xs text-blue-600 font-bold hover:underline"
                  >
                    Zobrazit všechna pravidla
                  </button>
                </div>
              ) : (
                <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
                  
                  {/* Seznam 7 kroků / pastí (Levá lišta - 4/12) */}
                  <div className="lg:col-span-4 space-y-2.5">
                    {filteredTheoryTraps.map((trap) => {
                      const realIndex = theoryTraps.findIndex(t => t.id === trap.id);
                      const isActive = activeTheoryStep === realIndex;
                      return (
                        <button 
                          key={trap.id}
                          id={`theory-step-${trap.id}`}
                          onClick={() => {
                            setActiveTheoryStep(realIndex);
                            setSelectedToken(null);
                          }}
                          className={`w-full text-left p-3.5 rounded-xl transition-all duration-200 flex items-start gap-3 border ${
                            isActive 
                              ? 'bg-slate-900 border-slate-900 text-white shadow-md' 
                              : 'bg-slate-50/80 border-slate-200/80 hover:bg-slate-100 hover:border-slate-300 text-slate-800'
                          }`}
                        >
                          <div className={`flex-shrink-0 w-7 h-7 rounded-md flex items-center justify-center font-black text-xs transition-colors ${
                            isActive ? 'bg-blue-600 text-white' : 'bg-slate-200 text-slate-600'
                          }`}>
                            {trap.id}
                          </div>
                          <div className="flex-1">
                            <h3 className={`font-bold text-xs md:text-sm ${isActive ? 'text-white' : 'text-slate-900'}`}>
                              {trap.title}
                            </h3>
                            <p className={`text-[11px] mt-0.5 line-clamp-1 ${isActive ? 'text-slate-300' : 'text-slate-500'}`}>
                              {trap.short}
                            </p>
                          </div>
                        </button>
                      );
                    })}
                  </div>

                  {/* Interaktivní Laboratoř Věty (Pravý panel - 8/12) */}
                  <div className="lg:col-span-8 flex flex-col">
                    {currentTheory && (
                      <div className="bg-slate-50 p-6 md:p-8 rounded-2xl border border-slate-200 shadow-inner flex-1 flex flex-col justify-between space-y-6">
                        
                        <div>
                          {/* Hlavička rozboru */}
                          <div className="flex flex-wrap items-center justify-between gap-3 pb-4 border-b border-slate-200">
                            <div className="flex items-center gap-2.5">
                              <span className="bg-blue-600 text-white px-2.5 py-1 rounded font-black text-sm shadow-sm">
                                Past #{currentTheory.id}
                              </span>
                              <h3 className="text-lg md:text-xl font-bold text-slate-900">
                                {currentTheory.title}
                              </h3>
                            </div>

                            {/* Přepínač Chybné Znění vs Opraveno Znění */}
                            <div className="flex items-center gap-1 bg-slate-200/80 p-1 rounded-xl text-xs font-bold">
                              <button
                                onClick={() => {
                                  setTheoryViewMode('trap');
                                  setIsTrapFixedLive(false);
                                  setSelectedToken(null);
                                }}
                                className={`px-3 py-1.5 rounded-lg transition-all ${
                                  theoryViewMode === 'trap' && !isTrapFixedLive
                                    ? 'bg-rose-600 text-white shadow-sm'
                                    : 'text-slate-700 hover:text-slate-900'
                                }`}
                              >
                                ❌ Chybné znění
                              </button>
                              <button
                                onClick={() => {
                                  setTheoryViewMode('fix');
                                  setIsTrapFixedLive(true);
                                  setSelectedToken(null);
                                }}
                                className={`px-3 py-1.5 rounded-lg transition-all ${
                                  theoryViewMode === 'fix' || isTrapFixedLive
                                    ? 'bg-emerald-600 text-white shadow-sm'
                                    : 'text-slate-700 hover:text-slate-900'
                                }`}
                              >
                                ✅ Správné znění
                              </button>
                            </div>
                          </div>

                          {/* INTERAKTIVNÍ VĚTNÁ ANATOMIE (TOKENY) */}
                          <div className="mt-6">
                            <div className="flex items-center justify-between mb-2">
                              <span className="text-xs font-extrabold text-slate-500 uppercase tracking-wider flex items-center gap-1">
                                <Layers className="w-3.5 h-3.5 text-blue-600" />
                                Klikni na jakékoli slovo ve větě:
                              </span>
                              
                              <button
                                onClick={() => {
                                  const textToRead = (theoryViewMode === 'trap' && !isTrapFixedLive) ? currentTheory.trap : currentTheory.fix;
                                  speakSentence(textToRead);
                                }}
                                className="text-xs text-blue-600 hover:text-blue-800 font-bold flex items-center gap-1 bg-white px-2.5 py-1 rounded-lg border border-slate-200 shadow-sm"
                              >
                                <Volume2 className={`w-3.5 h-3.5 ${speakingText ? 'text-blue-600 animate-pulse' : ''}`} />
                                <span>Poslechnout větu</span>
                              </button>
                            </div>

                            {/* Tokeny v kontejneru */}
                            <div className="bg-white p-5 md:p-6 rounded-2xl border border-slate-200 shadow-sm space-y-4">
                              <div className="flex flex-wrap items-center gap-2 min-h-[3.5rem]">
                                {((theoryViewMode === 'trap' && !isTrapFixedLive) ? currentTheory.tokensTrap : currentTheory.tokensFix)?.map((token, idx) => (
                                  <button
                                    key={idx}
                                    onClick={() => {
                                      setSelectedToken(token);
                                      speakSentence(token.text);
                                    }}
                                    className={getTokenStyle(token.role, token.isFaulty, selectedToken?.text === token.text)}
                                  >
                                    <span>{token.text}</span>
                                    {token.isFaulty && (
                                      <span className="text-[10px] bg-rose-600 text-white px-1.5 py-0.2 rounded font-extrabold uppercase">
                                        Chyba!
                                      </span>
                                    )}
                                  </button>
                                ))}
                              </div>

                              {/* Blesková Akce: Oprav chybu živě kliknutím */}
                              {theoryViewMode === 'trap' && !isTrapFixedLive && (
                                <div className="pt-3 border-t border-slate-100 flex items-center justify-between">
                                  <span className="text-xs text-slate-500 italic">
                                    💡 Tip: Můžeš kliknout na zvýrazněnou chybu pro její opravu živě!
                                  </span>
                                  <button
                                    onClick={() => {
                                      setIsTrapFixedLive(true);
                                      setTheoryViewMode('fix');
                                      speakSentence(currentTheory.fix);
                                    }}
                                    className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-extrabold flex items-center gap-1.5 transition-all shadow-sm active:scale-95"
                                  >
                                    <ArrowLeftRight className="w-3.5 h-3.5" />
                                    <span>Opravit chybu živě</span>
                                  </button>
                                </div>
                              )}
                            </div>

                            {/* DETAIL VYBRANÉHO TOKENU (INSPEKTOR) */}
                            {selectedToken ? (
                              <div className="mt-4 bg-slate-900 text-white p-4 md:p-5 rounded-xl border border-slate-800 animate-fade-in shadow-md">
                                <div className="flex items-center justify-between mb-2">
                                  <div className="flex items-center gap-2">
                                    <span className="text-xs font-mono uppercase bg-blue-600 text-white px-2 py-0.5 rounded font-bold">
                                      {selectedToken.label}
                                    </span>
                                    <span className="font-bold text-sm text-slate-200">
                                      "{selectedToken.text}"
                                    </span>
                                  </div>
                                  <button 
                                    onClick={() => setSelectedToken(null)}
                                    className="text-slate-400 hover:text-white"
                                  >
                                    <X className="w-4 h-4" />
                                  </button>
                                </div>
                                <p className="text-xs md:text-sm text-slate-300 leading-relaxed">
                                  {selectedToken.explanation}
                                </p>
                              </div>
                            ) : (
                              <div className="mt-3 text-center p-3 bg-blue-50/60 rounded-xl border border-blue-100 text-xs text-blue-900 font-medium">
                                👆 Klikni na libovolné slovo výše pro zobrazení jeho gramatické role.
                              </div>
                            )}

                          </div>

                          {/* SPECIÁLNÍ INTERAKTIVNÍ PRVKY PODLE TÉMATU */}
                          
                          {/* 1. Fonetická laboratoř pro A vs AN (Krok #4) */}
                          {currentTheory.id === 4 && currentTheory.phoneticNotes && (
                            <div className="mt-6 bg-white p-5 rounded-2xl border border-slate-200 space-y-3">
                              <h4 className="font-extrabold text-xs text-slate-500 uppercase tracking-wider flex items-center gap-1.5">
                                <Volume2 className="w-4 h-4 text-blue-600" />
                                Fonetická Zkoušečka: Výslovnost rozhoduje!
                              </h4>
                              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                                {currentTheory.phoneticNotes.map((note, idx) => (
                                  <button
                                    key={idx}
                                    onClick={() => speakSentence(note.word)}
                                    className="p-3 bg-slate-50 hover:bg-blue-50/70 border border-slate-200 rounded-xl text-left transition-all group flex items-start justify-between"
                                  >
                                    <div>
                                      <div className="flex items-center gap-2">
                                        <span className={`text-xs font-black px-1.5 py-0.5 rounded ${
                                          note.article === 'an' ? 'bg-amber-100 text-amber-900' : 'bg-blue-100 text-blue-900'
                                        }`}>
                                          {note.article.toUpperCase()}
                                        </span>
                                        <span className="font-bold text-slate-900 text-sm">{note.word}</span>
                                      </div>
                                      <div className="text-xs font-mono text-slate-500 mt-1">
                                        IPA: {note.ipa}
                                      </div>
                                      <div className="text-[11px] text-slate-600 mt-1 leading-tight">
                                        {note.explanation}
                                      </div>
                                    </div>
                                    <Volume2 className="w-4 h-4 text-slate-400 group-hover:text-blue-600 flex-shrink-0 mt-1" />
                                  </button>
                                ))}
                              </div>
                            </div>
                          )}

                          {/* 2. Předložková Matice pro Chybné Předložky (Krok #5) */}
                          {currentTheory.id === 5 && currentTheory.prepMatrix && (
                            <div className="mt-6 bg-white p-5 rounded-2xl border border-slate-200 space-y-3">
                              <h4 className="font-extrabold text-xs text-slate-500 uppercase tracking-wider flex items-center gap-1.5">
                                <ArrowLeftRight className="w-4 h-4 text-indigo-600" />
                                Porovnávač Předložkových Vazeb (Česky vs. Anglicky)
                              </h4>
                              <div className="overflow-x-auto">
                                <table className="w-full text-left text-xs">
                                  <thead>
                                    <tr className="border-b border-slate-200 text-slate-500 uppercase">
                                      <th className="py-2 px-3 font-extrabold">Výraz</th>
                                      <th className="py-2 px-3 font-extrabold text-rose-600">❌ Špatně (z Češtiny)</th>
                                      <th className="py-2 px-3 font-extrabold text-emerald-600">✅ Správně v AJ</th>
                                      <th className="py-2 px-3 font-extrabold text-slate-600">Český význam</th>
                                    </tr>
                                  </thead>
                                  <tbody className="divide-y divide-slate-100">
                                    {currentTheory.prepMatrix.map((row, idx) => (
                                      <tr key={idx} className="hover:bg-slate-50">
                                        <td className="py-2.5 px-3 font-bold text-slate-900">{row.verbOrAdj}</td>
                                        <td className="py-2.5 px-3 font-bold text-rose-700 bg-rose-50/50">{row.wrongPrep}</td>
                                        <td className="py-2.5 px-3 font-black text-emerald-700 bg-emerald-50/50">{row.correctPrep}</td>
                                        <td className="py-2.5 px-3 text-slate-600">{row.czMeaning}</td>
                                      </tr>
                                    ))}
                                  </tbody>
                                </table>
                              </div>
                            </div>
                          )}

                          {/* Tipy & Poučky */}
                          {currentTheory.detailTips && (
                            <div className="mt-6 bg-white p-4 rounded-xl border border-slate-200">
                              <h4 className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-2 flex items-center gap-1">
                                <Lightbulb className="w-3.5 h-3.5 text-amber-500" />
                                Pravidla k zapamatování:
                              </h4>
                              <ul className="space-y-1.5">
                                {currentTheory.detailTips.map((tip, idx) => (
                                  <li key={idx} className="text-xs text-slate-700 flex items-start gap-2">
                                    <span className="text-blue-600 font-bold">•</span>
                                    <span>{tip}</span>
                                  </li>
                                ))}
                              </ul>
                            </div>
                          )}

                          {/* INTERAKTIVNÍ MINIKVÍZ PŘÍMO V TEORII */}
                          {currentTheory.miniQuiz && (
                            <div className="mt-6 bg-blue-900 text-white p-5 rounded-2xl border border-blue-800 shadow-md">
                              <div className="flex items-center gap-2 mb-2 text-xs font-bold text-blue-300 uppercase tracking-wider">
                                <Sparkles className="w-4 h-4 text-amber-400" />
                                Rychlé cvičení pro ověření pochopení
                              </div>
                              <h4 className="font-bold text-sm md:text-base mb-4">
                                {currentTheory.miniQuiz.question}
                              </h4>

                              <div className="grid grid-cols-1 gap-2">
                                {currentTheory.miniQuiz.options.map((opt, optIdx) => {
                                  const isSelected = quizAnswered === optIdx;
                                  return (
                                    <button
                                      key={optIdx}
                                      onClick={() => setQuizAnswered(optIdx)}
                                      className={`p-3 rounded-xl text-left text-xs md:text-sm font-semibold transition-all border ${
                                        isSelected
                                          ? opt.isCorrect 
                                            ? 'bg-emerald-600 text-white border-emerald-500' 
                                            : 'bg-rose-600 text-white border-rose-500'
                                          : 'bg-blue-950/80 border-blue-800 hover:bg-blue-800 text-slate-100'
                                      }`}
                                    >
                                      <div className="flex items-center justify-between">
                                        <span>{opt.text}</span>
                                        {isSelected && (
                                          <span>{opt.isCorrect ? '✅ Správně' : '❌ Chyba'}</span>
                                        )}
                                      </div>
                                      {isSelected && (
                                        <p className="mt-2 text-xs opacity-90 font-normal pt-2 border-t border-white/20">
                                          {opt.explanation}
                                        </p>
                                      )}
                                    </button>
                                  );
                                })}
                              </div>
                            </div>
                          )}

                        </div>

                        {/* Tlačítka Navigace v teorii */}
                        <div className="pt-4 border-t border-slate-200 flex flex-wrap justify-between items-center gap-3">
                          <button
                            onClick={() => {
                              const prev = (activeTheoryStep - 1 + theoryTraps.length) % theoryTraps.length;
                              setActiveTheoryStep(prev);
                            }}
                            className="text-xs font-bold text-slate-600 hover:text-slate-900 px-3 py-2 rounded-lg bg-white border border-slate-200"
                          >
                            ← Předchozí rule
                          </button>
                          
                          <button
                            onClick={() => {
                              setSelectedCategory(currentTheory.title);
                              startNewPractice(currentTheory.title);
                              setActiveTab('practice');
                            }}
                            className="bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-black px-4 py-2.5 rounded-xl transition-all flex items-center gap-1.5 shadow-sm active:scale-95"
                          >
                            Spustit test na toto téma ({currentTheory.title})
                            <ArrowRight className="w-4 h-4" />
                          </button>

                          <button
                            onClick={() => {
                              const next = (activeTheoryStep + 1) % theoryTraps.length;
                              setActiveTheoryStep(next);
                            }}
                            className="text-xs font-bold text-slate-600 hover:text-slate-900 px-3 py-2 rounded-lg bg-white border border-slate-200"
                          >
                            Další rule →
                          </button>
                        </div>

                      </div>
                    )}
                  </div>

                </div>
              )}

            </div>
          </div>
        )}

        {/* === ZÁLOŽKA PROCVIČOVÁNÍ (TEST) === */}
        {activeTab === 'practice' && (
          <div className="animate-fade-in max-w-2xl mx-auto space-y-6">
            
            {/* Filtr kategorií */}
            <div className="bg-white p-4 rounded-xl shadow-sm border border-slate-200 flex flex-wrap items-center justify-between gap-3">
              <div className="flex items-center gap-2 text-sm font-bold text-slate-800">
                <Filter className="w-4 h-4 text-blue-600" />
                <span>Kategorie testu:</span>
              </div>
              <select
                id="category-select"
                value={selectedCategory}
                onChange={(e) => handleCategoryChange(e.target.value)}
                className="bg-slate-50 border border-slate-200 text-slate-900 text-xs md:text-sm rounded-lg font-bold p-2 focus:ring-2 focus:ring-blue-500 focus:outline-none"
              >
                <option value="all">Všechny gramatické pasti (Mix)</option>
                {savedMistakes.length > 0 && (
                  <option value="mistakes_only">
                    ⚡ Moje uložené chyby ({savedMistakes.length})
                  </option>
                )}
                {categories.map((cat, idx) => (
                  <option key={idx} value={cat}>
                    {cat}
                  </option>
                ))}
              </select>
            </div>

            {!isFinished ? (
              <div className="bg-white rounded-2xl shadow-lg border border-slate-200 overflow-hidden flex flex-col transition-all">
                
                {/* Progress bar */}
                <div className="bg-slate-100 h-2.5 w-full overflow-hidden">
                  <div 
                    className="bg-blue-600 h-full transition-all duration-300 ease-out"
                    style={{ width: `${((currentIndex + 1) / testSentences.length) * 100}%` }}
                  ></div>
                </div>

                <div className="p-6 md:p-8 flex-1">
                  <div className="flex justify-between items-center text-xs md:text-sm font-bold text-slate-500 mb-6">
                    <span className="bg-slate-100 px-3 py-1 rounded-md text-slate-800 font-mono">
                      Otázka {currentIndex + 1} z {testSentences.length}
                    </span>
                    <span className="text-blue-600">
                      Průběžné skóre: <strong className="text-base text-slate-900">{score}</strong> / {currentIndex + (hasAnswered ? 1 : 0)}
                    </span>
                  </div>

                  {/* Věta k posouzení */}
                  <div className="mb-8">
                    <div className="relative group bg-slate-50 p-6 md:p-8 rounded-2xl border-l-4 border-blue-600 shadow-inner flex flex-col justify-between">
                      <div className="flex justify-between items-start gap-2 mb-3">
                        <span className="text-xs font-black text-blue-600 uppercase tracking-wider">
                          Je tato věta gramaticky SPRÁVNĚ?
                        </span>
                        <button
                          onClick={() => speakSentence(testSentences[currentIndex]?.text || '')}
                          className="p-2 bg-white text-slate-600 hover:text-blue-600 rounded-lg border border-slate-200 shadow-sm transition-all active:scale-95 flex items-center gap-1 text-xs font-bold"
                          title="Přečíst nahlas v angličtině"
                        >
                          <Volume2 className={`w-4 h-4 ${speakingText === testSentences[currentIndex]?.text ? 'text-blue-600 animate-pulse' : ''}`} />
                          <span className="hidden sm:inline">Přečíst</span>
                        </button>
                      </div>

                      <h3 className="text-xl md:text-2xl font-bold text-slate-900 leading-snug my-2">
                        "{testSentences[currentIndex]?.text}"
                      </h3>
                    </div>
                  </div>

                  {/* Tlačítka SPRÁVNĚ / CHYBA */}
                  {!hasAnswered ? (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <button 
                        id="btn-sentence-correct"
                        onClick={() => handleAnswer(true)}
                        className="py-4 px-6 rounded-xl font-black text-emerald-900 bg-emerald-50 border-2 border-emerald-300 hover:bg-emerald-100 hover:border-emerald-400 active:scale-98 transition-all flex justify-center items-center gap-2.5 text-base shadow-sm"
                      >
                        <CheckCircle className="w-5 h-5 text-emerald-600" />
                        Věta je SPRÁVNĚ
                      </button>
                      <button 
                        id="btn-sentence-incorrect"
                        onClick={() => handleAnswer(false)}
                        className="py-4 px-6 rounded-xl font-black text-rose-900 bg-rose-50 border-2 border-rose-300 hover:bg-rose-100 hover:border-rose-400 active:scale-98 transition-all flex justify-center items-center gap-2.5 text-base shadow-sm"
                      >
                        <AlertCircle className="w-5 h-5 text-rose-600" />
                        Věta má CHYBU
                      </button>
                    </div>
                  ) : (
                    /* Zobrazení zpětné vazby po odpovědi */
                    <div className="animate-fade-in space-y-5">
                      
                      {/* Výsledek odpovědi */}
                      <div className={`p-4 rounded-xl flex items-center gap-3 border ${
                        userWasCorrect 
                          ? 'bg-emerald-50 border-emerald-300 text-emerald-950' 
                          : 'bg-rose-50 border-rose-300 text-rose-950'
                      }`}>
                        {userWasCorrect ? (
                          <>
                            <CheckCircle className="w-7 h-7 text-emerald-600 flex-shrink-0" />
                            <div>
                              <p className="font-black text-lg">Skvěle! Správná odpověď.</p>
                              <p className="text-xs text-emerald-800 font-medium">Připisuješ si 1 bod do skóre.</p>
                            </div>
                          </>
                        ) : (
                          <>
                            <AlertCircle className="w-7 h-7 text-rose-600 flex-shrink-0" />
                            <div>
                              <p className="font-black text-lg">Vedle! Byla to past.</p>
                              <p className="text-xs text-rose-800 font-medium">Podívej se níže na vysvětlení pravidla.</p>
                            </div>
                          </>
                        )}
                      </div>

                      {/* Detail pravidla / Oprava */}
                      <div className="bg-slate-50 border border-slate-200 rounded-xl p-5 space-y-3 text-sm">
                        {testSentences[currentIndex].isCorrect ? (
                          <div>
                            <span className="inline-block px-2.5 py-0.5 rounded-md bg-emerald-100 text-emerald-900 font-black text-xs uppercase mb-1">
                              Bezchybná věta
                            </span>
                            <p className="text-slate-800 font-medium leading-relaxed mt-1">
                              {testSentences[currentIndex].explanation}
                            </p>
                          </div>
                        ) : (
                          <div>
                            <div className="flex items-center gap-2 mb-2">
                              <span className="bg-amber-100 text-amber-900 text-xs px-2.5 py-0.5 rounded-md font-black uppercase">
                                Past: {testSentences[currentIndex].trap}
                              </span>
                            </div>

                            {testSentences[currentIndex].correction && (
                              <div className="bg-white p-3.5 rounded-lg border border-slate-200 my-2">
                                <span className="text-xs text-slate-500 font-bold block mb-1">Správné znění věty:</span>
                                <p className="text-emerald-900 font-bold text-base flex items-center justify-between">
                                  <span>"{testSentences[currentIndex].correction}"</span>
                                  <button
                                    onClick={() => speakSentence(testSentences[currentIndex].correction || '')}
                                    className="text-slate-400 hover:text-emerald-600 p-1 rounded"
                                  >
                                    <Volume2 className="w-4 h-4" />
                                  </button>
                                </p>
                              </div>
                            )}

                            <p className="text-slate-700 leading-relaxed mt-2 bg-blue-50/60 p-3 rounded-lg border border-blue-100">
                              <strong>Vysvětlení:</strong> {testSentences[currentIndex].explanation}
                            </p>
                          </div>
                        )}
                      </div>

                      {/* Tlačítko Další */}
                      <button 
                        id="btn-next-question"
                        onClick={handleNext}
                        className="w-full py-4 bg-slate-900 hover:bg-slate-800 text-white rounded-xl font-bold flex items-center justify-center gap-2 transition-all shadow-md active:scale-98"
                      >
                        {currentIndex < testSentences.length - 1 ? 'Další věta' : 'Zobrazit celkové výsledky'}
                        <ChevronRight className="w-5 h-5" />
                      </button>
                    </div>
                  )}

                </div>
              </div>
            ) : (
              /* ZÁVĚREČNÉ VÝSLEDKY TESTU */
              <div className="space-y-6">
                <div className="bg-white p-8 rounded-2xl shadow-lg border border-slate-200 text-center animate-fade-in">
                  <div className="w-20 h-20 bg-blue-100 text-blue-600 rounded-full flex items-center justify-center mx-auto mb-4 shadow-inner">
                    <Award className="w-10 h-10" />
                  </div>
                  <h2 className="text-3xl font-black text-slate-900">Test dokončen!</h2>
                  
                  <div className="py-6 border-y border-slate-100 my-6">
                    <p className="text-slate-500 font-semibold text-xs mb-1 uppercase tracking-wider">Výsledné skóre</p>
                    <div className="text-5xl font-black text-blue-600">
                      {score} <span className="text-2xl text-slate-400">/ {testSentences.length}</span>
                    </div>
                    <p className="mt-3 font-bold text-slate-800 text-base">
                      {score === testSentences.length ? '🥇 Absolutní mistr gramatiky! Nenecháš se ničím nachytat.' : 
                       score >= Math.ceil(testSentences.length * 0.8) ? '🌟 Výborná práce! Zvládáš gramatiku s přehledem.' :
                       score >= Math.ceil(testSentences.length * 0.5) ? '👍 Dobrá práce, ale pár pastí tě ještě překvapilo.' :
                       '💡 Nevadí, cvičení dělá mistra. Prostuduj si teorii a zkus to znovu!'}
                    </p>
                  </div>

                  <div className="flex flex-wrap gap-3 justify-center">
                    {savedMistakes.length > 0 && (
                      <button 
                        onClick={startPracticeMistakesOnly}
                        className="py-3 px-5 rounded-xl font-black text-slate-950 bg-amber-400 hover:bg-amber-300 transition-all flex items-center gap-2 text-sm shadow-md active:scale-95"
                      >
                        <Zap className="w-4 h-4 fill-slate-950" />
                        Procvičit pouze moje chyby ({savedMistakes.length})
                      </button>
                    )}
                    <button 
                      onClick={() => setActiveTab('theory')}
                      className="py-3 px-5 rounded-xl font-bold text-blue-900 bg-blue-50 hover:bg-blue-100 transition-colors flex items-center gap-2 text-sm"
                    >
                      <BookOpen className="w-4 h-4" />
                      Prostudovat teorii
                    </button>
                    <button 
                      onClick={() => startNewPractice()}
                      className="py-3 px-6 rounded-xl font-bold text-white bg-blue-600 hover:bg-blue-500 transition-all flex items-center gap-2 shadow-md text-sm active:scale-95"
                    >
                      <RefreshCw className="w-4 h-4" />
                      Generovat nový test (nové věty)
                    </button>
                  </div>
                </div>

                {/* HISTORIE ODPOVĚDÍ V TESTU */}
                <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200">
                  <h3 className="font-black text-slate-900 text-lg mb-4 flex items-center gap-2">
                    <RotateCcw className="w-5 h-5 text-blue-600" />
                    Přehled zodpovězených vět ({answersHistory.length})
                  </h3>

                  <div className="space-y-3">
                    {answersHistory.map((item, idx) => (
                      <div 
                        key={idx}
                        className={`p-4 rounded-xl border ${
                          item.isUserRight 
                            ? 'bg-emerald-50/50 border-emerald-200' 
                            : 'bg-rose-50/50 border-rose-200'
                        }`}
                      >
                        <div className="flex items-start justify-between gap-3">
                          <div className="flex items-start gap-2.5">
                            {item.isUserRight ? (
                              <CheckCircle className="w-5 h-5 text-emerald-600 flex-shrink-0 mt-0.5" />
                            ) : (
                              <AlertCircle className="w-5 h-5 text-rose-600 flex-shrink-0 mt-0.5" />
                            )}
                            <div>
                              <p className="font-bold text-slate-900 text-sm md:text-base">
                                "{item.sentence.text}"
                              </p>
                              {item.sentence.trap && (
                                <span className="inline-block text-xs font-semibold text-slate-500 mt-1">
                                  Kategorie: {item.sentence.trap}
                                </span>
                              )}
                              {!item.sentence.isCorrect && item.sentence.correction && (
                                <p className="text-xs text-emerald-800 font-bold mt-1">
                                  Správně: "{item.sentence.correction}"
                                </p>
                              )}
                              <p className="text-xs text-slate-600 mt-1 italic">
                                {item.sentence.explanation}
                              </p>
                            </div>
                          </div>

                          <div className="flex flex-col items-end gap-1.5 flex-shrink-0">
                            <span className={`text-xs font-bold px-2.5 py-1 rounded-md ${
                              item.isUserRight 
                                ? 'bg-emerald-100 text-emerald-900' 
                                : 'bg-rose-100 text-rose-900'
                            }`}>
                              {item.isUserRight ? 'Správně' : 'Chyba'}
                            </span>
                            {!item.isUserRight && (
                              <span className="text-[10px] text-amber-700 bg-amber-50 px-2 py-0.5 rounded border border-amber-200 font-medium">
                                Uloženo do Chyb
                              </span>
                            )}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

              </div>
            )}

          </div>
        )}

        {/* === ZÁLOŽKA SEZNAM CHYB === */}
        {activeTab === 'mistakes' && (
          <div className="space-y-6 animate-fade-in max-w-4xl mx-auto">
            
            <div className="bg-white p-6 md:p-8 rounded-2xl shadow-sm border border-slate-200">
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-6 border-b border-slate-100">
                <div>
                  <div className="inline-flex items-center gap-2 px-3 py-1 bg-amber-50 text-amber-800 rounded-md text-xs font-bold uppercase tracking-wider mb-2 border border-amber-200">
                    <AlertTriangle className="w-3.5 h-3.5 text-amber-600" />
                    Osobní Banka Chyb
                  </div>
                  <h2 className="text-2xl md:text-3xl font-black text-slate-900 tracking-tight flex items-center gap-3">
                    Seznam mých chyb
                    <span className="text-base bg-amber-100 text-amber-900 px-3 py-0.5 rounded-full font-bold">
                      {savedMistakes.length}
                    </span>
                  </h2>
                  <p className="text-slate-600 text-sm md:text-base mt-1">
                    Věty, ve kterých jsi při testování chyboval/a, se sem automaticky ukládají. Můžeš si je samostatně procvičit nebo označit jako naučené.
                  </p>
                </div>

                {savedMistakes.length > 0 && (
                  <div className="flex flex-wrap items-center gap-2 self-start md:self-auto">
                    <button
                      onClick={startPracticeMistakesOnly}
                      className="px-4 py-2.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs md:text-sm rounded-xl transition-all flex items-center gap-2 shadow-md active:scale-95"
                    >
                      <Zap className="w-4 h-4 fill-slate-950 text-slate-950" />
                      <span>Procvičit chyby ({savedMistakes.length})</span>
                    </button>
                    <button
                      onClick={clearAllMistakes}
                      className="px-3.5 py-2.5 bg-slate-100 hover:bg-rose-50 hover:text-rose-700 text-slate-600 font-bold text-xs md:text-sm rounded-xl transition-all border border-slate-200 flex items-center gap-1.5"
                      title="Vymazat všechny chyby"
                    >
                      <Trash2 className="w-4 h-4" />
                      <span className="hidden sm:inline">Vymazat vše</span>
                    </button>
                  </div>
                )}
              </div>

              {savedMistakes.length === 0 ? (
                <div className="text-center py-16 px-4">
                  <div className="w-16 h-16 bg-emerald-50 text-emerald-600 rounded-full flex items-center justify-center mx-auto mb-4 border border-emerald-100 shadow-sm">
                    <CheckCircle2 className="w-8 h-8" />
                  </div>
                  <h3 className="text-xl font-bold text-slate-900 mb-1">Žádné chyby v seznamu!</h3>
                  <p className="text-slate-500 text-sm max-w-md mx-auto mb-6">
                    Skvělá práce! Nemáš v seznamu žádné neprocvičené chyby. Jakmile při testu uděláš chybu, automaticky se sem uloží k opakování.
                  </p>
                  <button
                    onClick={() => {
                      startNewPractice('all');
                      setActiveTab('practice');
                    }}
                    className="px-6 py-3 bg-blue-600 hover:bg-blue-500 text-white rounded-xl font-bold text-sm transition-all shadow-md active:scale-95 inline-flex items-center gap-2"
                  >
                    <Edit3 className="w-4 h-4" />
                    <span>Spustit procvičovací test</span>
                  </button>
                </div>
              ) : (
                <div className="mt-6 space-y-4">
                  <div className="flex justify-between items-center text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">
                    <span>Uložené chyby k procvičení</span>
                    <span>Klikni na "Naučeno" pro vymazání ze seznamu</span>
                  </div>

                  <div className="grid grid-cols-1 gap-4">
                    {savedMistakes.map((mistake, idx) => (
                      <div
                        key={idx}
                        className="p-5 bg-slate-50 border border-slate-200 hover:border-slate-300 rounded-2xl transition-all shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4"
                      >
                        <div className="space-y-2 flex-1">
                          <div className="flex flex-wrap items-center gap-2">
                            {mistake.trap && (
                              <span className="bg-amber-100 text-amber-900 text-[11px] font-black uppercase px-2.5 py-0.5 rounded-md border border-amber-200">
                                Past: {mistake.trap}
                              </span>
                            )}
                            <span className={`text-[11px] font-bold px-2 py-0.5 rounded ${mistake.isCorrect ? 'bg-emerald-100 text-emerald-900' : 'bg-rose-100 text-rose-900'}`}>
                              {mistake.isCorrect ? 'Tato věta JE správně' : 'Chybná věta'}
                            </span>
                          </div>

                          <div className="flex items-start gap-2">
                            <h4 className="font-extrabold text-slate-900 text-base md:text-lg">
                              "{mistake.text}"
                            </h4>
                            <button
                              onClick={() => speakSentence(mistake.text)}
                              className="p-1 text-slate-400 hover:text-blue-600 rounded transition-colors flex-shrink-0"
                              title="Poslechnout výslovnost"
                            >
                              <Volume2 className="w-4 h-4" />
                            </button>
                          </div>

                          {mistake.correction && (
                            <div className="text-xs md:text-sm text-emerald-800 font-bold bg-emerald-50/80 p-2.5 rounded-lg border border-emerald-200 inline-block">
                              ✅ Správné znění: "{mistake.correction}"
                            </div>
                          )}

                          <p className="text-xs md:text-sm text-slate-600 leading-relaxed">
                            <strong>Vysvětlení:</strong> {mistake.explanation}
                          </p>
                        </div>

                        <div className="flex items-center gap-2 self-end md:self-center flex-shrink-0 pt-2 md:pt-0 border-t md:border-t-0 border-slate-200/60 w-full md:w-auto justify-end">
                          <button
                            onClick={() => removeMistake(mistake.text)}
                            className="px-3.5 py-2 bg-white hover:bg-emerald-50 text-slate-700 hover:text-emerald-700 border border-slate-200 hover:border-emerald-300 rounded-xl font-bold text-xs transition-all flex items-center gap-1.5 shadow-sm active:scale-95"
                            title="Označit jako naučené a vymazat ze seznamu"
                          >
                            <CheckCircle className="w-4 h-4 text-emerald-600" />
                            <span>Naučeno</span>
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>

          </div>
        )}

      </main>

      {/* MODAL SDRÍLENÍ A QR KÓDU */}
      {showQR && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/70 backdrop-blur-sm animate-fade-in">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-sm overflow-hidden flex flex-col relative border border-slate-100">
            <button 
              id="close-qr-modal-btn"
              onClick={() => setShowQR(false)}
              className="absolute top-4 right-4 p-2 bg-slate-100 hover:bg-slate-200 rounded-full transition-colors text-slate-500"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="p-6 text-center flex-1">
              <div className="w-12 h-12 bg-blue-100 text-blue-600 rounded-2xl flex items-center justify-center mx-auto mb-3 shadow-inner">
                <Share2 className="w-6 h-6" />
              </div>
              <h2 className="text-xl font-bold text-slate-900 mb-1">Sdílet aplikaci</h2>
              <p className="text-slate-500 text-xs mb-5">
                Naskenuj QR kód mobilním telefonem nebo zkopíruj odkaz
              </p>

              <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm inline-block mx-auto mb-4">
                <QRCodeSVG value={window.location.href} size={192} className="rounded-lg" />
              </div>

              <div className="mt-2">
                <button
                  onClick={copyAppUrl}
                  className="w-full py-2.5 px-4 bg-slate-100 hover:bg-slate-200 text-slate-800 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-2"
                >
                  {copiedLink ? (
                    <>
                      <Check className="w-4 h-4 text-emerald-600" />
                      <span>Odkaz zkopírován do schránky!</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-4 h-4" />
                      <span>Zkopírovat odkaz aplikace</span>
                    </>
                  )}
                </button>
              </div>
            </div>

            <div className="bg-slate-50 p-4 border-t border-slate-100">
              <button 
                onClick={() => setShowQR(false)}
                className="w-full py-2.5 bg-slate-200 hover:bg-slate-300 text-slate-800 rounded-xl font-bold text-sm transition-colors"
              >
                Zavřít
              </button>
            </div>
          </div>
        </div>
      )}

      {/* FOOTER */}
      <footer className="bg-slate-900 text-slate-400 py-6 text-center text-xs border-t border-slate-800">
        <div className="max-w-6xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="flex items-center gap-4 text-slate-500 font-mono">
            <span>80+ testovacích vět</span>
            <span>•</span>
            <span>7 hlavních chytáků</span>
          </div>
        </div>
      </footer>

      {/* Globální CSS animace */}
      <style dangerouslySetInnerHTML={{__html: `
        @keyframes fadeIn {
          from { opacity: 0; transform: translateY(6px); }
          to { opacity: 1; transform: translateY(0); }
        }
        .animate-fade-in {
          animation: fadeIn 0.25s ease-out forwards;
        }
      `}} />
    </div>
  );
}
