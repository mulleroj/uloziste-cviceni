export interface Sentence {
  id?: number;
  text: string;
  isCorrect: boolean;
  trap: string | null;
  correction: string | null;
  explanation: string;
  category?: string;
}

export interface SentenceToken {
  text: string;
  role: 'subject' | 'verb' | 'trap' | 'modifier' | 'time' | 'article' | 'preposition' | 'neutral' | 'correct';
  label: string;
  explanation: string;
  isFaulty?: boolean;
  replacement?: string;
}

export interface TheoryTrap {
  id: number;
  title: string;
  short: string;
  trap: string;
  fix: string;
  explanation: string;
  detailTips?: string[];
  // Interaktivní rozbor věty
  tokensTrap?: SentenceToken[];
  tokensFix?: SentenceToken[];
  phoneticNotes?: { word: string; ipa: string; soundType: 'vowel' | 'consonant'; article: 'a' | 'an'; explanation: string }[];
  prepMatrix?: { verbOrAdj: string; wrongPrep: string; correctPrep: string; czMeaning: string }[];
  miniQuiz?: {
    question: string;
    options: { text: string; isCorrect: boolean; explanation: string }[];
  };
}

// --- DATABÁZE VĚT (Celkem 80 vět pro generování do testu) ---
export const sentencesDB: Sentence[] = [
  // 1. Neshoda podmětu s přísudkem (10 vět)
  { text: "The quality of apples are good.", isCorrect: false, trap: "Neshoda podmětu s přísudkem", correction: "The quality of apples is good.", explanation: "Podmětem je 'quality' (j.č.), nikoli 'apples'." },
  { text: "A box of chocolates were on the table.", isCorrect: false, trap: "Neshoda podmětu s přísudkem", correction: "A box of chocolates was on the table.", explanation: "Podmětem je 'box' (j.č.), nikoli 'chocolates'." },
  { text: "Every one of the students have passed.", isCorrect: false, trap: "Neshoda podmětu s přísudkem", correction: "Every one of the students has passed.", explanation: "'Every one' je jednotné číslo, proto použijeme 'has'." },
  { text: "The list of items are on the desk.", isCorrect: false, trap: "Neshoda podmětu s přísudkem", correction: "The list of items is on the desk.", explanation: "Podmětem je 'list' (j.č.)." },
  { text: "Neither of the answers are correct.", isCorrect: false, trap: "Neshoda podmětu s přísudkem", correction: "Neither of the answers is correct.", explanation: "'Neither' se pojí se slovesem v jednotném čísle." },
  { text: "He go to school every day.", isCorrect: false, trap: "Neshoda podmětu s přísudkem", correction: "He goes to school every day.", explanation: "Ve třetí osobě jednotného čísla (he) přidáváme -es." },
  { text: "The group of tourists were tired.", isCorrect: false, trap: "Neshoda podmětu s přísudkem", correction: "The group of tourists was tired.", explanation: "Podmětem je 'group' (j.č.)." },
  { text: "My friend and his brother goes to the gym.", isCorrect: false, trap: "Neshoda podmětu s přísudkem", correction: "My friend and his brother go to the gym.", explanation: "Podmět je množný (friend AND brother), proto 'go'." },
  { text: "The news are very bad today.", isCorrect: false, trap: "Neshoda podmětu s přísudkem", correction: "The news is very bad today.", explanation: "Slovo 'news' (zprávy) je v angličtině nepočitatelné a pojí se s jednotným číslem." },
  { text: "One of my friends live in London.", isCorrect: false, trap: "Neshoda podmětu s přísudkem", correction: "One of my friends lives in London.", explanation: "Podmětem je 'One' (jeden z přátel), proto 'lives'." },

  // 2. Rozpor mezi časem a časovým výrazem (10 vět)
  { text: "She is playing yesterday.", isCorrect: false, trap: "Tense vs. Time Word", correction: "She was playing yesterday.", explanation: "Slovo 'yesterday' jasně ukazuje na minulost, nelze použít přítomný čas." },
  { text: "I go to the cinema last night.", isCorrect: false, trap: "Tense vs. Time Word", correction: "I went to the cinema last night.", explanation: "'Last night' vyžaduje minulý čas (went)." },
  { text: "We will visit them last month.", isCorrect: false, trap: "Tense vs. Time Word", correction: "We visited them last month.", explanation: "'Last month' vylučuje použití budoucího času (will visit)." },
  { text: "He has finished his work two hours ago.", isCorrect: false, trap: "Tense vs. Time Word", correction: "He finished his work two hours ago.", explanation: "Výraz 'ago' vyžaduje prostý minulý čas, nikoli předpřítomný." },
  { text: "I am living here since 2010.", isCorrect: false, trap: "Tense vs. Time Word", correction: "I have been living here since 2010.", explanation: "Pro děj začínající v minulosti a trvající doteď (since) se používá předpřítomný čas." },
  { text: "They just arrive.", isCorrect: false, trap: "Tense vs. Time Word", correction: "They have just arrived.", explanation: "Slovo 'just' se pojí s předpřítomným časem." },
  { text: "I see him tomorrow.", isCorrect: false, trap: "Tense vs. Time Word", correction: "I will see him tomorrow. (nebo: I am seeing him tomorrow.)", explanation: "'Tomorrow' odkazuje do budoucnosti." },
  { text: "Did you finished the report yet?", isCorrect: false, trap: "Tense vs. Time Word", correction: "Have you finished the report yet?", explanation: "'Yet' (už/ještě) se tradičně váže k předpřítomnému času." },
  { text: "She visits Paris in 1999.", isCorrect: false, trap: "Tense vs. Time Word", correction: "She visited Paris in 1999.", explanation: "Konkrétní letopočet v minulosti vyžaduje prostý minulý čas." },
  { text: "I already eat breakfast.", isCorrect: false, trap: "Tense vs. Time Word", correction: "I have already eaten breakfast.", explanation: "'Already' (už) se typicky používá s předpřítomným časem." },

  // 3. Nelogické použití pomocných sloves (10 vět)
  { text: "He did not went home.", isCorrect: false, trap: "Pomocná slovesa (Auxiliary Logic)", correction: "He did not go home.", explanation: "Po pomocném slovesu (did not) následuje sloveso v základním tvaru (infinitiv bez to)." },
  { text: "Did you saw the match?", isCorrect: false, trap: "Pomocná slovesa (Auxiliary Logic)", correction: "Did you see the match?", explanation: "Otázka v minulosti má 'Did', proto je hlavní sloveso v základním tvaru 'see'." },
  { text: "She doesn't wants to go.", isCorrect: false, trap: "Pomocná slovesa (Auxiliary Logic)", correction: "She doesn't want to go.", explanation: "Koncovku -s přebírá 'does', hlavní sloveso je v infinitivu 'want'." },
  { text: "Does he likes pizza?", isCorrect: false, trap: "Pomocná slovesa (Auxiliary Logic)", correction: "Does he like pizza?", explanation: "Pomocné sloveso 'does' už v sobě nese -s, hlavní sloveso je 'like'." },
  { text: "I didn't had time.", isCorrect: false, trap: "Pomocná slovesa (Auxiliary Logic)", correction: "I didn't have time.", explanation: "Zápor did not (didn't) vrací hlavní sloveso do základu (have)." },
  { text: "Will she comes tomorrow?", isCorrect: false, trap: "Pomocná slovesa (Auxiliary Logic)", correction: "Will she come tomorrow?", explanation: "Po modálních slovesech (will, can, must...) je vždy holý infinitiv bez -s." },
  { text: "He don't know the answer.", isCorrect: false, trap: "Pomocná slovesa (Auxiliary Logic)", correction: "He doesn't know the answer.", explanation: "Pro třetí osobu (he, she, it) se používá 'doesn't', nikoliv 'don't'." },
  { text: "Did they played well?", isCorrect: false, trap: "Pomocná slovesa (Auxiliary Logic)", correction: "Did they play well?", explanation: "'Did' už ukazuje na minulost, hlavní sloveso se nečasuje." },
  { text: "She cannot speaks French.", isCorrect: false, trap: "Pomocná slovesa (Auxiliary Logic)", correction: "She cannot speak French.", explanation: "Po modálním slovese (can) se nepřidává -s." },
  { text: "Did she found the keys?", isCorrect: false, trap: "Pomocná slovesa (Auxiliary Logic)", correction: "Did she find the keys?", explanation: "Po 'Did' musí následovat základní tvar slovesa (find)." },

  // 4. Záměna neurčitých členů (a / an) (10 vět)
  { text: "She is a honest girl.", isCorrect: false, trap: "Záměna členů (Article Confusion)", correction: "She is an honest girl.", explanation: "Slovo 'honest' sice začíná na h, ale to se nevyslovuje. Výslovnost začíná samohláskou, proto 'an'." },
  { text: "He is a honourable man.", isCorrect: false, trap: "Záměna členů (Article Confusion)", correction: "He is an honourable man.", explanation: "Opět němé 'h' na začátku. Výslovnost je /ɒnərəbl/, proto 'an'." },
  { text: "We waited for a hour.", isCorrect: false, trap: "Záměna členů (Article Confusion)", correction: "We waited for an hour.", explanation: "Slovo 'hour' se vyslovuje jako /aʊə/, začíná na samohlásku." },
  { text: "I go to an university.", isCorrect: false, trap: "Záměna členů (Article Confusion)", correction: "I go to a university.", explanation: "Slovo 'university' začíná psanou samohláskou, ale vyslovuje se na souhlásku /j/, proto 'a'." },
  { text: "It is an unique opportunity.", isCorrect: false, trap: "Záměna členů (Article Confusion)", correction: "It is a unique opportunity.", explanation: "'Unique' se vyslovuje s počátečním /j/, proto používáme 'a'." },
  { text: "He is a FBI agent.", isCorrect: false, trap: "Záměna členů (Article Confusion)", correction: "He is an FBI agent.", explanation: "Zkratka FBI se čte jako /ef/, začíná na samohlásku, proto 'an'." },
  { text: "It was an one-way street.", isCorrect: false, trap: "Záměna členů (Article Confusion)", correction: "It was a one-way street.", explanation: "'One' se vyslovuje jako /wʌn/ (začíná na w), proto 'a'." },
  { text: "I bought a umbrella.", isCorrect: false, trap: "Záměna členů (Article Confusion)", correction: "I bought an umbrella.", explanation: "'Umbrella' se vyslovuje se samohláskou na začátku, proto 'an'." },
  { text: "She is an European.", isCorrect: false, trap: "Záměna členů (Article Confusion)", correction: "She is a European.", explanation: "'European' se čte /jʊərəˈpiːən/ (začíná souhláskou j), proto 'a'." },
  { text: "I need a MP3 player.", isCorrect: false, trap: "Záměna členů (Article Confusion)", correction: "I need an MP3 player.", explanation: "Písmeno M se čte /em/, začíná samohláskou, proto 'an'." },

  // 5. Chybné předložky ze zvyku (10 vět)
  { text: "She is good in maths.", isCorrect: false, trap: "Chybné předložky (Prepositions)", correction: "She is good at maths.", explanation: "Správná vazba (být v něčem dobrý) je 'good AT something'." },
  { text: "He is married with a doctor.", isCorrect: false, trap: "Chybné předložky (Prepositions)", correction: "He is married to a doctor.", explanation: "Vazba (být s někým ženatý/vdaná) je 'married TO'." },
  { text: "I am interested on history.", isCorrect: false, trap: "Chybné předložky (Prepositions)", correction: "I am interested in history.", explanation: "Správná vazba je 'interested IN'." },
  { text: "We discussed about the problem.", isCorrect: false, trap: "Chybné předložky (Prepositions)", correction: "We discussed the problem.", explanation: "Sloveso 'discuss' se používá BEZ předložky." },
  { text: "He depends from his parents.", isCorrect: false, trap: "Chybné předložky (Prepositions)", correction: "He depends on his parents.", explanation: "Správná vazba (záviset na) je 'depend ON'." },
  { text: "I am listening music.", isCorrect: false, trap: "Chybné předložky (Prepositions)", correction: "I am listening to music.", explanation: "Správná vazba (poslouchat něco) je 'listen TO something'." },
  { text: "She goes at work early.", isCorrect: false, trap: "Chybné předložky (Prepositions)", correction: "She goes to work early.", explanation: "Směřování někam se vyjadřuje předložkou 'to'." },
  { text: "He is afraid from spiders.", isCorrect: false, trap: "Chybné předložky (Prepositions)", correction: "He is afraid of spiders.", explanation: "Správná vazba (bát se něčeho) je 'afraid OF'." },
  { text: "Look on this picture.", isCorrect: false, trap: "Chybné předložky (Prepositions)", correction: "Look at this picture.", explanation: "Správná vazba (podívat se na něco) je 'look AT'." },
  { text: "I translate it to English.", isCorrect: false, trap: "Chybné předložky (Prepositions)", correction: "I translate it into English.", explanation: "Správná vazba pro překlad je 'translate INTO'." },

  // 6. Špatně umístěný přívlastek (Dangling / Misplaced modifier) (10 vět)
  { text: "Running fast, the tree fell.", isCorrect: false, trap: "Špatně umístěný přívlastek (Modifier)", correction: "As I was running fast, the tree fell.", explanation: "Z první věty vyplývá, že běžel ten strom. Modifikátor (running fast) musí být spojen s podmětem (I)." },
  { text: "Covered in mud, I helped the dog.", isCorrect: false, trap: "Špatně umístěný přívlastek (Modifier)", correction: "I helped the dog that was covered in mud.", explanation: "Věta říká, že já jsem byl od bláta, ačkoli to byl pes." },
  { text: "He nearly drove the car for six hours.", isCorrect: false, trap: "Špatně umístěný přívlastek (Modifier)", correction: "He drove the car for nearly six hours.", explanation: "Slovo 'nearly' patří k času (skoro šest hodin), nikoli ke slovesu (skoro řídil)." },
  { text: "Barking loudly, the mailman ran away from the dog.", isCorrect: false, trap: "Špatně umístěný přívlastek (Modifier)", correction: "The mailman ran away from the loudly barking dog.", explanation: "Modifikátor 'barking loudly' je umístěn u pošťáka, takže to vypadá, že štěkal on." },
  { text: "She only has a brother.", isCorrect: false, trap: "Špatně umístěný přívlastek (Modifier)", correction: "She has only one brother.", explanation: "Slovo 'only' by mělo stát co nejblíže slovu, které upravuje (bratr, nikoliv 'má')." },
  { text: "Reading a book, my cat jumped on my lap.", isCorrect: false, trap: "Špatně umístěný přívlastek (Modifier)", correction: "While I was reading a book, my cat jumped on my lap.", explanation: "Kočka nečetla knihu, je nutné přidat podmět (While I was...)." },
  { text: "Exhausted, the bed looked very comfortable to John.", isCorrect: false, trap: "Špatně umístěný přívlastek (Modifier)", correction: "To exhausted John, the bed looked very comfortable.", explanation: "Postel nebyla vyčerpaná (exhausted), byl to John." },
  { text: "I found my keys walking down the street.", isCorrect: false, trap: "Špatně umístěný přívlastek (Modifier)", correction: "While walking down the street, I found my keys.", explanation: "Klíče nechodily po ulici." },
  { text: "We just bought a new car.", isCorrect: false, trap: "Špatně umístěný přívlastek (Modifier)", correction: "We bought just a new car. / We recently bought a new car.", explanation: "'Just' (jen) může nešikovným umístěním změnit význam." },
  { text: "He fed the cat wearing a suit.", isCorrect: false, trap: "Špatně umístěný přívlastek (Modifier)", correction: "Wearing a suit, he fed the cat.", explanation: "Původní věta naznačuje, že oblek měla na sobě kočka." },

  // 7. Dvojitý zápor a nadbytečnost (10 vět)
  { text: "He did not do nothing.", isCorrect: false, trap: "Dvojitý zápor (Double Negative)", correction: "He did not do anything.", explanation: "Angličtina nesnese dva zápory ve větě. Po did not musí následovat anything." },
  { text: "She hardly works never.", isCorrect: false, trap: "Dvojitý zápor (Double Negative)", correction: "She hardly ever works.", explanation: "'Hardly' (sotva) má samo o sobě záporný význam, nelze jej kombinovat s 'never'." },
  { text: "I don't need no help.", isCorrect: false, trap: "Dvojitý zápor (Double Negative)", correction: "I don't need any help. (nebo: I need no help.)", explanation: "Don't a no tvoří chybný dvojitý zápor." },
  { text: "We couldn't barely see.", isCorrect: false, trap: "Dvojitý zápor (Double Negative)", correction: "We could barely see.", explanation: "'Barely' se počítá jako zápor, takže musíme použít 'could', nikoli 'couldn't'." },
  { text: "There isn't nobody here.", isCorrect: false, trap: "Dvojitý zápor (Double Negative)", correction: "There isn't anybody here. (nebo: There is nobody here.)", explanation: "Jeden zápor na větu (buď isn't anybody nebo is nobody)." },
  { text: "He hasn't got no money.", isCorrect: false, trap: "Dvojitý zápor (Double Negative)", correction: "He hasn't got any money.", explanation: "Zápor je už v 'hasn't', dále použijeme 'any'." },
  { text: "I didn't see nowhere to hide.", isCorrect: false, trap: "Dvojitý zápor (Double Negative)", correction: "I didn't see anywhere to hide.", explanation: "Po záporném slovesu (didn't) následuje slovo s any (anywhere)." },
  { text: "She never said nothing to me.", isCorrect: false, trap: "Dvojitý zápor (Double Negative)", correction: "She never said anything to me.", explanation: "'Never' už je zápor." },
  { text: "I cannot find it nowhere.", isCorrect: false, trap: "Dvojitý zápor (Double Negative)", correction: "I cannot find it anywhere.", explanation: "'Cannot' je zápor, dále patří 'anywhere'." },
  { text: "They hadn't barely started.", isCorrect: false, trap: "Dvojitý zápor (Double Negative)", correction: "They had barely started.", explanation: "'Barely' vyjadřuje zápor, nepotřebuje 'hadn't'." },

  // Zcela správné věty (10 vět) - chytáky
  { text: "The quality of the apples is excellent.", isCorrect: true, trap: null, correction: null, explanation: "Podmět je 'quality', sloveso je 'is' - vše v pořádku!" },
  { text: "He went to the cinema yesterday.", isCorrect: true, trap: null, correction: null, explanation: "Minulý čas 'went' se správně váže k 'yesterday'." },
  { text: "She doesn't want to leave yet.", isCorrect: true, trap: null, correction: null, explanation: "Po pomocném 'doesn't' je sloveso správně v infinitivu 'want'." },
  { text: "It is an honor to meet you.", isCorrect: true, trap: null, correction: null, explanation: "'Honor' se sice píše s 'h', ale čte se od samohlásky. 'An honor' je správně." },
  { text: "I am really good at mathematics.", isCorrect: true, trap: null, correction: null, explanation: "Správná předložková vazba 'good at'." },
  { text: "Barking loudly, the dog chased the cat.", isCorrect: true, trap: null, correction: null, explanation: "Modifikátor 'Barking loudly' je správně umístěn těsně vedle podmětu 'the dog'." },
  { text: "I don't have anything to do.", isCorrect: true, trap: null, correction: null, explanation: "Správné použití jednoho záporu: don't ... anything." },
  { text: "The list of the guests is on the table.", isCorrect: true, trap: null, correction: null, explanation: "Podmět 'list' (j.č.) má správně přísudek 'is'." },
  { text: "Did you finish the project last night?", isCorrect: true, trap: null, correction: null, explanation: "Minulý čas. Pomocné sloveso Did a základní tvar finish. Správně!" },
  { text: "He is studying at a university in London.", isCorrect: true, trap: null, correction: null, explanation: "'University' se vyslovuje jako /ju:/, proto je člen 'a' správně." }
];

export const theoryTraps: TheoryTrap[] = [
  {
    id: 1,
    title: "Neshoda podmětu s přísudkem",
    short: "Ověř shodu podmětu s přísudkem.",
    trap: "The quality of apples are good.",
    fix: "The quality of apples IS good.",
    explanation: "Podmět často bývá oddělen předložkovou vazbou (of apples). Skutečným podmětem je zde 'quality', což je jednotné číslo.",
    detailTips: [
      "Vždy najdi hlavní podstatné jméno v podmětu před předložkou 'of'.",
      "Slova jako 'news', 'information', 'advice' jsou v AJ nepočitatelná (jednotné číslo).",
      "'Everyone', 'nobody', 'neither', 'each' vyžadují sloveso v jednotném čísle."
    ],
    tokensTrap: [
      { text: "The quality", role: "subject", label: "Skutečný podmět (Singular)", explanation: "'Quality' je podstatné jméno v jednotném čísle! Vždy určuje tvar slovesa." },
      { text: "of apples", role: "preposition", label: "Předložková vsuvka (Lákadlo)", explanation: "'of apples' je pouze rozvíjející vsuvka v množném čísle. Ignoruj ji při určování slovesa!" },
      { text: "are", role: "trap", label: "CHYBA ❌ (Plural Verb)", isFaulty: true, replacement: "is", explanation: "Chybný tvar 'are' vznikl zmatením ze slova 'apples'. Pro 'quality' vyžadujeme 'is'!" },
      { text: "good.", role: "neutral", label: "Přídavné jméno", explanation: "Přídavek vyjadřující vlastnost." }
    ],
    tokensFix: [
      { text: "The quality", role: "subject", label: "Skutečný podmět (j.č.)", explanation: "'Quality' (Sg)" },
      { text: "of apples", role: "preposition", label: "Předložková vsuvka", explanation: "Rozvíjející věta" },
      { text: "is", role: "correct", label: "SPRÁVNĚ ✅ (Singular Verb)", explanation: "Sloveso v jednotném čísle ladí s 'The quality'!" },
      { text: "good.", role: "neutral", label: "Doplněk", explanation: "Přídavné jméno" }
    ],
    miniQuiz: {
      question: "Které sloveso patří do věty: 'A box of heavy chocolates ___ on the table'?",
      options: [
        { text: "was", isCorrect: true, explanation: "Správně! Podmětem je 'A box' (jednotné číslo), nikoli 'chocolates'." },
        { text: "were", isCorrect: false, explanation: "Chyba! 'Were' je množné číslo, ale podmětem je krabice (A box)." }
      ]
    }
  },
  {
    id: 2,
    title: "Čas vs. Časový výraz",
    short: "Zkontrolujte návaznost času na časové výrazy (yesterday, since, atd.).",
    trap: "She is playing yesterday.",
    fix: "She WAS playing yesterday.",
    explanation: "Časové výrazy (yesterday, ago, next week) diktují gramatický čas. Sleduj je pozorně!",
    detailTips: [
      "Určitá minulost (yesterday, in 2010, 2 days ago, last week) = Past Simple / Past Continuous.",
      "Odkaz na děj trvající doteď od minulosti (since, for) = Present Perfect.",
      "Slovo 'yet' a 'already' v klasické AJ vyžadují předpřítomný čas (Present Perfect)."
    ],
    tokensTrap: [
      { text: "She", role: "subject", label: "Podmět", explanation: "Osoba provádějící děj." },
      { text: "is playing", role: "trap", label: "CHYBA ❌ (Přítomný čas)", isFaulty: true, replacement: "was playing", explanation: "Přítomný průběhový čas (is playing) koliduje s minulým časovým údajem 'yesterday'!" },
      { text: "yesterday.", role: "time", label: "Časový spínač (Minulost)", explanation: "'Yesterday' striktně přikazuje minulý čas!" }
    ],
    tokensFix: [
      { text: "She", role: "subject", label: "Podmět", explanation: "Osoba" },
      { text: "was playing", role: "correct", label: "SPRÁVNĚ ✅ (Minulý průběhový čas)", explanation: "'was playing' dokonale ladí s včerejškem." },
      { text: "yesterday.", role: "time", label: "Časové určení", explanation: "Včera" }
    ],
    miniQuiz: {
      question: "Jak doplňujeme sloveso k časovému výrazu 'two days ago'?",
      options: [
        { text: "I bought it two days ago.", isCorrect: true, explanation: "Správně! Výraz 'ago' vyžaduje Prostý Minulý Čas (bought)." },
        { text: "I have bought it two days ago.", isCorrect: false, explanation: "Chyba! Předpřítomný čas nelze kombinovat s konkrétním časem v minulosti jako 'ago'." }
      ]
    }
  },
  {
    id: 3,
    title: "Logika pomocných sloves",
    short: "Zkontroluj pomocná slovesa v otázce a záporu (did/does + infinitiv).",
    trap: "He did not went home.",
    fix: "He did not GO home.",
    explanation: "Po pomocném slovesu (did not) následuje sloveso v základním tvaru (infinitiv bez to).",
    detailTips: [
      "Minulost/osoba je vyjádřena v pomocném slovesu (did/does), hlavní sloveso má holý tvar (infinitiv).",
      "Pozor na chybné tvary jako 'Did you saw?' -> správně 'Did you see?'.",
      "Po modálních slovesech (can, must, should, will) se nepřidává přípona -s ani tvar minulého času."
    ],
    tokensTrap: [
      { text: "He", role: "subject", label: "Podmět", explanation: "Osoba" },
      { text: "did not", role: "verb", label: "Pomocné sloveso (Minulý zápor)", explanation: "'Did' už v sobě plně nese minulosný čas a zápor." },
      { text: "went", role: "trap", label: "CHYBA ❌ (Dvojité vyjádření minulosti)", isFaulty: true, replacement: "go", explanation: "'Went' je minulý tvar. Ale minulost už nese 'did'! Dvě minulosti vedle sebe jsou chyba." },
      { text: "home.", role: "neutral", label: "Příslovce místa", explanation: "Cíl cesty" }
    ],
    tokensFix: [
      { text: "He", role: "subject", label: "Podmět", explanation: "Osoba" },
      { text: "did not", role: "verb", label: "Pomocné sloveso", explanation: "Nese minulost" },
      { text: "go", role: "correct", label: "SPRÁVNĚ ✅ (Základní tvar / Infinitiv)", explanation: "Základní tvar slovesa bez minulostního ohýbání!" },
      { text: "home.", role: "neutral", label: "Doplnění", explanation: "Místo" }
    ],
    miniQuiz: {
      question: "Která otázka je gramaticky bezchybná?",
      options: [
        { text: "Did you see that movie?", isCorrect: true, explanation: "Správně! Po pomocném 'Did' následuje infinitiv 'see'." },
        { text: "Did you saw that movie?", isCorrect: false, explanation: "Chyba! Po 'Did' nemůže stát minulý tvar 'saw'." }
      ]
    }
  },
  {
    id: 4,
    title: "Záměna neurčitých členů",
    short: "Zkontroluj členy, obzvláště 'a' vs 'an' podle VÝSLOVNOSTI.",
    trap: "She is a honest girl.",
    fix: "She is AN honest girl.",
    explanation: "O použití 'a' nebo 'an' rozhoduje výslovnost. Hláska 'h' ve slově honest se nevyslovuje (začíná na O).",
    detailTips: [
      "Pravidlo závisí na ZVUKU, ne na písmeni na papíře!",
      "Němé H: an hour, an honest man, an honour.",
      "Souhláska /j/ na začátku: a university, a European, a unique idea."
    ],
    tokensTrap: [
      { text: "She is", role: "subject", label: "Podmět + sloveso", explanation: "Sloveso být" },
      { text: "a", role: "trap", label: "CHYBA ❌ (Špatný člen)", isFaulty: true, replacement: "an", explanation: "Slovo 'honest' sice začíná písmenem H, ale vyslovuje se /ɒnɪst/ (začíná samohláskou O!). Proto potřebujeme člen AN!" },
      { text: "honest", role: "modifier", label: "Slovo s němým H (/ɒnɪst/)", explanation: "H se nečte, první zvuk je samohláska O!" },
      { text: "girl.", role: "neutral", label: "Podstatné jméno", explanation: "Dívka" }
    ],
    tokensFix: [
      { text: "She is", role: "subject", label: "Podmět + sloveso", explanation: "Osoba" },
      { text: "an", role: "correct", label: "SPRÁVNĚ ✅ (Člen před samohláskovým zvukem)", explanation: "'An' usnadňuje plynulý přechod na zvuk O ve slově honest!" },
      { text: "honest", role: "modifier", label: "Výslovnost: /ɒn.ɪst/", explanation: "Němé H" },
      { text: "girl.", role: "neutral", label: "Jméno", explanation: "Dívka" }
    ],
    phoneticNotes: [
      { word: "honest", ipa: "/ˈɒn.ɪst/", soundType: "vowel", article: "an", explanation: "Němé 'H' – první slyšitelný tón je samohláska /ɒ/." },
      { word: "university", ipa: "/ˌjuː.nɪˈvɜː.sə.ti/", soundType: "consonant", article: "a", explanation: "Začíná na konsonantní zvuk /j/ (jako 'j' v 'jablko'). Proto používáme člen 'A'." },
      { word: "hour", ipa: "/ˈaʊ.ər/", soundType: "vowel", article: "an", explanation: "Němé 'H' – výslovnost začíná dvojhláskou /aʊ/." },
      { word: "European", ipa: "/ˌjʊə.rəˈpiː.ən/", soundType: "consonant", article: "a", explanation: "První zvuk je souhláska /j/, nikoli samohláska." },
      { word: "FBI agent", ipa: "/ˌef.biːˈaɪ/", soundType: "vowel", article: "an", explanation: "Písmeno F se čte jako /ef/ – začíná zvukem E!" }
    ],
    miniQuiz: {
      question: "Jaký člen použijeme před výrazem '___ unique style'?",
      options: [
        { text: "a unique style", isCorrect: true, explanation: "Správně! 'Unique' začíná zvukem /j/ (souhláska), takže patří člen 'a'!" },
        { text: "an unique style", isCorrect: false, explanation: "Chyba! Písmeno U sice vypadá jako samohláska, ale čte se /j/ – proto 'a'!" }
      ]
    }
  },
  {
    id: 5,
    title: "Chybné předložky ze zvyku",
    short: "Ověř předložky – pozor na předložky ze zvyku z češtiny.",
    trap: "She is good in maths.",
    fix: "She is good AT maths.",
    explanation: "Angličtina má specifické vazby předložek, které nelze doslovně překládat z češtiny.",
    detailTips: [
      "Good AT / Bad AT (dobrý/špatný v čem).",
      "Married TO (ženatý s / vdaná za).",
      "Listen TO (poslouchat co).",
      "Discuss something (BEZ 'about')."
    ],
    tokensTrap: [
      { text: "She is good", role: "subject", label: "Přídavné jméno schopnosti", explanation: "'Good' vyjadřuje dovednost." },
      { text: "in", role: "trap", label: "CHYBA ❌ (Český doslovný překlad 'v')", isFaulty: true, replacement: "at", explanation: "V češtině říkáme 'dobrý V matematice', ale v angličtině se po 'good' NIKDY nepoužívá 'in'!" },
      { text: "maths.", role: "neutral", label: "Předmět", explanation: "Matematika" }
    ],
    tokensFix: [
      { text: "She is good", role: "subject", label: "Schopnost", explanation: "Dobrý" },
      { text: "at", role: "correct", label: "SPRÁVNĚ ✅ (Ustálená vazba 'good AT')", explanation: "Anglická vazba pro dovednost je vždy 'AT'!" },
      { text: "maths.", role: "neutral", label: "Obor", explanation: "Matematika" }
    ],
    prepMatrix: [
      { verbOrAdj: "good / bad", wrongPrep: "in", correctPrep: "at", czMeaning: "dobrý / špatný v čem" },
      { verbOrAdj: "married / engaged", wrongPrep: "with", correctPrep: "to", czMeaning: "ženatý s / vdaná za" },
      { verbOrAdj: "interested", wrongPrep: "on / about", correctPrep: "in", czMeaning: "zajímající se o" },
      { verbOrAdj: "discuss", wrongPrep: "about", correctPrep: "(BEZ předložky)", czMeaning: "diskutovat o čem" },
      { verbOrAdj: "depend", wrongPrep: "from", correctPrep: "on", czMeaning: "záviset na čem" },
      { verbOrAdj: "listen", wrongPrep: "(chybějící)", correctPrep: "to", czMeaning: "poslouchat koho/co" }
    ],
    miniQuiz: {
      question: "Vyber správnou větu pro český výraz 'Diskutovali jsme o problému':",
      options: [
        { text: "We discussed the problem.", isCorrect: true, explanation: "Správně! Sloveso 'discuss' nepřibírá předložku 'about'!" },
        { text: "We discussed about the problem.", isCorrect: false, explanation: "Chyba! 'About' je po 'discuss' nadbytečné a chybné." }
      ]
    }
  },
  {
    id: 6,
    title: "Špatně umístěný přívlastek",
    short: "Modifikátor musí stát u slova, které upravuje.",
    trap: "Running fast, the tree fell.",
    fix: "As I was running fast, the tree fell.",
    explanation: "Rozvíjející člen musí stát přímo vedle slova, které popisuje. Jinak to vypadá, že běžel strom.",
    detailTips: [
      "Dávej pozor na přechodníky / přívlastky na začátku věty (Running..., Covered in...).",
      "Podmět v hlavní větě za čárkou musí být ten, kdo děj v přívlastku provádí.",
      "Přívlastky jako 'only', 'just', 'nearly' umisťuj těsně před slovo, které upřesňují."
    ],
    tokensTrap: [
      { text: "Running fast,", role: "modifier", label: "Přechodníková vsuvka (Děj)", explanation: "Kdo provádí tento děj? Musí to být podmět hned za čárkou!" },
      { text: "the tree", role: "trap", label: "CHYBA ❌ (Nelogický podmět)", isFaulty: true, replacement: "As I was running fast, the tree", explanation: "Podmětem je 'strom'! Věta tím pádem říká, že Rychle Běžel Strom!" },
      { text: "fell.", role: "verb", label: "Sloveso", explanation: "Spadl" }
    ],
    tokensFix: [
      { text: "As I was running fast,", role: "correct", label: "SPRÁVNĚ ✅ (Jasně určený konatel I)", explanation: "Přidali jsme podmět 'I', takže je jasné, kdo běžel." },
      { text: "the tree", role: "subject", label: "Podmět děje spadnutí", explanation: "Strom" },
      { text: "fell.", role: "verb", label: "Přísudek", explanation: "Spadl" }
    ],
    miniQuiz: {
      question: "Co je špatně na větě: 'Barking loudly, the mailman ran away'?",
      options: [
        { text: "Podmět 'mailman' stojí u štěkání, vyhlíží to jako že štěkal pošťák.", isCorrect: true, explanation: "Správně! Modifikátor 'Barking loudly' musí stát u psa, nikoli u pošťáka." },
        { text: "Sloveso 'ran away' je ve špatném čase.", isCorrect: false, explanation: "Chyba! Čas je v pořádku, problémem je umístění přívlastku." }
      ]
    }
  },
  {
    id: 7,
    title: "Dvojitý zápor",
    short: "Zkontroluj, zda ve větě není dvojitý zápor.",
    trap: "He did not do nothing.",
    fix: "He did not do ANYTHING.",
    explanation: "Angličtina nesnese dva zápory ve větě. Po did not musí následovat anything.",
    detailTips: [
      "V angličtině platí pravidlo 1 záporu na větu.",
      "Záporné sloveso + anything / anybody / anywhere.",
      "Slova 'hardly', 'barely', 'scarcely' jsou samy o sobě záporná."
    ],
    tokensTrap: [
      { text: "He", role: "subject", label: "Podmět", explanation: "Osoba" },
      { text: "did not do", role: "verb", label: "1. Zápor (Slovesný zápor)", explanation: "Záporné sloveso 'did not do'." },
      { text: "nothing.", role: "trap", label: "CHYBA ❌ (2. Zápor ve stejné větě)", isFaulty: true, replacement: "anything.", explanation: "Dvojitý zápor! V jedné anglické větě nemohou být dva zápory (did not + nothing)." }
    ],
    tokensFix: [
      { text: "He", role: "subject", label: "Podmět", explanation: "Osoba" },
      { text: "did not do", role: "verb", label: "Jediný zápor ve větě", explanation: "Slovesný zápor" },
      { text: "anything.", role: "correct", label: "SPRÁVNĚ ✅ (Kladné zájmeno)", explanation: "Zájmeno 'anything' po záporném slovesu dodržuje pravidlo jednoho záporu!" }
    ],
    miniQuiz: {
      question: "Který tvar je správný pro vyjádření 'Nic jsem neviděl'?",
      options: [
        { text: "I didn't see anything.", isCorrect: true, explanation: "Správně! Používáme jeden zápor 'didn't' a zájmeno 'anything'." },
        { text: "I didn't see nothing.", isCorrect: false, explanation: "Chyba! Dva zápory (didn't + nothing) jsou v angličtině gramatickým prohřeškem." }
      ]
    }
  }
];
