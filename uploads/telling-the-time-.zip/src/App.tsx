import React, { useState, useEffect, useCallback, useRef } from 'react';
import { Clock, BookOpen, GraduationCap, CheckCircle2, XCircle, RotateCcw, ChevronRight, Info, BarChart, Keyboard, Share2, X } from 'lucide-react';
import { QRCodeCanvas } from 'qrcode.react';

const App = () => {
  const [activeTab, setActiveTab] = useState('learn'); // 'learn' nebo 'test'
  const [difficulty, setDifficulty] = useState<string | null>(null); // null, 'easy', 'medium', 'hard'
  const [score, setScore] = useState(0);
  const [questionIndex, setQuestionIndex] = useState(0);
  const [testFinished, setTestFinished] = useState(false);
  const [feedback, setFeedback] = useState<{ type: 'correct' | 'error'; msg: string } | null>(null);
  const [selectedTime, setSelectedTime] = useState({ h: 10, m: 15 });
  const [currentTestQuestions, setCurrentTestQuestions] = useState<any[]>([]);
  const [userInput, setUserInput] = useState("");
  const [showShare, setShowShare] = useState(false);
  const [timeLeft, setTimeLeft] = useState(15);
  const [currentTimeLimit, setCurrentTimeLimit] = useState(15);
  const inputRef = useRef<HTMLInputElement>(null);

  const getLimitByDifficulty = (diff: string) => {
    if (diff === 'easy') return 20;
    if (diff === 'medium') return 15;
    if (diff === 'hard') return 25;
    return 15;
  };

  // Pomocné funkce pro názvy čísel a formátování času
  const getNumberName = (n: number) => {
    const names = [
      "zero", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine", "ten",
      "eleven", "twelve", "thirteen", "fourteen", "fifteen", "sixteen", "seventeen", "eighteen", "nineteen", "twenty",
      "twenty-one", "twenty-two", "twenty-three", "twenty-four", "twenty-five", "twenty-six", "twenty-seven", "twenty-eight", "twenty-nine", "thirty"
    ];
    return names[n] || n.toString();
  };

  const getEnglishTimeText = (h: number, m: number) => {
    if (m === 0) return `It's ${getNumberName(h)} o'clock`;
    if (m === 15) return `It's quarter past ${getNumberName(h)}`;
    if (m === 30) return `It's half past ${getNumberName(h)}`;
    if (m === 45) return `It's quarter to ${getNumberName(h === 12 ? 1 : h + 1)}`;
    
    if (m <= 30) {
      return `It's ${getNumberName(m)} past ${getNumberName(h)}`;
    } else {
      return `It's ${getNumberName(60 - m)} to ${getNumberName(h === 12 ? 1 : h + 1)}`;
    }
  };

  // Databáze 50 úkolů
  const TIME_POOL = [
    {h:1, m:0}, {h:2, m:0}, {h:3, m:0}, {h:4, m:0}, {h:5, m:0}, {h:6, m:0}, {h:7, m:0}, {h:8, m:0}, {h:9, m:0}, {h:10, m:0}, {h:11, m:0}, {h:12, m:0},
    {h:1, m:30}, {h:2, m:30}, {h:3, m:30}, {h:4, m:30}, {h:5, m:30}, {h:6, m:30}, {h:7, m:30}, {h:8, m:30}, {h:9, m:30}, {h:10, m:30}, {h:11, m:30}, {h:12, m:30},
    {h:1, m:15}, {h:3, m:15}, {h:5, m:15}, {h:7, m:15}, {h:9, m:15}, {h:11, m:15},
    {h:2, m:45}, {h:4, m:45}, {h:6, m:45}, {h:8, m:45}, {h:10, m:45}, {h:12, m:45},
    {h:1, m:5}, {h:2, m:10}, {h:3, m:20}, {h:4, m:25}, {h:5, m:35}, {h:6, m:40}, {h:7, m:50}, {h:8, m:55},
    {h:9, m:5}, {h:10, m:10}, {h:11, m:20}, {h:12, m:25}, {h:1, m:40}, {h:2, m:50}
  ];

  const prepareNewTest = useCallback((selectedDiff: string) => {
    let filteredPool = [];
    if (selectedDiff === 'easy') {
      filteredPool = TIME_POOL.filter(q => q.m === 0 || q.m === 30 || q.m === 15 || q.m === 45);
    } else {
      filteredPool = [...TIME_POOL];
    }

    const shuffled = filteredPool.sort(() => Math.random() - 0.5).slice(0, 10);
    
    const questionsWithDistractors = shuffled.map(q => {
      const correct = getEnglishTimeText(q.h, q.m);
      let distractors: string[] = [];
      while(distractors.length < 3) {
        const rand = TIME_POOL[Math.floor(Math.random() * TIME_POOL.length)];
        const text = getEnglishTimeText(rand.h, rand.m);
        if (text !== correct && !distractors.includes(text)) {
          distractors.push(text);
        }
      }
      return {
        ...q,
        correct,
        options: [...distractors, correct].sort(() => Math.random() - 0.5)
      };
    });

    setCurrentTestQuestions(questionsWithDistractors);
    setDifficulty(selectedDiff);
    const limit = getLimitByDifficulty(selectedDiff);
    setCurrentTimeLimit(limit);
    setQuestionIndex(0);
    setScore(0);
    setTestFinished(false);
    setFeedback(null);
    setUserInput("");
    setTimeLeft(limit);
  }, []);

  const handleAnswer = (option: string) => {
    if (feedback) return;
    const current = currentTestQuestions[questionIndex];
    if (option === "TIMEOUT_EXPIRED") {
      setFeedback({ type: 'error', msg: `Čas vypršel! Správně bylo: ${current.correct}` });
    } else if (option.trim().toLowerCase() === current.correct.toLowerCase()) {
      setScore(s => s + 1);
      setFeedback({ type: 'correct', msg: 'Výborně! Přesně tak.' });
    } else {
      setFeedback({ type: 'error', msg: `Chyba. Správně je: ${current.correct}` });
    }
  };

  const nextQuestion = () => {
    setFeedback(null);
    setUserInput("");
    setTimeLeft(currentTimeLimit);
    if (questionIndex < currentTestQuestions.length - 1) {
      setQuestionIndex(questionIndex + 1);
    } else {
      setTestFinished(true);
    }
  };

  useEffect(() => {
    if (difficulty === 'hard' && !feedback && !testFinished && inputRef.current) {
      inputRef.current.focus();
    }
  }, [difficulty, questionIndex, feedback, testFinished]);

  useEffect(() => {
    let timer: NodeJS.Timeout;
    if (difficulty && !testFinished && !feedback && timeLeft > 0) {
      timer = setInterval(() => {
        setTimeLeft((prev) => prev - 1);
      }, 1000);
    } else if (timeLeft === 0 && !feedback && !testFinished) {
      handleAnswer("TIMEOUT_EXPIRED");
    }

    return () => clearInterval(timer);
  }, [difficulty, testFinished, feedback, timeLeft]);

  const ClockFace = ({ h, m, size = 200, interactive = false }: { h: number; m: number; size?: number; interactive?: boolean }) => {
    const hourAngle = (h % 12) * 30 + m * 0.5;
    const minuteAngle = m * 6;

    return (
      <div className="relative inline-block drop-shadow-lg">
        <svg width={size} height={size} viewBox="0 0 100 100">
          <circle cx="50" cy="50" r="48" fill="#ffffff" stroke="#1e293b" strokeWidth="1.5" />
          {interactive && (
            <>
              <path d="M 50 50 L 50 5 A 45 45 0 0 1 50 95 Z" fill="#ecfdf5" opacity="0.5" />
              <path d="M 50 50 L 50 95 A 45 45 0 0 1 50 5 Z" fill="#eff6ff" opacity="0.5" />
            </>
          )}
          {[12, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11].map((num, i) => {
            const angle = i * 30 * (Math.PI / 180);
            const x = 50 + 38 * Math.sin(angle);
            const y = 50 - 38 * Math.cos(angle);
            return (
              <text key={num} x={x} y={y} textAnchor="middle" dominantBaseline="middle" className="text-[7px] font-bold fill-slate-500">
                {num}
              </text>
            );
          })}
          <line x1="50" y1="50" x2="50" y2="30" stroke="#1e293b" strokeWidth="3" strokeLinecap="round" transform={`rotate(${hourAngle}, 50, 50)`} />
          <line x1="50" y1="50" x2="50" y2="15" stroke="#4f46e5" strokeWidth="2" strokeLinecap="round" transform={`rotate(${minuteAngle}, 50, 50)`} />
          <circle cx="50" cy="50" r="2.5" fill="#1e293b" />
        </svg>
      </div>
    );
  };

  const shareUrl = typeof window !== 'undefined' ? window.location.href : '';

  return (
    <div className="min-h-screen bg-slate-50 p-4 md:p-8 font-sans">
      <div className="max-w-4xl mx-auto">
        
        {/* Hlavní Nadpis */}
        <h1 className="text-4xl md:text-5xl font-black text-slate-800 mb-8 text-center tracking-tight">
          Telling The Time!
        </h1>

        {/* Navigace */}
        <div className="flex bg-white rounded-t-3xl shadow-sm border-b overflow-hidden relative">
          <button 
            onClick={() => setActiveTab('learn')}
            className={`flex-1 py-5 flex items-center justify-center gap-2 font-bold transition-all ${activeTab === 'learn' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:bg-slate-50'}`}
          >
            <BookOpen className="w-5 h-5" /> 1. Vysvětlení
          </button>
          <button 
            onClick={() => setActiveTab('test')}
            className={`flex-1 py-5 flex items-center justify-center gap-2 font-bold transition-all ${activeTab === 'test' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:bg-slate-50'}`}
          >
            <GraduationCap className="w-5 h-5" /> 2. Test
          </button>
          <button 
            onClick={() => setShowShare(true)}
            className="px-6 py-5 text-slate-400 hover:text-indigo-600 hover:bg-slate-50 transition-all border-l"
            title="Sdílet se studenty"
          >
            <Share2 className="w-5 h-5" />
          </button>
        </div>

        <div className="bg-white rounded-b-3xl shadow-xl p-6 md:p-10 min-h-[550px] relative">
          
          {activeTab === 'learn' ? (
            <div className="animate-in fade-in slide-in-from-bottom-4 duration-500">
              <div className="grid md:grid-cols-2 gap-10 items-center">
                <div className="flex flex-col items-center">
                  <ClockFace h={selectedTime.h} m={selectedTime.m} size={280} interactive={true} />
                  <div className="mt-8 w-full max-w-xs space-y-6">
                    <div className="space-y-2">
                      <div className="flex justify-between text-xs font-bold text-slate-400 uppercase">
                        <span>Hodiny</span>
                        <span className="text-indigo-600">{selectedTime.h}</span>
                      </div>
                      <input type="range" min="1" max="12" value={selectedTime.h} onChange={(e) => setSelectedTime({...selectedTime, h: parseInt(e.target.value)})} className="w-full h-2 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-indigo-600" />
                    </div>
                    <div className="space-y-2">
                      <div className="flex justify-between text-xs font-bold text-slate-400 uppercase">
                        <span>Minuty</span>
                        <span className="text-indigo-600">{selectedTime.m}</span>
                      </div>
                      <input type="range" min="0" max="55" step="5" value={selectedTime.m} onChange={(e) => setSelectedTime({...selectedTime, m: parseInt(e.target.value)})} className="w-full h-2 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-indigo-600" />
                    </div>
                  </div>
                </div>
                <div className="space-y-6">
                  <div className="bg-indigo-50 p-6 rounded-2xl border-2 border-indigo-100 shadow-inner">
                    <h2 className="text-slate-400 text-xs font-bold uppercase mb-1">Digitální čas</h2>
                    <p className="text-4xl font-mono font-bold text-indigo-900">{selectedTime.h}:{selectedTime.m.toString().padStart(2, '0')}</p>
                    <div className="h-px bg-indigo-100 my-4" />
                    <h2 className="text-slate-400 text-xs font-bold uppercase mb-1">Anglicky se řekne</h2>
                    <p className="text-2xl font-bold text-indigo-600 leading-tight">{getEnglishTimeText(selectedTime.h, selectedTime.m)}</p>
                  </div>
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div className="bg-emerald-50 p-4 rounded-xl border border-emerald-100">
                      <h3 className="font-bold text-emerald-900 mb-1">Pravá strana: PAST</h3>
                      <p className="text-emerald-700 leading-relaxed text-xs">Do 30. minuty říkáme, kolik minut uplynulo <strong>PO</strong> hodině.</p>
                    </div>
                    <div className="bg-blue-50 p-4 rounded-xl border border-blue-100">
                      <h3 className="font-bold text-blue-900 mb-1">Levá strana: TO</h3>
                      <p className="text-blue-700 leading-relaxed text-xs">Od 31. minuty říkáme, kolik minut zbývá <strong>DO</strong> další hodiny.</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ) : (
            <div className="animate-in fade-in slide-in-from-bottom-4 duration-500">
              {!difficulty ? (
                <div className="max-w-md mx-auto text-center py-12">
                  <BarChart className="w-16 h-16 text-indigo-200 mx-auto mb-6" />
                  <h2 className="text-3xl font-black text-slate-800 mb-4">Vyber si obtížnost</h2>
                  <p className="text-slate-400 mb-10">Zvol si úroveň, na kterou se cítíš.</p>
                  <div className="space-y-4">
                    <button onClick={() => prepareNewTest('easy')} className="w-full p-6 rounded-2xl border-2 border-emerald-100 bg-emerald-50 text-emerald-700 font-bold text-lg hover:border-emerald-300 transition-all flex justify-between items-center group">
                      <div className="flex flex-col items-start">
                        <span>Lehká (Easy)</span>
                        <span className="text-[10px] opacity-60">Limit: 20s na otázku</span>
                      </div>
                      <span className="text-xs bg-emerald-200 px-3 py-1 rounded-full group-hover:bg-emerald-300">Celé, půlky & čtvrtě</span>
                    </button>
                    <button onClick={() => prepareNewTest('medium')} className="w-full p-6 rounded-2xl border-2 border-blue-100 bg-blue-50 text-blue-700 font-bold text-lg hover:border-blue-300 transition-all flex justify-between items-center group">
                      <div className="flex flex-col items-start">
                        <span>Střední (Medium)</span>
                        <span className="text-[10px] opacity-60">Limit: 15s na otázku</span>
                      </div>
                      <span className="text-xs bg-blue-200 px-3 py-1 rounded-full group-hover:bg-blue-300">Všechny kombinace</span>
                    </button>
                    <button onClick={() => prepareNewTest('hard')} className="w-full p-6 rounded-2xl border-2 border-rose-100 bg-rose-50 text-rose-700 font-bold text-lg hover:border-rose-300 transition-all flex justify-between items-center group">
                      <div className="flex flex-col items-start">
                        <div className="flex items-center gap-2">
                          <Keyboard className="w-5 h-5" />
                          <span>Těžká (Hard)</span>
                        </div>
                        <span className="text-[10px] opacity-60">Limit: 25s na otázku</span>
                      </div>
                      <span className="text-xs bg-rose-200 px-3 py-1 rounded-full group-hover:bg-rose-300">Psaní vlastního textu</span>
                    </button>
                  </div>
                </div>
              ) : !testFinished ? (
                <div className="max-w-xl mx-auto">
                  <div className="flex justify-between items-center mb-8 px-2">
                    <button onClick={() => setDifficulty(null)} className="text-xs font-bold text-indigo-600 hover:underline">← Změnit úroveň</button>
                    <div className="text-right">
                      <span className="text-[10px] font-black text-slate-300 uppercase tracking-widest block">Čas</span>
                      <span className={`text-sm font-bold ${timeLeft <= 5 ? 'text-rose-500 animate-pulse' : 'text-indigo-600'}`}>{timeLeft}s</span>
                    </div>
                    <div className="text-right">
                      <span className="text-[10px] font-black text-slate-300 uppercase tracking-widest block">Otázka</span>
                      <span className="text-sm font-bold text-slate-500">{questionIndex + 1} / 10</span>
                    </div>
                  </div>

                  {/* Timer Progress Bar */}
                  <div className="w-full h-1.5 bg-slate-100 rounded-full mb-8 overflow-hidden">
                    <div 
                      className={`h-full transition-all duration-1000 ease-linear ${timeLeft <= 5 ? 'bg-rose-500' : 'bg-indigo-600'}`}
                      style={{ width: `${(timeLeft / currentTimeLimit) * 100}%` }}
                    />
                  </div>

                  <div className="flex flex-col items-center mb-10">
                    <ClockFace h={currentTestQuestions[questionIndex]?.h} m={currentTestQuestions[questionIndex]?.m} size={220} />
                    <p className="mt-6 text-2xl font-black text-slate-800 tracking-tight">What time is it?</p>
                  </div>

                  {difficulty === 'hard' ? (
                    <div className="space-y-4">
                      <div className="relative">
                        <input
                          ref={inputRef}
                          type="text"
                          value={userInput}
                          onChange={(e) => setUserInput(e.target.value)}
                          onKeyDown={(e) => e.key === 'Enter' && userInput.trim() && handleAnswer(userInput)}
                          placeholder="Např: It's ten past two"
                          disabled={!!feedback}
                          className="w-full p-5 text-lg font-bold border-4 border-slate-100 rounded-2xl focus:border-indigo-400 focus:outline-none transition-all"
                        />
                        <div className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-300">
                          <Keyboard className="w-6 h-6" />
                        </div>
                      </div>
                      <button
                        onClick={() => handleAnswer(userInput)}
                        disabled={!!feedback || !userInput.trim()}
                        className="w-full py-4 bg-indigo-600 text-white rounded-xl font-bold hover:bg-indigo-700 transition-all disabled:opacity-50 disabled:bg-slate-300"
                      >
                        Potvrdit odpověď
                      </button>
                      <p className="text-center text-[10px] text-slate-400 uppercase font-bold tracking-widest">Nezapomeň na začátku napsat "It's ..."</p>
                    </div>
                  ) : (
                    <div className="grid gap-3">
                      {currentTestQuestions[questionIndex]?.options.map((opt, i) => (
                        <button
                          key={i}
                          disabled={!!feedback}
                          onClick={() => handleAnswer(opt)}
                          className={`w-full p-4 text-left rounded-xl border-2 font-bold transition-all
                            ${!feedback ? 'border-slate-100 hover:border-indigo-200 hover:bg-indigo-50 active:scale-[0.98]' : 
                              opt === currentTestQuestions[questionIndex].correct ? 'border-emerald-500 bg-emerald-50 text-emerald-700' : 'border-slate-50 opacity-40'}
                          `}
                        >
                          {opt}
                        </button>
                      ))}
                    </div>
                  )}

                  {feedback && (
                    <div className={`mt-8 p-5 rounded-2xl flex items-center justify-between animate-in zoom-in-95 duration-300 ${feedback.type === 'correct' ? 'bg-emerald-50 text-emerald-800 border border-emerald-100' : 'bg-rose-50 text-rose-800 border border-rose-100'}`}>
                      <div className="flex items-center gap-3">
                        {feedback.type === 'correct' ? <CheckCircle2 className="w-6 h-6" /> : <XCircle className="w-6 h-6" />}
                        <span className="font-bold text-sm">{feedback.msg}</span>
                      </div>
                      <button onClick={nextQuestion} className="bg-white px-5 py-2.5 rounded-xl text-xs font-black uppercase tracking-wider shadow-sm hover:shadow-md transition-all flex items-center gap-2">
                        {questionIndex === 9 ? 'Dokončit' : 'Další'} <ChevronRight className="w-4 h-4" />
                      </button>
                    </div>
                  )}
                </div>
              ) : (
                <div className="text-center py-10 max-w-sm mx-auto">
                  <div className="w-24 h-24 bg-indigo-50 rounded-full flex items-center justify-center mx-auto mb-8 shadow-inner">
                    <GraduationCap className="w-12 h-12 text-indigo-600" />
                  </div>
                  <h2 className="text-3xl font-black text-slate-800 mb-2">Test dokončen!</h2>
                  <p className="text-slate-400 font-medium mb-10">Úroveň: <span className="capitalize text-indigo-600 font-bold">{difficulty}</span></p>
                  <div className="relative mb-10">
                    <div className="text-7xl font-black text-indigo-600">{Math.round((score / 10) * 100)}%</div>
                    <div className="text-slate-400 font-bold mt-2">Tvá úspěšnost ({score} z 10)</div>
                  </div>
                  <div className="flex flex-col gap-3">
                    <button onClick={() => prepareNewTest(difficulty || 'medium')} className="flex items-center justify-center gap-3 w-full py-4 bg-indigo-600 text-white rounded-2xl font-black shadow-lg shadow-indigo-100 hover:bg-indigo-700 transition-all active:scale-[0.97]">
                      <RotateCcw className="w-5 h-5" /> DALŠÍCH 10 ÚKOLŮ
                    </button>
                    <button onClick={() => setDifficulty(null)} className="w-full py-4 text-slate-400 font-bold hover:text-slate-600 transition-all">
                      Zpět na výběr obtížnosti
                    </button>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Share Modal */}
          {showShare && (
            <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center z-50 p-4 animate-in fade-in duration-300">
              <div className="bg-white p-8 rounded-[2rem] max-w-sm w-full text-center relative shadow-2xl animate-in zoom-in-95 duration-300">
                 <button onClick={() => setShowShare(false)} className="absolute top-6 right-6 text-slate-300 hover:text-slate-600 transition-colors">
                   <X className="w-6 h-6" />
                 </button>
                 <div className="w-16 h-16 bg-indigo-50 rounded-2xl flex items-center justify-center mx-auto mb-6">
                    <Share2 className="w-8 h-8 text-indigo-600" />
                 </div>
                 <h3 className="text-2xl font-black text-slate-800 mb-2">Sdílet se studenty</h3>
                 <p className="text-sm text-slate-400 mb-6">Naskenujte kód pro rychlý přístup k procvičování hodin.</p>
                 
                 <div className="bg-slate-50 p-6 rounded-3xl mb-8 flex justify-center border-2 border-slate-100">
                   <QRCodeCanvas 
                     value={shareUrl} 
                     size={200}
                     level="H"
                     includeMargin={true}
                     className="rounded-lg"
                   />
                 </div>
                 
                 <button 
                  onClick={() => setShowShare(false)} 
                  className="w-full py-4 bg-indigo-600 text-white rounded-2xl font-black shadow-lg shadow-indigo-100 hover:bg-indigo-700 transition-all"
                 >
                   HOTOVO
                 </button>
              </div>
            </div>
          )}
        </div>
        <p className="mt-8 text-center text-slate-300 text-[10px] font-bold uppercase tracking-[0.2em] flex items-center justify-center gap-2">
          <span className="w-1.5 h-1.5 bg-emerald-400 rounded-full animate-pulse"></span>
          Offline Ready • Interactive English Learning Tool • Level A1/A2
        </p>
      </div>
    </div>
  );
};

export default App;
