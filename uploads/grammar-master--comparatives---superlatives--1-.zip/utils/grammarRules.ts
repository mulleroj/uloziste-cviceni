
import { Question } from '../types';

export const getGrammarHint = (question: Question): string => {
  const adj = question.adjective.toLowerCase();
  const type = question.type;
  const isSuperlative = type === 'superlative';
  const prefix = isSuperlative ? 'Remember: Superlatives MUST always start with "the". ' : '';

  // Irregular adjectives
  const irregulars: Record<string, { comparative: string; superlative: string; rule: string }> = {
    'good': { comparative: 'better', superlative: 'the best', rule: 'This is an irregular adjective.' },
    'bad': { comparative: 'worse', superlative: 'the worst', rule: 'This is an irregular adjective.' },
    'far': { comparative: 'further', superlative: 'the furthest', rule: 'This is an irregular adjective.' },
  };

  if (irregulars[adj]) {
    return `${prefix}${irregulars[adj].rule} The ${type} form is "${irregulars[adj][type]}".`;
  }

  // Long adjectives
  const longAdjectives = ['expensive', 'difficult', 'delicious', 'comfortable', 'boring', 'dangerous'];
  if (longAdjectives.includes(adj)) {
    if (isSuperlative) {
      return `${prefix}For long adjectives, we use "the most" before the base word.`;
    }
    return `For long adjectives, we use "more" before the base word.`;
  }

  // Short adjectives ending in 'y'
  if (adj.endsWith('y')) {
    const suffix = type === 'comparative' ? 'er' : 'est';
    return `${prefix}For adjectives ending in 'y', change 'y' to 'i' and add -${suffix}.`;
  }

  // CVC rule
  const cvcWords = ['hot', 'big', 'fat', 'sad', 'thin'];
  if (cvcWords.includes(adj)) {
    const suffix = type === 'comparative' ? 'er' : 'est';
    return `${prefix}Short CVC adjectives double the last letter before adding -${suffix}.`;
  }

  // Adjectives ending in 'e'
  if (adj.endsWith('e')) {
    const suffix = type === 'comparative' ? 'r' : 'st';
    return `${prefix}Adjectives already ending in 'e' only add -${suffix}.`;
  }

  // Standard rule
  const suffix = type === 'comparative' ? 'er' : 'est';
  return `${prefix}For most short adjectives, add the suffix -${suffix}.`;
};
