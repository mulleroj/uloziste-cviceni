import React, { useState, useEffect } from 'react';
import { BookOpen, GraduationCap, CheckCircle, RefreshCcw, QrCode, Check, X, History, Trash2, ChevronDown, ChevronUp } from 'lucide-react';
import { QRCodeSVG } from 'qrcode.react';

interface HistoryEntry {
  id: string;
  date: string;
  score: number;
  total: number;
  difficulty: string;
  errors: { text: string; userAns: string; correctAns: string }[];
}

const HistoryItem: React.FC<{ item: HistoryEntry }> = ({ item }) => {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <div className="border border-slate-100 rounded-xl overflow-hidden">
      <button 
        onClick={() => setIsOpen(!isOpen)}
        className="w-full flex items-center justify-between p-4 hover:bg-slate-50 transition-colors text-left"
      >
        <div className="flex items-center gap-4">
          <div className={`w-10 h-10 rounded-full flex items-center justify-center font-bold ${
            item.score === item.total ? 'bg-emerald-100 text-emerald-600' : 
            item.score > item.total * 0.7 ? 'bg-indigo-100 text-indigo-600' : 
            'bg-amber-100 text-amber-600'
          }`}>
            {item.score}
          </div>
          <div>
            <div className="font-bold text-slate-800">{item.date}</div>
            <div className="text-xs text-slate-500 uppercase tracking-wider font-semibold">
              {item.difficulty === 'beginner' ? 'Začátečník' : item.difficulty === 'intermediate' ? 'Střední' : 'Pokročilý'} • {item.total} otázek
            </div>
          </div>
        </div>
        <div className="flex items-center gap-2">
          {item.errors.length > 0 && (
            <span className="text-xs bg-rose-100 text-rose-600 px-2 py-0.5 rounded-full font-bold">
              {item.errors.length} {item.errors.length === 1 ? 'chyba' : item.errors.length < 5 ? 'chyby' : 'chyb'}
            </span>
          )}
          {isOpen ? <ChevronUp className="w-4 h-4 text-slate-400" /> : <ChevronDown className="w-4 h-4 text-slate-400" />}
        </div>
      </button>
      
      {isOpen && (
        <div className="p-4 bg-slate-50 border-t border-slate-100 animate-in slide-in-from-top-2 duration-200">
          {item.errors.length === 0 ? (
            <p className="text-sm text-emerald-600 font-medium flex items-center gap-2">
              <Check className="w-4 h-4" /> Žádné chyby! Skvělý výkon.
            </p>
          ) : (
            <div className="space-y-2">
              <div className="text-xs font-bold text-slate-400 uppercase mb-2">Přehled chyb:</div>
              {item.errors.map((error, idx) => (
                <div key={idx} className="flex items-center justify-between bg-white p-2 rounded-lg border border-slate-100 text-sm">
                  <span className="font-medium text-slate-700">{error.text}</span>
                  <div className="flex items-center gap-2">
                    <span className="text-rose-500 line-through">{error.userAns || '---'}</span>
                    <span className="text-emerald-600 font-bold">{error.correctAns}</span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
};

const App = () => {
  const [activeTab, setActiveTab] = useState<'explanation' | 'exercise' | 'history'>('explanation');
  const [questions, setQuestions] = useState<{ text: string; ans: string }[]>([]);
  const [userAnswers, setUserAnswers] = useState<Record<number, string>>({});
  const [showResults, setShowResults] = useState(false);
  const [score, setScore] = useState(0);
  const [history, setHistory] = useState<HistoryEntry[]>([]);

  const [difficulty, setDifficulty] = useState<'beginner' | 'intermediate' | 'advanced'>('beginner');

  // Load history from localStorage
  useEffect(() => {
    const savedHistory = localStorage.getItem('preposition_history');
    if (savedHistory) {
      try {
        setHistory(JSON.parse(savedHistory));
      } catch (e) {
        console.error("Failed to parse history", e);
      }
    }
  }, []);

  // Save history to localStorage whenever it changes
  useEffect(() => {
    localStorage.setItem('preposition_history', JSON.stringify(history));
  }, [history]);

  // Databáze 100 zadání s úrovněmi
  const allData = [
    // Beginner
    { text: "___ Monday", ans: "on", level: "beginner" },
    { text: "___ 5 o'clock", ans: "at", level: "beginner" },
    { text: "___ the morning", ans: "in", level: "beginner" },
    { text: "___ summer", ans: "in", level: "beginner" },
    { text: "___ 1999", ans: "in", level: "beginner" },
    { text: "___ night", ans: "at", level: "beginner" },
    { text: "___ June", ans: "in", level: "beginner" },
    { text: "___ noon", ans: "at", level: "beginner" },
    { text: "___ the evening", ans: "in", level: "beginner" },
    { text: "___ winter", ans: "in", level: "beginner" },
    { text: "___ October", ans: "in", level: "beginner" },
    { text: "___ 10:30 AM", ans: "at", level: "beginner" },
    { text: "___ autumn", ans: "in", level: "beginner" },
    { text: "___ the afternoon", ans: "in", level: "beginner" },
    { text: "___ midnight", ans: "at", level: "beginner" },
    { text: "___ Saturday", ans: "on", level: "beginner" },
    { text: "___ 2025", ans: "in", level: "beginner" },
    { text: "___ July", ans: "in", level: "beginner" },
    { text: "___ February", ans: "in", level: "beginner" },
    { text: "___ 9 o'clock", ans: "at", level: "beginner" },
    { text: "___ August", ans: "in", level: "beginner" },
    { text: "___ Wednesday", ans: "on", level: "beginner" },
    { text: "___ March", ans: "in", level: "beginner" },
    { text: "___ Thursday", ans: "on", level: "beginner" },
    { text: "___ September", ans: "in", level: "beginner" },
    { text: "___ November", ans: "in", level: "beginner" },
    { text: "___ December", ans: "in", level: "beginner" },
    { text: "___ 12:00", ans: "at", level: "beginner" },
    { text: "___ May", ans: "in", level: "beginner" },
    { text: "___ April", ans: "in", level: "beginner" },
    { text: "___ Tuesday morning", ans: "on", level: "beginner" },
    { text: "___ Friday night", ans: "on", level: "beginner" },
    { text: "___ Sunday afternoon", ans: "on", level: "beginner" },

    // Intermediate
    { text: "___ Christmas Day", ans: "on", level: "intermediate" },
    { text: "___ the weekend", ans: "at", level: "intermediate" },
    { text: "___ April 12th", ans: "on", level: "intermediate" },
    { text: "___ Easter", ans: "at", level: "intermediate" },
    { text: "___ New Year's Eve", ans: "on", level: "intermediate" },
    { text: "___ the 21st century", ans: "in", level: "intermediate" },
    { text: "___ bedtime", ans: "at", level: "intermediate" },
    { text: "___ my birthday", ans: "on", level: "intermediate" },
    { text: "___ May 1st", ans: "on", level: "intermediate" },
    { text: "___ the 1980s", ans: "in", level: "intermediate" },
    { text: "___ breakfast time", ans: "at", level: "intermediate" },
    { text: "___ spring", ans: "in", level: "intermediate" },
    { text: "___ half past seven", ans: "at", level: "intermediate" },
    { text: "___ weekdays", ans: "on", level: "intermediate" },
    { text: "___ lunch", ans: "at", level: "intermediate" },
    { text: "___ New Year's Day", ans: "on", level: "intermediate" },
    { text: "___ dinner time", ans: "at", level: "intermediate" },
    { text: "___ the past", ans: "in", level: "intermediate" },
    { text: "___ the moment", ans: "at", level: "intermediate" },
    { text: "___ Christmas Eve", ans: "on", level: "intermediate" },
    { text: "___ the future", ans: "in", level: "intermediate" },
    { text: "___ Mother's Day", ans: "on", level: "intermediate" },
    { text: "___ 6 PM", ans: "at", level: "intermediate" },
    { text: "___ the holidays", ans: "in", level: "intermediate" },
    { text: "___ March", ans: "in", level: "intermediate" },
    { text: "___ 11:45", ans: "at", level: "intermediate" },
    { text: "___ Valentine's Day", ans: "on", level: "intermediate" },
    { text: "___ 2:15", ans: "at", level: "intermediate" },
    { text: "___ the weekend (US)", ans: "on", level: "intermediate" },
    { text: "___ July 4th", ans: "on", level: "intermediate" },
    { text: "___ ten o'clock", ans: "at", level: "intermediate" },
    { text: "___ school days", ans: "on", level: "intermediate" },
    { text: "___ lunch time", ans: "at", level: "intermediate" },
    { text: "___ 1945", ans: "in", level: "intermediate" },
    { text: "___ payday", ans: "on", level: "intermediate" },

    // Advanced
    { text: "___ sunrise", ans: "at", level: "advanced" },
    { text: "___ a sunny day", ans: "on", level: "advanced" },
    { text: "___ sunset", ans: "at", level: "advanced" },
    { text: "___ holiday", ans: "on", level: "advanced" },
    { text: "___ the same time", ans: "at", level: "advanced" },
    { text: "___ a few minutes", ans: "in", level: "advanced" },
    { text: "___ a cold day", ans: "on", level: "advanced" },
    { text: "___ dawn", ans: "at", level: "advanced" },
    { text: "___ the end of the month", ans: "at", level: "advanced" },
    { text: "___ a rainy day", ans: "on", level: "advanced" },
    { text: "___ the Middle Ages", ans: "in", level: "advanced" },
    { text: "___ the start of the film", ans: "at", level: "advanced" },
    { text: "___ the age of five", ans: "at", level: "advanced" },
    { text: "___ a dark night", ans: "on", level: "advanced" },
    { text: "___ the morning of the 5th", ans: "in", level: "advanced" },
    { text: "___ Easter Monday", ans: "on", level: "advanced" },
    { text: "___ current time", ans: "at", level: "advanced" },
    { text: "___ the ice age", ans: "in", level: "advanced" },
    { text: "___ New Year", ans: "at", level: "advanced" },
    { text: "___ my graduation day", ans: "on", level: "advanced" },
    { text: "___ a wet Friday", ans: "on", level: "advanced" },
    { text: "___ nightfall", ans: "at", level: "advanced" },
    { text: "___ the 90s", ans: "in", level: "advanced" },
    { text: "___ Halloween", ans: "at", level: "advanced" },
    { text: "___ a summer evening", ans: "on", level: "advanced" },
    { text: "___ mid-day", ans: "at", level: "advanced" },
    { text: "___ home time", ans: "at", level: "advanced" },
    { text: "___ the next century", ans: "in", level: "advanced" },
    { text: "___ any day", ans: "on", level: "advanced" },
    { text: "___ tea time", ans: "at", level: "advanced" }
  ];

  const generateTest = () => {
    const filtered = allData.filter(d => d.level === difficulty);
    const shuffled = [...filtered].sort(() => 0.5 - Math.random());
    setQuestions(shuffled.slice(0, 20));
    setUserAnswers({});
    setShowResults(false);
    setScore(0);
  };

  useEffect(() => {
    generateTest();
  }, [difficulty]);

  const handleSelect = (index: number, val: string) => {
    setUserAnswers({ ...userAnswers, [index]: val });
  };

  const checkResults = () => {
    let currentScore = 0;
    const errors: { text: string; userAns: string; correctAns: string }[] = [];

    questions.forEach((q, idx) => {
      const userAns = userAnswers[idx] || "";
      if (userAns === q.ans) {
        currentScore++;
      } else {
        errors.push({
          text: q.text,
          userAns: userAns,
          correctAns: q.ans
        });
      }
    });

    setScore(currentScore);
    setShowResults(true);

    // Save to history
    const newResult = {
      id: Date.now().toString(),
      date: new Date().toLocaleString('cs-CZ'),
      score: currentScore,
      total: questions.length,
      difficulty,
      errors
    };
    setHistory(prev => [newResult, ...prev].slice(0, 50)); // Keep last 50 results
  };

  const answeredCount = Object.keys(userAnswers).length;
  const progressPercentage = (answeredCount / 20) * 100;

  return (
    <div className="min-h-screen bg-slate-50 font-sans text-slate-900 p-4 md:p-8">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <header className="flex flex-col md:flex-row justify-between items-center mb-8 gap-4 bg-white p-6 rounded-2xl shadow-sm border border-slate-100">
          <div>
            <h1 className="text-3xl font-bold text-indigo-600 flex items-center gap-2">
              <GraduationCap className="w-8 h-8" />
              Prepositions of Time
              <span className="hidden md:inline-block text-[10px] bg-emerald-100 text-emerald-600 px-2 py-0.5 rounded-full font-bold uppercase tracking-wider">
                Offline Ready
              </span>
            </h1>
            <p className="text-slate-500">Předložky AT, IN, ON interaktivně</p>
          </div>
          <div className="flex bg-slate-100 p-1 rounded-xl" role="tablist" aria-label="Navigace aplikace">
            <button 
              onClick={() => setActiveTab('explanation')}
              role="tab"
              aria-selected={activeTab === 'explanation'}
              aria-controls="explanation-panel"
              id="tab-explanation"
              className={`flex items-center gap-2 px-4 py-2 rounded-lg transition-all focus:outline-none focus:ring-2 focus:ring-indigo-500 ${activeTab === 'explanation' ? 'bg-white shadow-sm text-indigo-600' : 'text-slate-500 hover:text-slate-700'}`}
            >
              <BookOpen className="w-4 h-4" aria-hidden="true" /> Vysvětlení
            </button>
            <button 
              onClick={() => setActiveTab('exercise')}
              role="tab"
              aria-selected={activeTab === 'exercise'}
              aria-controls="exercise-panel"
              id="tab-exercise"
              className={`flex items-center gap-2 px-4 py-2 rounded-lg transition-all focus:outline-none focus:ring-2 focus:ring-indigo-500 ${activeTab === 'exercise' ? 'bg-white shadow-sm text-indigo-600' : 'text-slate-500 hover:text-slate-700'}`}
            >
              <CheckCircle className="w-4 h-4" aria-hidden="true" /> Cvičení
            </button>
            <button 
              onClick={() => setActiveTab('history')}
              role="tab"
              aria-selected={activeTab === 'history'}
              aria-controls="history-panel"
              id="tab-history"
              className={`flex items-center gap-2 px-4 py-2 rounded-lg transition-all focus:outline-none focus:ring-2 focus:ring-indigo-500 ${activeTab === 'history' ? 'bg-white shadow-sm text-indigo-600' : 'text-slate-500 hover:text-slate-700'}`}
            >
              <History className="w-4 h-4" aria-hidden="true" /> Historie
            </button>
          </div>
        </header>

        <main>
          {/* Vysvětlení */}
          {activeTab === 'explanation' && (
            <div 
              id="explanation-panel"
              role="tabpanel"
              aria-labelledby="tab-explanation"
              className="grid grid-cols-1 md:grid-cols-3 gap-6 animate-in fade-in duration-500"
            >
              <section className="bg-white p-6 rounded-2xl shadow-sm border-t-4 border-indigo-500">
                <h2 className="text-xl font-bold mb-4 flex items-center gap-2 text-indigo-700">
                  <span className="bg-indigo-100 text-indigo-600 px-2 py-0.5 rounded text-sm uppercase">at</span>
                  Konkrétní čas
                </h2>
                <ul className="space-y-3 text-slate-600">
                  <li className="flex items-start gap-2">
                    <div className="w-1.5 h-1.5 rounded-full bg-indigo-400 mt-2 shrink-0" aria-hidden="true" />
                    <span><b>Přesný čas:</b> at 8 o'clock, at 10:30 PM</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <div className="w-1.5 h-1.5 rounded-full bg-indigo-400 mt-2 shrink-0" aria-hidden="true" />
                    <span><b>Části dne (bez členu):</b> at night, at noon, at midnight</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <div className="w-1.5 h-1.5 rounded-full bg-indigo-400 mt-2 shrink-0" aria-hidden="true" />
                    <span><b>Svátky (období):</b> at Christmas, at Easter</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <div className="w-1.5 h-1.5 rounded-full bg-indigo-400 mt-2 shrink-0" aria-hidden="true" />
                    <span><b>Časy jídla:</b> at breakfast, at lunchtime</span>
                  </li>
                </ul>
              </section>

              <section className="bg-white p-6 rounded-2xl shadow-sm border-t-4 border-emerald-500">
                <h2 className="text-xl font-bold mb-4 flex items-center gap-2 text-emerald-700">
                  <span className="bg-emerald-100 text-emerald-600 px-2 py-0.5 rounded text-sm uppercase">on</span>
                  Dny a data
                </h2>
                <ul className="space-y-3 text-slate-600">
                  <li className="flex items-start gap-2">
                    <div className="w-1.5 h-1.5 rounded-full bg-emerald-400 mt-2 shrink-0" aria-hidden="true" />
                    <span><b>Dny v týdnu:</b> on Monday, on Friday night</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <div className="w-1.5 h-1.5 rounded-full bg-emerald-400 mt-2 shrink-0" aria-hidden="true" />
                    <span><b>Kalendářní data:</b> on April 12th, on 1st May</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <div className="w-1.5 h-1.5 rounded-full bg-emerald-400 mt-2 shrink-0" aria-hidden="true" />
                    <span><b>Specifické dny:</b> on my birthday, on Christmas Day</span>
                  </li>
                </ul>
              </section>

              <section className="bg-white p-6 rounded-2xl shadow-sm border-t-4 border-amber-500">
                <h2 className="text-xl font-bold mb-4 flex items-center gap-2 text-amber-700">
                  <span className="bg-amber-100 text-amber-600 px-2 py-0.5 rounded text-sm uppercase">in</span>
                  Delší období
                </h2>
                <ul className="space-y-3 text-slate-600">
                  <li className="flex items-start gap-2">
                    <div className="w-1.5 h-1.5 rounded-full bg-amber-400 mt-2 shrink-0" aria-hidden="true" />
                    <span><b>Měsíce a roky:</b> in June, in 2024, in the 90s</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <div className="w-1.5 h-1.5 rounded-full bg-amber-400 mt-2 shrink-0" aria-hidden="true" />
                    <span><b>Roční období:</b> in summer, in winter</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <div className="w-1.5 h-1.5 rounded-full bg-amber-400 mt-2 shrink-0" aria-hidden="true" />
                    <span><b>Části dne (se členem):</b> in the morning, in the evening</span>
                  </li>
                </ul>
              </section>
            </div>
          )}

          {/* Cvičení */}
          {activeTab === 'exercise' && (
            <div 
              id="exercise-panel"
              role="tabpanel"
              aria-labelledby="tab-exercise"
              className="bg-white p-6 md:p-8 rounded-2xl shadow-sm border border-slate-100 animate-in slide-in-from-bottom-4 duration-500"
            >
              <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6 gap-4">
                <div>
                  <h2 className="text-xl font-bold flex items-center gap-2">
                    Procvičování (20 náhodných úkolů)
                  </h2>
                  <div className="flex gap-2 mt-2" role="group" aria-label="Výběr obtížnosti">
                    {(['beginner', 'intermediate', 'advanced'] as const).map((level) => (
                      <button
                        key={level}
                        onClick={() => setDifficulty(level)}
                        aria-pressed={difficulty === level}
                        className={`px-3 py-1 rounded-full text-xs font-bold transition-all focus:outline-none focus:ring-2 focus:ring-indigo-500 ${
                          difficulty === level 
                            ? 'bg-indigo-600 text-white' 
                            : 'bg-slate-100 text-slate-500 hover:bg-slate-200'
                        }`}
                      >
                        {level === 'beginner' ? 'Začátečník' : level === 'intermediate' ? 'Střední' : 'Pokročilý'}
                      </button>
                    ))}
                  </div>
                </div>
                <button 
                  onClick={generateTest}
                  className="flex items-center gap-1 text-sm bg-slate-100 hover:bg-slate-200 px-3 py-1.5 rounded-lg transition-colors focus:outline-none focus:ring-2 focus:ring-indigo-500"
                >
                  <RefreshCcw className="w-4 h-4" aria-hidden="true" /> Nový test
                </button>
              </div>

              {/* Progress Bar */}
              <div className="mb-8">
                <div className="flex justify-between items-center mb-2">
                  <span className="text-sm font-medium text-slate-600" id="progress-label">Průběh: {answeredCount} / 20</span>
                  <span className="text-sm font-bold text-indigo-600">{Math.round(progressPercentage)}%</span>
                </div>
                <div 
                  className="w-full bg-slate-100 rounded-full h-2.5"
                  role="progressbar"
                  aria-valuenow={answeredCount}
                  aria-valuemin={0}
                  aria-valuemax={20}
                  aria-labelledby="progress-label"
                >
                  <div 
                    className="bg-indigo-600 h-2.5 rounded-full transition-all duration-300 ease-out" 
                    style={{ width: `${progressPercentage}%` }}
                  ></div>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-x-12 gap-y-4 mb-8">
                {questions.map((q, idx) => (
                  <div key={idx} className="flex items-center justify-between p-3 rounded-xl hover:bg-slate-50 transition-colors border border-transparent hover:border-slate-100">
                    <div className="flex-1 flex items-center">
                      <span className="w-8 text-slate-500 text-sm font-mono">{idx + 1}.</span>
                      <div className="flex items-center gap-2 w-full">
                        <select 
                          disabled={showResults}
                          value={userAnswers[idx] || ""}
                          onChange={(e) => handleSelect(idx, e.target.value)}
                          aria-label={`Předložka pro: ${q.text.replace("___", "")}`}
                          className={`px-2 py-1 rounded border-2 outline-none focus:ring-2 focus:ring-indigo-500 transition-all ${
                            showResults 
                              ? (userAnswers[idx] === q.ans ? 'bg-emerald-50 border-emerald-500 text-emerald-700' : 'bg-rose-50 border-rose-500 text-rose-700')
                              : 'bg-white border-slate-200 text-slate-700'
                          }`}
                        >
                          <option value="">---</option>
                          <option value="at">at</option>
                          <option value="in">in</option>
                          <option value="on">on</option>
                        </select>
                        <span className="text-lg font-medium">{q.text.replace("___", "")}</span>
                      </div>
                    </div>
                    {showResults && (
                      <div className="ml-2 flex items-center gap-2">
                        {userAnswers[idx] === q.ans ? (
                          <Check className="w-5 h-5 text-emerald-600" aria-label="Správně" />
                        ) : (
                          <>
                            <X className="w-5 h-5 text-rose-600" aria-label="Chyba" />
                            <span className="text-rose-700 font-bold text-xs whitespace-nowrap">Správně: {q.ans}</span>
                          </>
                        )}
                      </div>
                    )}
                  </div>
                ))}
              </div>

              {!showResults ? (
                <button 
                  onClick={checkResults}
                  className="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-4 rounded-xl shadow-lg shadow-indigo-200 transition-all transform hover:-translate-y-1 focus:outline-none focus:ring-4 focus:ring-indigo-300"
                >
                  Zkontrolovat výsledky
                </button>
              ) : (
                <div className="p-6 bg-slate-50 rounded-2xl border-2 border-indigo-100 text-center">
                  <div className="text-4xl font-black text-indigo-600 mb-2" role="status">
                    {score} / 20
                  </div>
                  <p className="text-slate-700 mb-4">
                    {score === 20 ? "Excelentní! Neudělali jste jedinou chybu." : 
                     score > 15 ? "Skvělá práce! Skoro bezchybné." : 
                     score > 10 ? "Dobré, ale zkus se ještě podívat na pravidla." : 
                     "Chce to ještě trochu cviku."}
                  </p>
                  <button 
                    onClick={generateTest}
                    className="bg-white border-2 border-indigo-600 text-indigo-600 hover:bg-indigo-50 px-8 py-2 rounded-lg font-bold transition-all focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  >
                    Zkusit znovu
                  </button>
                </div>
              )}
            </div>
          )}

          {/* Historie */}
          {activeTab === 'history' && (
            <div 
              id="history-panel"
              role="tabpanel"
              aria-labelledby="tab-history"
              className="bg-white p-6 md:p-8 rounded-2xl shadow-sm border border-slate-100 animate-in slide-in-from-right-4 duration-500"
            >
              <div className="flex justify-between items-center mb-6">
                <h2 className="text-xl font-bold flex items-center gap-2">
                  <History className="w-5 h-5 text-indigo-500" /> Historie testů
                </h2>
                {history.length > 0 && (
                  <button 
                    onClick={() => {
                      if (confirm('Opravdu chcete smazat celou historii?')) {
                        setHistory([]);
                      }
                    }}
                    className="flex items-center gap-1 text-xs text-rose-500 hover:text-rose-700 transition-colors"
                  >
                    <Trash2 className="w-3.5 h-3.5" /> Smazat vše
                  </button>
                )}
              </div>

              {history.length === 0 ? (
                <div className="text-center py-12 bg-slate-50 rounded-2xl border-2 border-dashed border-slate-200">
                  <History className="w-12 h-12 text-slate-300 mx-auto mb-4" />
                  <p className="text-slate-500">Zatím nemáte žádné uložené výsledky.</p>
                  <button 
                    onClick={() => setActiveTab('exercise')}
                    className="mt-4 text-indigo-600 font-bold hover:underline"
                  >
                    Spustit první test
                  </button>
                </div>
              ) : (
                <div className="space-y-4">
                  {history.map((item) => (
                    <HistoryItem key={item.id} item={item} />
                  ))}
                </div>
              )}
            </div>
          )}
        </main>

        {/* Footer with QR Code */}
        <footer className="mt-12 flex flex-col md:flex-row items-center justify-between gap-6 p-8 bg-white rounded-2xl shadow-sm border border-slate-100">
          <div className="text-center md:text-left">
            <h3 className="text-xl font-bold flex items-center gap-2 justify-center md:justify-start">
              <QrCode className="w-5 h-5 text-indigo-500" />
              Sdílet s ostatními
            </h3>
            <p className="text-slate-500 mt-2 max-w-sm">
              Namiřte fotoaparát na QR kód a otevřete toto cvičení na jiném zařízení. Funguje i bez internetu (PWA).
            </p>
          </div>
          <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200">
            <QRCodeSVG 
              value={window.location.href}
              size={128}
              level="H"
              includeMargin={false}
              className="w-32 h-32"
            />
          </div>
        </footer>
      </div>
    </div>
  );
};

export default App;
