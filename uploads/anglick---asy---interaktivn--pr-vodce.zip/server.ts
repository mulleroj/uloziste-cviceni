import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI } from '@google/genai';
import dotenv from 'dotenv';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // Initialize Gemini client lazily/safely
  const getAI = () => {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      throw new Error('GEMINI_API_KEY process variable is missing.');
    }
    return new GoogleGenAI({ apiKey });
  };

  // API endpoint for AI grammar explanation & analysis
  app.post('/api/ai-explain', async (req, res) => {
    try {
      const { text, tenseContext } = req.body;
      if (!text) {
        return res.status(400).json({ error: 'Text prompt is required.' });
      }

      const ai = getAI();
      const prompt = `Jsi expert na výuku anglické gramatiky a časů pro české studenty.
Analýza věty: "${text}"
${tenseContext ? `Zaměření na čas: ${tenseContext}` : ''}

Prosím poskytni strukturovanou odpověď v jazyce čeština ve formátu JSON obsahující následující pole:
{
  "tenseName": "Název mluvnického času anglicky i česky",
  "explanation": "Jasné a srozumitelné vysvětlení, proč se používá tento čas",
  "formula": "Gramatický vzorec (+, -, ?)",
  "signalWords": ["seznam typických signalizačních slov"],
  "examples": [
    { "en": "Anglická kladná věta", "cz": "Český překlad" },
    { "en": "Anglická záporná věta", "cz": "Český překlad" },
    { "en": "Anglická otázka", "cz": "Český překlad" }
  ],
  "commonMistakes": "Časté chyby českých mluvčích u tohoto času"
}`;

      const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: prompt,
        config: {
          responseMimeType: 'application/json',
        },
      });

      const responseText = response.text || '{}';
      const data = JSON.parse(responseText);
      return res.json(data);
    } catch (error: any) {
      console.error('Error in /api/ai-explain:', error);
      return res.status(500).json({
        error: error.message || 'Nepodařilo se vygenerovat vysvětlení pomocí AI.',
      });
    }
  });

  // API endpoint for custom AI practice questions
  app.post('/api/ai-generate-questions', async (req, res) => {
    try {
      const { category, count = 5, difficulty = 'medium' } = req.body;
      const ai = getAI();

      const prompt = `Vygeneruj ${count} testových otázek pro výuku anglických časů zaměřených na téma: ${category || 'Všechny časy'}. Obtížnost: ${difficulty}.
Odpověz výhradně ve formátu JSON jako pole objektů s touto strukturou:
[
  {
    "q": "Věta s podtržítkem pro doplňovaný čas, např. 'She _______ (work) when I called.'",
    "options": ["3 nebo 4 možnosti odpovídající danému místu, např. 'was working', 'worked', 'is working'"],
    "answer": 0,
    "explanation": "Podrobné české vysvětlení, proč je správná odpověď index 0 a proč ostatní možnosti nesedí."
  }
]`;

      const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: prompt,
        config: {
          responseMimeType: 'application/json',
        },
      });

      const responseText = response.text || '[]';
      const questions = JSON.parse(responseText);
      return res.json({ questions });
    } catch (error: any) {
      console.error('Error in /api/ai-generate-questions:', error);
      return res.status(500).json({
        error: error.message || 'Nepodařilo se vygenerovat otázky.',
      });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server is running on http://localhost:${PORT}`);
  });
}

startServer();
