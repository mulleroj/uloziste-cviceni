import { TenseDetail } from '../types';

export const tensesDetails: TenseDetail[] = [
  // --- PRESENT TENSES ---
  {
    id: 'present-simple',
    name: 'Present Simple',
    nameCz: 'Přítomný prostý čas',
    category: 'present',
    shortDesc: 'Fakta, zvyky, pravidelně se opakující děje a trvalé situace.',
    detailedDesc: 'Používá se pro děje, které se pravidelně opakují, pro fakta, všeobecné pravdy, jízdní řády nebo trvalé záliby. Nezávisí na tom, co se děje zrovna v tuto vteřinu.',
    formula: {
      positive: 'S + sloveso (u 3. os. j.č. přidej -s/-es)',
      negative: 'S + do not / does not + základní sloveso',
      question: 'Do / Does + S + základní sloveso?',
    },
    signalWords: ['always', 'usually', 'often', 'sometimes', 'every day', 'never', 'on Mondays'],
    examples: [
      { en: 'Water boils at 100°C.', cz: 'Voda vře při 100°C. (Fyzikální fakt)', type: 'positive' },
      { en: 'I drive to work every morning.', cz: 'Každé ráno jezdím do práce autem. (Zvyk)', type: 'positive' },
      { en: 'He doesn\'t like spinach.', cz: 'On nemá rád špenát. (Fakt)', type: 'negative' },
      { en: 'Do you speak English?', cz: 'Mluvíte anglicky?', type: 'question' },
    ],
    colorTheme: {
      badge: 'bg-emerald-100 text-emerald-800 border-emerald-300',
      bg: 'bg-emerald-50/70',
      border: 'border-emerald-200',
      text: 'text-emerald-900',
      accent: 'emerald',
    },
    miniQuiz: {
      question: 'Voda ______ při 100°C.',
      options: [
        { text: 'boils', correct: true, explanation: 'Správně! Jedná se o fyzikální fakt, který platí stále.' },
        { text: 'is boiling', correct: false, explanation: 'Ne. Průběhový čas by znamenal, že vře právě teď před námi v hrnci, ale mluvíme o poučce.' },
      ],
    },
  },
  {
    id: 'present-continuous',
    name: 'Present Continuous',
    nameCz: 'Přítomný průběhový čas',
    category: 'present',
    shortDesc: 'Děj probíhající PRÁVĚ TEĎ nebo v dočasném období okolo teď.',
    detailedDesc: 'Vyjadřuje akce, které probíhají v momentě promluvy ("teď"), dočasné situace ("tento týden bydlim u kamaráda") nebo pevně domluvené osobní plány do blízké budoucnosti.',
    formula: {
      positive: 'S + am / is / are + sloveso-ing',
      negative: 'S + am not / isn\'t / aren\'t + sloveso-ing',
      question: 'Am / Is / Are + S + sloveso-ing?',
    },
    signalWords: ['now', 'right now', 'at the moment', 'currently', 'today', 'this week', 'Look!'],
    examples: [
      { en: 'Look! It is raining outside.', cz: 'Dívej! Venku prší. (Děj probíhá teď)', type: 'positive' },
      { en: 'I am working in London this month.', cz: 'Tento měsíc pracuji v Londýně. (Dočasný stav)', type: 'positive' },
      { en: 'She isn\'t listening to me.', cz: 'Ona mě neposlouchá.', type: 'negative' },
      { en: 'Are you coming to the party tonight?', cz: 'Přijdeš dnes večer na párty?', type: 'question' },
    ],
    colorTheme: {
      badge: 'bg-blue-100 text-blue-800 border-blue-300',
      bg: 'bg-blue-50/70',
      border: 'border-blue-200',
      text: 'text-blue-900',
      accent: 'blue',
    },
    miniQuiz: {
      question: 'Nebuď hlučný, dítě ______.',
      options: [
        { text: 'sleeps', correct: false, explanation: 'Ne. Dítě spí v tuto chvíli, nejde o obecné konstatování.' },
        { text: 'is sleeping', correct: true, explanation: 'Výborně! Děj se odehrává právě v tento okamžik promluvy.' },
      ],
    },
  },
  {
    id: 'present-perfect',
    name: 'Present Perfect Simple',
    nameCz: 'Předpřítomný prostý čas',
    category: 'present',
    shortDesc: 'Děj začal v minulosti, ale má přímý NÁSLEDEK nebo SPOJENÍ s přítomností.',
    detailedDesc: 'Tento čas spojuje minulost s přítomností. Používáme ho pro životní zkušenosti (bez udání času), nedávné děje s následkem v přítomnosti nebo děje trvající doteď.',
    formula: {
      positive: 'S + have / has + 3. tvar slovesa (-ed / příčestí minulá)',
      negative: 'S + haven\'t / hasn\'t + 3. tvar slovesa',
      question: 'Have / Has + S + 3. tvar slovesa?',
    },
    signalWords: ['just', 'already', 'yet', 'ever', 'never', 'since', 'for', 'recently'],
    examples: [
      { en: 'I have lost my keys!', cz: 'Ztratil jsem klíče! (A TEĎ nemůžu domů)', type: 'positive' },
      { en: 'Have you ever been to Paris?', cz: 'Byl jsi někdy v Paříži? (Životní zkušenost)', type: 'question' },
      { en: 'They haven\'t finished their homework yet.', cz: 'Ještě nedokončili domácí úkol.', type: 'negative' },
    ],
    colorTheme: {
      badge: 'bg-purple-100 text-purple-800 border-purple-300',
      bg: 'bg-purple-50/70',
      border: 'border-purple-200',
      text: 'text-purple-900',
      accent: 'purple',
    },
    miniQuiz: {
      question: 'Au! ______ jsem se do prstu!',
      options: [
        { text: 'I cut', correct: false, explanation: 'Pokud říkáš "Au!" právě teď, děj má živý přítomný následek.' },
        { text: 'I have cut', correct: true, explanation: 'Skvěle! Minulý děj má jasný následek v přítomnosti (krvácí/bolí).' },
      ],
    },
  },
  {
    id: 'present-perfect-continuous',
    name: 'Present Perfect Continuous',
    nameCz: 'Předpřítomný průběhový čas',
    category: 'present',
    shortDesc: 'Zdůrazňuje DÉLKU TRVÁNÍ nebo průběh děje, který začal v minulosti a stále probíhá nebo právě skončil.',
    detailedDesc: 'Často odpovídá na otázku "How long...?". Děj trval delší dobu nepřetržitě doteď (např. "Učím se 3 hodiny"). Viditelný je i fyzický výsledek (zpocený, unavený).',
    formula: {
      positive: 'S + have / has been + sloveso-ing',
      negative: 'S + haven\'t / hasn\'t been + sloveso-ing',
      question: 'Have / Has + S + been + sloveso-ing?',
    },
    signalWords: ['for 2 hours', 'since morning', 'how long', 'all day'],
    examples: [
      { en: 'I have been studying for 3 hours.', cz: 'Učím se už 3 hodiny. (A stále pokračuji)', type: 'positive' },
      { en: 'She is out of breath because she has been running.', cz: 'Nemůže popadnout dech, protože běžela. (Průběh zanechal následek)', type: 'positive' },
    ],
    colorTheme: {
      badge: 'bg-indigo-100 text-indigo-800 border-indigo-300',
      bg: 'bg-indigo-50/70',
      border: 'border-indigo-200',
      text: 'text-indigo-900',
      accent: 'indigo',
    },
    miniQuiz: {
      question: 'Je unavená, protože ______ celý den.',
      options: [
        { text: 'worked', correct: false, explanation: 'Past simple nezdůrazňuje neustálý průběh vedoucí k současné únavě.' },
        { text: 'has been working', correct: true, explanation: 'Správně! Průběh akce zanechal současnou únavu.' },
      ],
    },
  },

  // --- PAST TENSES ---
  {
    id: 'past-simple',
    name: 'Past Simple',
    nameCz: 'Minulý prostý čas',
    category: 'past',
    shortDesc: 'Ukončený děj v ukončeném čase v minulosti. Tečka na časové ose.',
    detailedDesc: 'Používá se pro události, které začaly i skončily v minulosti v konkrétní určený čas (včera, vloni, v roce 2010). Často v sérii po sobě jdoucích kroků.',
    formula: {
      positive: 'S + 2. tvar slovesa (-ed / nepravidelná slovesa)',
      negative: 'S + did not + základní sloveso',
      question: 'Did + S + základní sloveso?',
    },
    signalWords: ['yesterday', 'last year', '2 days ago', 'in 2015', 'when I was young'],
    examples: [
      { en: 'I visited Paris in 2019.', cz: 'V roce 2019 jsem navštívil Paříž.', type: 'positive' },
      { en: 'He opened the door, stepped inside and sat down.', cz: 'Otevřel dveře, vstoupil dovnitř a posadil se. (Série kroků)', type: 'positive' },
      { en: 'Did you see the match yesterday?', cz: 'Viděl jsi včera ten zápas?', type: 'question' },
    ],
    colorTheme: {
      badge: 'bg-rose-100 text-rose-800 border-rose-300',
      bg: 'bg-rose-50/70',
      border: 'border-rose-200',
      text: 'text-rose-900',
      accent: 'rose',
    },
    miniQuiz: {
      question: 'Kdy ______ ten dům?',
      options: [
        { text: 'have they built', correct: false, explanation: 'U otázky "When" zjišťujeme konkrétní čas v minulosti, použije se Past Simple.' },
        { text: 'did they build', correct: true, explanation: 'Správně! Otázka "When?" směřuje na konkrétní minulé datum/období.' },
      ],
    },
  },
  {
    id: 'past-continuous',
    name: 'Past Continuous',
    nameCz: 'Minulý průběhový čas',
    category: 'past',
    shortDesc: 'Děj probíhající v přesně stanovený moment v minulosti nebo pozadí příběhu.',
    detailedDesc: 'Popisuje děj, který delší dobu probíhal v minulosti ("v 8 hodin jsem se díval na TV"). Často tvoří scénu, do které vpadne kratší minula akce.',
    formula: {
      positive: 'S + was / were + sloveso-ing',
      negative: 'S + wasn\'t / weren\'t + sloveso-ing',
      question: 'Was / Were + S + sloveso-ing?',
    },
    signalWords: ['while', 'when (u přerušení)', 'at 8 PM yesterday', 'all night'],
    examples: [
      { en: 'I was sleeping when the alarm went off.', cz: 'Spal jsem (dlouhá akce), když zazvonil budík (krátká akce).', type: 'positive' },
      { en: 'While she was cooking, I was reading.', cz: 'Zatímco ona vařila, já jsem si četl. (Dvě paralelní akce)', type: 'positive' },
    ],
    colorTheme: {
      badge: 'bg-amber-100 text-amber-800 border-amber-300',
      bg: 'bg-amber-50/70',
      border: 'border-amber-200',
      text: 'text-amber-900',
      accent: 'amber',
    },
    miniQuiz: {
      question: 'Když jsem spal, někdo ______ okno.',
      options: [
        { text: 'was breaking', correct: false, explanation: 'Nerozbíjel ho dlouze celou dobu, rozbití byla rychlá událost.' },
        { text: 'broke', correct: true, explanation: 'Výborně! Rychlý minulý děj přerušil váš trvající spánek.' },
      ],
    },
  },
  {
    id: 'past-perfect',
    name: 'Past Perfect',
    nameCz: 'Předminulý prostý čas',
    category: 'past',
    shortDesc: 'Děj, který se stal JEŠTĚ PŘED jiným minulým dějem ("minulost v minulosti").',
    detailedDesc: 'Slouží k uspořádání časové posloupnosti v minulosti. Událost v Past Perfect se odehrála dříve než událost v Past Simple.',
    formula: {
      positive: 'S + had + 3. tvar slovesa',
      negative: 'S + hadn\'t + 3. tvar slovesa',
      question: 'Had + S + 3. tvar slovesa?',
    },
    signalWords: ['by the time', 'already', 'before', 'after', 'because'],
    examples: [
      { en: 'When I arrived at the station, the train had already left.', cz: 'Když jsem dorazil na nádraží, vlak už odjel. (Vlak odjel DŘÍVE)', type: 'positive' },
    ],
    colorTheme: {
      badge: 'bg-red-100 text-red-800 border-red-300',
      bg: 'bg-red-50/70',
      border: 'border-red-200',
      text: 'text-red-900',
      accent: 'red',
    },
    miniQuiz: {
      question: 'Když jsme přišli do kina, film už ______.',
      options: [
        { text: 'started', correct: false, explanation: 'Děj začal PŘED naším příchodem, vyžaduje Past Perfect.' },
        { text: 'had started', correct: true, explanation: 'Přesně tak! Film začal ještě dříve, než jsme dorazili.' },
      ],
    },
  },

  // --- FUTURE TENSES ---
  {
    id: 'future-simple',
    name: 'Future Simple (Will)',
    nameCz: 'Budoucí prostý čas (Will)',
    category: 'future',
    shortDesc: 'Spontánní rozhodnutí TEĎ, sliby, nabídky a nepodložené předpovědi.',
    detailedDesc: 'Tento čas volíme pro akce, pro které jsme se rozhodli v momentě mluvy (bez předchozího plánu), pro sliby, nabídky pomoci nebo osobní odhady ("myslím, že...").',
    formula: {
      positive: 'S + will + základní sloveso',
      negative: 'S + won\'t (will not) + základní sloveso',
      question: 'Will + S + základní sloveso?',
    },
    signalWords: ['spontaneous decision', 'I think', 'I promise', 'maybe', 'perhaps', 'probably'],
    examples: [
      { en: 'Někdo zvoní! - I will get it.', cz: 'Někdo zvoní! - Já tam dojdu. (Okamžité rozhodnutí)', type: 'positive' },
      { en: 'I promise I won\'t tell anyone.', cz: 'Slibuji, že to nikomu neřeknu.', type: 'negative' },
    ],
    colorTheme: {
      badge: 'bg-yellow-100 text-yellow-800 border-yellow-300',
      bg: 'bg-yellow-50/70',
      border: 'border-yellow-200',
      text: 'text-yellow-900',
      accent: 'yellow',
    },
    miniQuiz: {
      question: 'Někdo zvoní u dveří! Já tam ______.',
      options: [
        { text: 'will go', correct: true, explanation: 'Správně! Spontánní rozhodnutí v momentě promluvy.' },
        { text: 'am going to go', correct: false, explanation: 'Ne. Zvonění přišlo nečekaně, neměl jsi to naplánováno dopředu.' },
      ],
    },
  },
  {
    id: 'future-going-to',
    name: 'Going to',
    nameCz: 'Vazba Going to (Plány)',
    category: 'future',
    shortDesc: 'Předem promyšlené PLÁNY a ZÁMĚRY nebo předpovědi s viditelným důkazem.',
    detailedDesc: 'Používáme, když jsme o akci přemýšleli již DŘÍVE a udělali jsme vědomé rozhodnutí, nebo když v současnosti vidíme jasný důkaz (např. tmavé mraky na obloze).',
    formula: {
      positive: 'S + am / is / are + going to + základní sloveso',
      negative: 'S + am not / isn\'t / aren\'t + going to + sloveso',
      question: 'Am / Is / Are + S + going to + sloveso?',
    },
    signalWords: ['plan', 'intend to', 'decided to', 'Look at those...'],
    examples: [
      { en: 'I am going to buy a new car next month.', cz: 'Příští měsíc se chystám koupit nové auto. (Už jsem se rozhodl)', type: 'positive' },
      { en: 'Look at those dark clouds! It is going to rain.', cz: 'Podívej na ty tmavé mraky! Bude pršet. (Důkaz viditelný teď)', type: 'positive' },
    ],
    colorTheme: {
      badge: 'bg-orange-100 text-orange-800 border-orange-300',
      bg: 'bg-orange-50/70',
      border: 'border-orange-200',
      text: 'text-orange-900',
      accent: 'orange',
    },
    miniQuiz: {
      question: 'Podívej na ty černé mraky na obloze! ______ pršet.',
      options: [
        { text: 'It will rain', correct: false, explanation: 'Pokud máme jasný vizuální důkaz na obloze, dáváme přednost "going to".' },
        { text: 'It is going to rain', correct: true, explanation: 'Výborně! Přítomný důkaz (černé mraky) jasně ukazuje na "going to".' },
      ],
    },
  },
  {
    id: 'future-continuous',
    name: 'Future Continuous',
    nameCz: 'Budoucí průběhový čas',
    category: 'future',
    shortDesc: 'Děj, který bude PROBÍHAT v konkrétní určený moment v budoucnosti.',
    detailedDesc: 'Představuje průběhovou akci v budoucnosti ("Zítra o tomto čase budu ležet na pláži").',
    formula: {
      positive: 'S + will be + sloveso-ing',
      negative: 'S + won\'t be + sloveso-ing',
      question: 'Will + S + be + sloveso-ing?',
    },
    signalWords: ['this time tomorrow', 'at 5 PM next Friday', 'this time next week'],
    examples: [
      { en: 'This time next week, I will be lying on a beach.', cz: 'Tento čas příští týden budu ležet na pláži.', type: 'positive' },
    ],
    colorTheme: {
      badge: 'bg-teal-100 text-teal-800 border-teal-300',
      bg: 'bg-teal-50/70',
      border: 'border-teal-200',
      text: 'text-teal-900',
      accent: 'teal',
    },
    miniQuiz: {
      question: 'Zítra v 10 ráno ______ ve letadle.',
      options: [
        { text: 'will sit', correct: false, explanation: 'Děj bude v ten přesný čas probíhat (průběhovost).' },
        { text: 'will be sitting', correct: true, explanation: 'Správně! Akce bude v přesný okamžik v budoucnosti probíhat.' },
      ],
    },
  },
];
