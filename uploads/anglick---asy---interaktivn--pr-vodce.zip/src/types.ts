export type TenseCategory = 'all' | 'present' | 'past' | 'future' | 'advanced';

export interface Question {
  id: string;
  q: string;
  options: string[];
  answer: number;
  explanation: string;
  category: TenseCategory;
  difficulty?: 'easy' | 'medium' | 'hard';
}

export interface ExampleSentence {
  en: string;
  cz: string;
  type?: 'positive' | 'negative' | 'question';
}

export interface TenseDetail {
  id: string;
  name: string;
  nameCz: string;
  category: 'present' | 'past' | 'future';
  shortDesc: string;
  detailedDesc: string;
  formula: {
    positive: string;
    negative: string;
    question: string;
  };
  signalWords: string[];
  examples: ExampleSentence[];
  colorTheme: {
    badge: string;
    bg: string;
    border: string;
    text: string;
    accent: string;
  };
  miniQuiz: {
    question: string;
    options: { text: string; correct: boolean; explanation: string }[];
  };
}

export interface TimeMachinePoint {
  min: number;
  max: number;
  tenseId: string;
  name: string;
  sentenceEn: string;
  sentenceCz: string;
  context: string;
  signalWords: string[];
  color: string;
  bg: string;
  border: string;
}

export interface QuizResult {
  id: string;
  date: string;
  score: number;
  totalQuestions: number;
  category: TenseCategory;
  percentage: number;
  timeSpentSeconds: number;
}

export interface AiExplanationResult {
  tenseName: string;
  explanation: string;
  formula: string;
  signalWords: string[];
  examples: ExampleSentence[];
  commonMistakes: string;
}
