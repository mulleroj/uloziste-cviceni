import React, { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { TimeMachineSection } from './components/TimeMachineSection';
import { TheorySection } from './components/TheorySection';
import { QuizSection } from './components/QuizSection';
import { AiAssistantSection } from './components/AiAssistantSection';
import { StatsSection } from './components/StatsSection';
import { ShareModal } from './components/ShareModal';
import { QuizResult } from './types';
import { Clock, BookOpen, Award, Sparkles, Heart } from 'lucide-react';

export default function App() {
  const [activeSection, setActiveSection] = useState<'timeline' | 'theory' | 'test' | 'ai' | 'stats'>('timeline');
  const [selectedTenseId, setSelectedTenseId] = useState<string | undefined>(undefined);
  const [shareModalOpen, setShareModalOpen] = useState<boolean>(false);
  const [quizHistory, setQuizHistory] = useState<QuizResult[]>([]);

  // Load saved quiz results from localStorage
  useEffect(() => {
    try {
      const saved = localStorage.getItem('english_tenses_quiz_history');
      if (saved) {
        setQuizHistory(JSON.parse(saved));
      }
    } catch (e) {
      console.error('Failed to parse localStorage history:', e);
    }
  }, []);

  const handleQuizFinished = (newResult: QuizResult) => {
    const updated = [newResult, ...quizHistory];
    setQuizHistory(updated);
    try {
      localStorage.setItem('english_tenses_quiz_history', JSON.stringify(updated));
    } catch (e) {
      console.error('Failed to save quiz history:', e);
    }
  };

  const handleClearStats = () => {
    if (confirm('Opravdu chcete smazat veškerou historii výsledků?')) {
      setQuizHistory([]);
      try {
        localStorage.removeItem('english_tenses_quiz_history');
      } catch (e) {
        console.error('Failed to clear history:', e);
      }
    }
  };

  const handleGoToTheoryWithTense = (tenseId?: string) => {
    setSelectedTenseId(tenseId);
    setActiveSection('theory');
  };

  return (
    <div className="min-h-screen bg-[#09090b] text-zinc-100 flex flex-col font-sans selection:bg-indigo-500/30 selection:text-indigo-200">
      {/* Navigation Header */}
      <Header
        activeSection={activeSection}
        onNavigate={(sec) => setActiveSection(sec)}
        onOpenShareModal={() => setShareModalOpen(true)}
      />

      {/* Main Content Viewport */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-10">
        {activeSection === 'timeline' && (
          <TimeMachineSection
            onGoToTest={() => setActiveSection('test')}
            onGoToTheory={handleGoToTheoryWithTense}
          />
        )}

        {activeSection === 'theory' && (
          <TheorySection
            initialTenseId={selectedTenseId}
            onGoToTest={() => setActiveSection('test')}
          />
        )}

        {activeSection === 'test' && (
          <QuizSection
            onQuizFinished={handleQuizFinished}
            onGoToTheory={() => setActiveSection('theory')}
          />
        )}

        {activeSection === 'ai' && <AiAssistantSection />}

        {activeSection === 'stats' && (
          <StatsSection
            quizHistory={quizHistory}
            onClearStats={handleClearStats}
            onGoToTest={() => setActiveSection('test')}
          />
        )}
      </main>

      {/* Share QR Modal */}
      <ShareModal isOpen={shareModalOpen} onClose={() => setShareModalOpen(false)} />

      {/* Footer */}
    </div>
  );
}
