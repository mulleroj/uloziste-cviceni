import { AiExplanationResult } from '../types';

interface TenseKnowledge {
  id: string;
  name: string;
  nameCz: string;
  formula: string;
  explanation: string;
  signalWords: string[];
  examples: { en: string; cz: string }[];
  commonMistakes: string;
  keywords: string[];
  grammarPatterns: RegExp[];
}

const KNOWLEDGE_BASE: TenseKnowledge[] = [
  {
    id: 'present-simple',
    name: 'Present Simple (Přítomný prostý čas)',
    nameCz: 'Přítomný prostý čas',
    formula: 'Klad: Subjekt + sloveso (+ s/es pro he/she/it) | Zápor: S + do not / does not + V | Otázka: Do / Does + S + V?',
    explanation: 'Vyjadřuje opakováné děje, zvyky, stálé pravdy, jízdní řády nebo fakta, které platí všeobecně a nikoli výhradně v tuto jedinou vteřinu.',
    signalWords: ['always', 'usually', 'often', 'sometimes', 'every day', 'never', 'on Mondays', 'normally', 'seldom'],
    examples: [
      { en: 'I study English every day.', cz: 'Učím se anglicky každý den. (Pravidelný zvyk)' },
      { en: 'He does not play tennis on Sundays.', cz: 'On v neděli nehraje tenis.' },
      { en: 'Do you work in Prague?', cz: 'Pracuješ v Praze?' },
    ],
    commonMistakes: 'Častou chybou je zapomínání koncovky "-s" ve 3. osobě (he plays, she works) nebo pletení s průběhovým časem u dějů, které jsou zvykem.',
    keywords: ['present simple', 'prostý', 'zvyk', 'fakt', 'opakovaný', 'always', 'usually', 'every'],
    grammarPatterns: [
      /\b(always|usually|often|sometimes|never|every\s+\w+)\b/i,
      /\b(do|does|don't|doesn't)\b/i,
      /\b(boils|works|lives|drives|speaks|likes|runs|plays|studies|goes)\b/i,
    ],
  },
  {
    id: 'present-continuous',
    name: 'Present Continuous (Přítomný průběhový čas)',
    nameCz: 'Přítomný průběhový čas',
    formula: 'Klad: S + am / is / are + sloveso-ing | Zápor: S + am not / isn\'t / aren\'t + V-ing | Otázka: Am / Is / Are + S + V-ing?',
    explanation: 'Používá se pro akce probíhající PRÁVĚ TEĎ v momentě promluvy, dočasné situace v tomto období, nebo pevně naplánovanou budoucnost.',
    signalWords: ['now', 'right now', 'at the moment', 'currently', 'today', 'this week', 'Look!', 'Listen!'],
    examples: [
      { en: 'I am reading an interesting book right now.', cz: 'Právě teď čtu zajímavou knihu.' },
      { en: 'Look! It is raining outside.', cz: 'Koukej! Venku prší.' },
      { en: 'Are you listening to music?', cz: 'Posloucháš hudbu?' },
    ],
    commonMistakes: 'Použití průběhového tvaru u stavových sloves (např. "I am wanting" je chyba, správně je "I want"). Chybějící pomocné sloveso "be" (např. "He working" místo "He is working").',
    keywords: ['present continuous', 'průběhový', 'právě teď', 'moment', 'now', 'ing', 'dnes'],
    grammarPatterns: [
      /\b(am|is|are|isn't|aren't)\s+\w+ing\b/i,
      /\b(right now|at the moment|look!|listen!)\b/i,
    ],
  },
  {
    id: 'present-perfect',
    name: 'Present Perfect Simple (Předpřítomný prostý čas)',
    nameCz: 'Předpřítomný prostý čas',
    formula: 'Klad: S + have / has + 3. tvar (příčestí minulé) | Zápor: S + haven\'t / hasn\'t + 3. tvar | Otázka: Have / Has + S + 3. tvar?',
    explanation: 'Propojuje minulost s přítomností. Vyjadřuje děj, který se stal v nedefinované minulosti a má přímý dopad/následek teď, nebo životní zkušenost ("už jsem někdy...").',
    signalWords: ['just', 'already', 'yet', 'ever', 'never', 'since', 'for', 'recently', 'so far'],
    examples: [
      { en: 'I have lost my wallet.', cz: 'Ztratil jsem peněženku. (Důsledek: Nemám ji teď u sebe)' },
      { en: 'She has already finished her work.', cz: 'Ona už svou práci dokončila.' },
      { en: 'Have you ever been to London?', cz: 'Byl jsi někdy v Londýně?' },
    ],
    commonMistakes: 'Použití předpřítomného času s konkrétním časovým údajem v minulosti (např. "I have seen him yesterday" je chyba, správně je "I saw him yesterday").',
    keywords: ['present perfect', 'předpřítomný', 'zkušenost', 'ztratil', 'stalo se', 'have', 'has', 'ever', 'never', 'just', 'already', 'yet'],
    grammarPatterns: [
      /\b(have|has|haven't|hasn't)\s+(\w+ed|\w+en|lost|been|done|seen|gone|written|bought|broken|found)\b/i,
      /\b(ever|never|already|just|yet|since|for\s+\d+)\b/i,
    ],
  },
  {
    id: 'past-simple',
    name: 'Past Simple (Minulý prostý čas)',
    nameCz: 'Minulý prostý čas',
    formula: 'Klad: S + 2. tvar slovesa (-ed / nepravidelné) | Zápor: S + did not + základní tvar | Otázka: Did + S + základní tvar?',
    explanation: 'Vyjadřuje ukončený děj v konkrétním čase v minulosti. Čas je buď výslovně uveden (yesterday, last year, in 2020), nebo vyplývá z kontextu.',
    signalWords: ['yesterday', 'ago', 'last week', 'in 2010', 'when I was young', 'then'],
    examples: [
      { en: 'We visited Paris last year.', cz: 'Minulý rok jsme navštívili Paříž.' },
      { en: 'He didn\'t come to the meeting yesterday.', cz: 'On včera nepřišel na schůzku.' },
      { en: 'Did you see that movie?', cz: 'Viděl jsi ten film?' },
    ],
    commonMistakes: 'Dávání minulého tvaru po záporech a otázkách s "did" (např. "Did you went?" je chyba, správně je "Did you go?").',
    keywords: ['past simple', 'minulý', 'prostý', 'yesterday', 'ago', 'last', 'včera', 'minule', 'did'],
    grammarPatterns: [
      /\b(yesterday|ago|last\s+\w+|in\s+19\d\d|in\s+20\d\d)\b/i,
      /\b(did|didn't)\b/i,
      /\b(\w+ed|went|saw|came|bought|wrote|took|made|found|had|was|were)\b/i,
    ],
  },
  {
    id: 'past-continuous',
    name: 'Past Continuous (Minulý průběhový čas)',
    nameCz: 'Minulý průběhový čas',
    formula: 'Klad: S + was / were + V-ing | Zápor: S + wasn\'t / weren\'t + V-ing | Otázka: Was / Were + S + V-ing?',
    explanation: 'Vyjadřuje děj, který probíhal neustále v určitou dobu v minulosti, nebo vytvářel pozadí, když do něj vstoupil jiný jednorázový děj (v minulém prostém).',
    signalWords: ['while', 'as', 'when', 'at 5 PM yesterday', 'all morning', 'all day'],
    examples: [
      { en: 'I was sleeping when the phone rang.', cz: 'Spal jsem, když telefon zazvonil.' },
      { en: 'They were watching TV all evening.', cz: 'Sledovali televizi celé odpoledne.' },
      { en: 'What were you doing at 8 o\'clock?', cz: 'Co jsi dělal v 8 hodin?' },
    ],
    commonMistakes: 'Použití "was" u množného čísla (správně "they WERE watching") nebo zapomínání tvaru -ing.',
    keywords: ['past continuous', 'minulý průběhový', 'while', 'was', 'were', 'když v tom', 'probíhal'],
    grammarPatterns: [
      /\b(was|were|wasn't|weren't)\s+\w+ing\b/i,
      /\b(while\s+i|while\s+he|while\s+she|while\s+they)\b/i,
    ],
  },
  {
    id: 'future-simple',
    name: 'Future Simple (Budoucí čas s WILL)',
    nameCz: 'Budoucí prostý čas (Will)',
    formula: 'Klad: S + will + základní tvar | Zápor: S + won\'t + základní tvar | Otázka: Will + S + základní tvar?',
    explanation: 'Používá se pro spontánní rozhodnutí v momentě promluvy ("Pomůžu ti!"), předpovědi bez přímých důkazů nebo sliby a nabídky.',
    signalWords: ['tomorrow', 'next week', 'I think', 'probably', 'maybe', 'I promise', 'I hope'],
    examples: [
      { en: 'I think it will rain tomorrow.', cz: 'Myslím, že zítra bude pršet. (Předpověď/Názor)' },
      { en: 'Don\'t worry, I will help you with that.', cz: 'Neboj se, pomůžu ti s tím. (Spontánní nabídka)' },
      { en: 'Will you call me later?', cz: 'Zavoláš mi později?' },
    ],
    commonMistakes: 'Používání "will" pro promyšlené a předem naplánované akce (tam patří "going to").',
    keywords: ['future simple', 'will', 'won\'t', 'spontánní', 'slib', 'zítra', 'myslím že', 'promise'],
    grammarPatterns: [
      /\b(will|won't|'ll)\b/i,
      /\b(i think|probably|maybe|i promise)\b/i,
    ],
  },
  {
    id: 'going-to',
    name: 'Going to (Plánovaná budoucnost)',
    nameCz: 'Vazba going to',
    formula: 'Klad: S + am / is / are + going to + základní tvar | Zápor: S + am not / isn\'t / aren\'t + going to + V | Otázka: Am / Is / Are + S + going to + V?',
    explanation: 'Vyjadřuje předem promyšlený záměr či plán ("Mám v úmyslu...") nebo jasnou předpověď založenou na viditelném důkazu teď v přítomnosti.',
    signalWords: ['intentions', 'plans', 'Look at those clouds!', 'soon', 'this weekend'],
    examples: [
      { en: 'I am going to buy a new car next month.', cz: 'Příští měsíc si chci koupit nové auto. (Naplánováno)' },
      { en: 'Look at those black clouds! It is going to rain.', cz: 'Koukej na ty černé mraky! Bude pršet. (Viditelný důkaz)' },
      { en: 'Are you going to study medicine?', cz: 'Chystáš se studovat medicínu?' },
    ],
    commonMistakes: 'Vynechání slovesa "be" (např. "I going to" je chyba, správně je "I am going to").',
    keywords: ['going to', 'plán', 'chystám se', 'záměr', 'důkaz', 'gonna'],
    grammarPatterns: [
      /\b(am|is|are|isn't|aren't)\s+going\s+to\b/i,
      /\bgonna\b/i,
    ],
  },
];

export function analyzeSentenceOffline(
  text: string,
  tenseContext?: string
): AiExplanationResult {
  const cleanInput = text.trim();
  const lowerInput = cleanInput.toLowerCase();

  // If user selected a specific tense context, try to match it first
  let selectedKnowledge: TenseKnowledge | null = null;

  if (tenseContext) {
    selectedKnowledge =
      KNOWLEDGE_BASE.find((k) => k.name.toLowerCase().includes(tenseContext.toLowerCase())) ||
      null;
  }

  // If no specific context or not matched, score each tense
  if (!selectedKnowledge) {
    let bestScore = -1;
    KNOWLEDGE_BASE.forEach((k) => {
      let score = 0;

      // Keyword matches
      k.keywords.forEach((kw) => {
        if (lowerInput.includes(kw)) score += 3;
      });

      // Regex pattern matches
      k.grammarPatterns.forEach((pat) => {
        if (pat.test(lowerInput)) score += 5;
      });

      if (score > bestScore) {
        bestScore = score;
        selectedKnowledge = k;
      }
    });
  }

  // Fallback if no specific score matched
  if (!selectedKnowledge || bestScoreMatchedIsZero(cleanInput, selectedKnowledge)) {
    // Default to a helpful general grammar breakdown
    selectedKnowledge = KNOWLEDGE_BASE[0]; // Present Simple default or auto-detected
  }

  // Construct customized examples based on input text if it's an English sentence
  const isEnglishSentence = /[a-zA-Z]{3,}/.test(cleanInput) && cleanInput.split(' ').length >= 2;

  const resultExamples = isEnglishSentence
    ? [
        { en: cleanInput, cz: `Analýza věty: "${cleanInput}"` },
        ...selectedKnowledge.examples.slice(0, 2),
      ]
    : selectedKnowledge.examples;

  return {
    tenseName: selectedKnowledge.name,
    explanation: selectedKnowledge.explanation,
    formula: selectedKnowledge.formula,
    signalWords: selectedKnowledge.signalWords,
    examples: resultExamples,
    commonMistakes: selectedKnowledge.commonMistakes,
  };
}

function bestScoreMatchedIsZero(input: string, k: TenseKnowledge): boolean {
  const lower = input.toLowerCase();
  const hasKeyword = k.keywords.some((kw) => lower.includes(kw));
  const hasPattern = k.grammarPatterns.some((pat) => pat.test(lower));
  return !hasKeyword && !hasPattern;
}
