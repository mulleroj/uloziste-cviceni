import React, { useState } from 'react';
import { Sparkles, Send, Volume2, BookOpen, AlertCircle, Loader2, WifiOff } from 'lucide-react';
import { AiExplanationResult } from '../types';
import { speakEnglishSentence } from '../utils/speech';
import { analyzeSentenceOffline } from '../utils/offlineAnalyzer';

export const AiAssistantSection: React.FC = () => {
  const [inputText, setInputText] = useState<string>('');
  const [tenseContext, setTenseContext] = useState<string>('');
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [aiResult, setAiResult] = useState<AiExplanationResult | null>(null);

  const handleAnalyze = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim()) return;

    setLoading(true);
    setError(null);

    // Instant offline local processing
    setTimeout(() => {
      try {
        const result = analyzeSentenceOffline(inputText, tenseContext);
        setAiResult(result);
      } catch (err: any) {
        console.error('Offline analyzer error:', err);
        setError('Došlo k chybě při lokální analýze.');
      } finally {
        setLoading(false);
      }
    }, 250);
  };

  const handleSpeak = (text: string) => {
    speakEnglishSentence(text);
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      {/* Header */}
      <div className="text-center space-y-3 max-w-2xl mx-auto">
        <div className="inline-flex items-center space-x-2 px-4 py-1.5 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 text-xs font-bold uppercase tracking-widest">
          <WifiOff className="w-4 h-4 text-emerald-400" />
          <span>100% Offline Engine • Bez API</span>
        </div>
        <h2 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight">Lokální Gramatický Asistent & Rozbor Vět</h2>
        <p className="text-slate-400 text-sm sm:text-base leading-relaxed">
          Zadejte libovolnou anglickou nebo českou větu, popište situaci nebo se zeptejte na gramatické pravidlo.
          Aplikace provede okamžitou offline analýzu.
        </p>
      </div>

      {/* Input Form Card */}
      <div className="bg-[#18181b] rounded-3xl shadow-xl p-6 sm:p-8 border border-zinc-800 space-y-5">
        <form onSubmit={handleAnalyze} className="space-y-4">
          <div>
            <label className="text-xs font-bold uppercase tracking-widest text-slate-400 block mb-2">
              Zadejte větu nebo dotaz:
            </label>
            <input
              type="text"
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              placeholder="Např. 'I have been living in Prague for 5 years' nebo 'Rozdíl mezi will a going to'"
              className="w-full p-4 rounded-2xl bg-[#09090b] border border-zinc-800 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 text-white placeholder-zinc-500 text-sm font-medium transition"
            />
          </div>

          <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="w-full sm:w-auto">
              <select
                value={tenseContext}
                onChange={(e) => setTenseContext(e.target.value)}
                className="w-full sm:w-auto px-4 py-3 rounded-2xl bg-[#09090b] border border-zinc-800 text-xs font-semibold text-zinc-300 focus:ring-2 focus:ring-indigo-500"
              >
                <option value="">Všechny časy (Automatická detekce)</option>
                <option value="Present Simple">Present Simple</option>
                <option value="Present Continuous">Present Continuous</option>
                <option value="Present Perfect">Present Perfect</option>
                <option value="Past Simple">Past Simple</option>
                <option value="Past Continuous">Past Continuous</option>
                <option value="Future Simple (Will)">Future Simple (Will)</option>
                <option value="Going to">Going to</option>
              </select>
            </div>

            <button
              type="submit"
              disabled={loading || !inputText.trim()}
              className={`w-full sm:w-auto px-8 py-3.5 rounded-2xl font-bold text-sm text-white transition flex items-center justify-center space-x-2 shadow-lg border border-indigo-400/30 ${
                loading || !inputText.trim()
                  ? 'bg-zinc-800 text-zinc-500 cursor-not-allowed border-zinc-800'
                  : 'bg-gradient-to-r from-indigo-500 to-purple-600 hover:from-indigo-600 hover:to-purple-700 shadow-indigo-500/30'
              }`}
            >
              {loading ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>Provádím analýzu...</span>
                </>
              ) : (
                <>
                  <Send className="w-4 h-4" />
                  <span>Analýza pomocí AI</span>
                </>
              )}
            </button>
          </div>
        </form>

        {/* Quick sample prompts */}
        <div className="pt-2">
          <span className="text-xs font-semibold text-slate-400 block mb-2">Rychlé příklady k vyzkoušení:</span>
          <div className="flex flex-wrap gap-2">
            {[
              'I have lost my wallet.',
              'I was reading a book when the phone rang.',
              'Look at those dark clouds! It is going to rain.',
              'I will call you as soon as I arrive.',
            ].map((sample) => (
              <button
                key={sample}
                onClick={() => setInputText(sample)}
                className="text-xs font-medium px-3 py-1.5 bg-[#09090b] hover:bg-zinc-800 hover:text-white rounded-xl text-zinc-400 transition border border-zinc-800"
              >
                "{sample}"
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Error display */}
      {error && (
        <div className="p-4 rounded-2xl bg-rose-950/80 border border-rose-800/80 text-rose-200 text-sm font-medium flex items-center space-x-2">
          <AlertCircle className="w-5 h-5 text-rose-400 shrink-0" />
          <span>{error}</span>
        </div>
      )}

      {/* AI Result Card */}
      {aiResult && (
        <div className="bg-[#18181b] rounded-3xl shadow-xl p-6 sm:p-8 border border-zinc-800 space-y-6 animate-fadeIn">
          <div className="border-b border-zinc-800 pb-4 flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="p-3 rounded-2xl bg-indigo-500/10 text-indigo-400 border border-indigo-500/20 font-bold">
                <BookOpen className="w-5 h-5" />
              </div>
              <div>
                <span className="text-xs font-bold text-slate-400 uppercase tracking-widest block">
                  Určený čas
                </span>
                <h3 className="text-xl font-bold text-white mt-0.5">{aiResult.tenseName}</h3>
              </div>
            </div>
          </div>

          <div className="space-y-5">
            <div>
              <h4 className="text-xs font-bold uppercase tracking-widest text-slate-400 mb-2">
                Vysvětlení použití:
              </h4>
              <p className="text-sm sm:text-base text-zinc-200 leading-relaxed font-medium bg-[#09090b] p-4.5 rounded-2xl border border-zinc-800">
                {aiResult.explanation}
              </p>
            </div>

            {aiResult.formula && (
              <div>
                <h4 className="text-xs font-bold uppercase tracking-widest text-slate-400 mb-2">
                  Gramatický vzorec:
                </h4>
                <div className="bg-[#09090b] text-indigo-300 p-4 rounded-2xl font-mono text-xs font-bold border border-zinc-800">
                  {aiResult.formula}
                </div>
              </div>
            )}

            {aiResult.signalWords && aiResult.signalWords.length > 0 && (
              <div>
                <h4 className="text-xs font-bold uppercase tracking-widest text-slate-400 mb-2">
                  Typická signalizační slovíčka:
                </h4>
                <div className="flex flex-wrap gap-2">
                  {aiResult.signalWords.map((word) => (
                    <span
                      key={word}
                      className="px-3 py-1 rounded-xl bg-zinc-800 text-indigo-300 text-xs font-semibold border border-zinc-700/60"
                    >
                      {word}
                    </span>
                  ))}
                </div>
              </div>
            )}

            {aiResult.examples && aiResult.examples.length > 0 && (
              <div>
                <h4 className="text-xs font-bold uppercase tracking-widest text-slate-400 mb-2.5">
                  Příklady použití s výslovností:
                </h4>
                <div className="space-y-2.5">
                  {aiResult.examples.map((ex, idx) => (
                    <div
                      key={idx}
                      className="p-3.5 bg-[#09090b] rounded-2xl border border-zinc-800 flex items-center justify-between gap-3 text-xs"
                    >
                      <div>
                        <p className="font-bold text-white">{ex.en}</p>
                        <p className="text-slate-400 italic mt-0.5">{ex.cz}</p>
                      </div>
                      <button
                        onClick={() => handleSpeak(ex.en)}
                        className="p-2.5 rounded-xl bg-zinc-800 border border-zinc-700 text-indigo-400 hover:text-white hover:bg-indigo-600 transition shrink-0"
                        title="Poslechnout výslovnost"
                      >
                        <Volume2 className="w-4 h-4" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {aiResult.commonMistakes && (
              <div className="p-4.5 rounded-2xl bg-amber-950/70 border border-amber-800/80 text-amber-200 text-xs space-y-1.5">
                <div className="font-bold uppercase tracking-widest text-[11px] text-amber-300">
                  ⚠️ Časté chyby českých mluvčích:
                </div>
                <p className="leading-relaxed">{aiResult.commonMistakes}</p>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
