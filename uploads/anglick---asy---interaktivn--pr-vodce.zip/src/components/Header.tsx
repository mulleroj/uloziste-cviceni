import React, { useState } from 'react';
import { Clock, BookOpen, Award, Sparkles, Share2, BarChart2, Menu, X } from 'lucide-react';

interface HeaderProps {
  activeSection: 'timeline' | 'theory' | 'test' | 'ai' | 'stats';
  onNavigate: (section: 'timeline' | 'theory' | 'test' | 'ai' | 'stats') => void;
  onOpenShareModal: () => void;
  savedCount?: number;
}

export const Header: React.FC<HeaderProps> = ({
  activeSection,
  onNavigate,
  onOpenShareModal,
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const handleNavClick = (section: 'timeline' | 'theory' | 'test' | 'ai' | 'stats') => {
    onNavigate(section);
    setMobileMenuOpen(false);
  };

  return (
    <header className="bg-[#09090b]/90 backdrop-blur-md text-white sticky top-0 z-40 border-b border-zinc-800/80">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-20">
          {/* Logo & Branding */}
          <div
            className="flex items-center space-x-3 cursor-pointer group"
            onClick={() => handleNavClick('timeline')}
          >
            <div className="bg-indigo-500/10 p-2.5 rounded-2xl backdrop-blur-md group-hover:bg-indigo-500/20 transition-all border border-indigo-500/30">
              <Clock className="h-6 w-6 text-indigo-400 animate-spin-slow" />
            </div>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-1.5 lg:space-x-2">
            <button
              onClick={() => handleNavClick('timeline')}
              className={`px-3.5 py-2 rounded-xl font-semibold text-sm transition-all flex items-center space-x-2 ${
                activeSection === 'timeline'
                  ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/25 border border-indigo-400/30 font-bold'
                  : 'text-zinc-400 hover:bg-zinc-800/60 hover:text-white'
              }`}
            >
              <Clock className="w-4 h-4" />
              <span>Stroj času</span>
            </button>

            <button
              onClick={() => handleNavClick('theory')}
              className={`px-3.5 py-2 rounded-xl font-semibold text-sm transition-all flex items-center space-x-2 ${
                activeSection === 'theory'
                  ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/25 border border-indigo-400/30 font-bold'
                  : 'text-zinc-400 hover:bg-zinc-800/60 hover:text-white'
              }`}
            >
              <BookOpen className="w-4 h-4" />
              <span>Teorie & Rozdíly</span>
            </button>

            <button
              onClick={() => handleNavClick('test')}
              className={`px-4 py-2 rounded-xl font-bold text-sm transition-all flex items-center space-x-2 shadow-lg ${
                activeSection === 'test'
                  ? 'bg-gradient-to-r from-indigo-500 to-purple-600 text-white ring-2 ring-indigo-400/50 shadow-indigo-500/30'
                  : 'bg-zinc-800 hover:bg-zinc-700 text-white border border-zinc-700'
              }`}
            >
              <Award className="w-4 h-4 text-emerald-400" />
              <span>Spustit Test</span>
            </button>

            <button
              onClick={() => handleNavClick('ai')}
              className={`px-3.5 py-2 rounded-xl font-semibold text-sm transition-all flex items-center space-x-2 ${
                activeSection === 'ai'
                  ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/25 border border-indigo-400/30 font-bold'
                  : 'text-zinc-400 hover:bg-zinc-800/60 hover:text-white'
              }`}
            >
              <Sparkles className="w-4 h-4 text-amber-400" />
              <span>AI Rozbor</span>
            </button>

            <button
              onClick={() => handleNavClick('stats')}
              className={`px-3.5 py-2 rounded-xl font-semibold text-sm transition-all flex items-center space-x-2 ${
                activeSection === 'stats'
                  ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/25 border border-indigo-400/30 font-bold'
                  : 'text-zinc-400 hover:bg-zinc-800/60 hover:text-white'
              }`}
            >
              <BarChart2 className="w-4 h-4 text-emerald-400" />
              <span>Statistiky</span>
            </button>

            <button
              onClick={onOpenShareModal}
              title="Sdílet QR kód pro studenty"
              className="p-2.5 rounded-xl text-zinc-400 hover:text-white hover:bg-zinc-800/60 transition-colors ml-1 border border-transparent hover:border-zinc-700"
            >
              <Share2 className="w-5 h-5" />
            </button>
          </nav>

          {/* Mobile Menu Trigger */}
          <div className="md:hidden flex items-center space-x-2">
            <button
              onClick={onOpenShareModal}
              className="p-2 rounded-xl text-zinc-400 hover:text-white hover:bg-zinc-800"
              title="Sdílet"
            >
              <Share2 className="w-5 h-5" />
            </button>

            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 rounded-xl text-zinc-300 hover:bg-zinc-800 focus:outline-none border border-zinc-800"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-[#18181b] border-t border-zinc-800 px-4 pt-3 pb-4 space-y-2 animate-fadeIn">
          <button
            onClick={() => handleNavClick('timeline')}
            className={`w-full text-left px-4 py-3 rounded-xl font-semibold text-sm flex items-center space-x-3 ${
              activeSection === 'timeline' ? 'bg-indigo-600 text-white font-bold' : 'text-zinc-300 hover:bg-zinc-800'
            }`}
          >
            <Clock className="w-5 h-5 text-indigo-400" />
            <span>Stroj času & Časová osa</span>
          </button>

          <button
            onClick={() => handleNavClick('theory')}
            className={`w-full text-left px-4 py-3 rounded-xl font-semibold text-sm flex items-center space-x-3 ${
              activeSection === 'theory' ? 'bg-indigo-600 text-white font-bold' : 'text-zinc-300 hover:bg-zinc-800'
            }`}
          >
            <BookOpen className="w-5 h-5 text-indigo-400" />
            <span>Teorie & Rozdíly</span>
          </button>

          <button
            onClick={() => handleNavClick('test')}
            className={`w-full text-left px-4 py-3 rounded-xl font-bold text-sm flex items-center space-x-3 bg-gradient-to-r from-indigo-500 to-purple-600 text-white`}
          >
            <Award className="w-5 h-5 text-emerald-400" />
            <span>Spustit Test</span>
          </button>

          <button
            onClick={() => handleNavClick('ai')}
            className={`w-full text-left px-4 py-3 rounded-xl font-semibold text-sm flex items-center space-x-3 ${
              activeSection === 'ai' ? 'bg-indigo-600 text-white font-bold' : 'text-zinc-300 hover:bg-zinc-800'
            }`}
          >
            <Sparkles className="w-5 h-5 text-amber-400" />
            <span>AI Rozbor a věty</span>
          </button>

          <button
            onClick={() => handleNavClick('stats')}
            className={`w-full text-left px-4 py-3 rounded-xl font-semibold text-sm flex items-center space-x-3 ${
              activeSection === 'stats' ? 'bg-indigo-600 text-white font-bold' : 'text-zinc-300 hover:bg-zinc-800'
            }`}
          >
            <BarChart2 className="w-5 h-5 text-emerald-400" />
            <span>Moje statistiky</span>
          </button>
        </div>
      )}
    </header>
  );
};
