import React, { useState } from 'react';
import { X, Copy, Check, QrCode } from 'lucide-react';

interface ShareModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ShareModal: React.FC<ShareModalProps> = ({ isOpen, onClose }) => {
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const currentUrl = typeof window !== 'undefined' ? window.location.href : '';

  const handleCopy = async () => {
    try {
      if (navigator.clipboard) {
        await navigator.clipboard.writeText(currentUrl);
      } else {
        const textArea = document.createElement('textarea');
        textArea.value = currentUrl;
        document.body.appendChild(textArea);
        textArea.select();
        document.execCommand('copy');
        document.body.removeChild(textArea);
      }
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
    } catch (err) {
      console.error('Copy failed:', err);
    }
  };

  // QR Code URL using free reliable API service
  const qrImageUrl = `https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=${encodeURIComponent(
    currentUrl
  )}&color=1d4ed8`;

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4 animate-fadeIn">
      <div className="bg-[#18181b] rounded-3xl shadow-2xl border border-zinc-800 max-w-sm w-full p-6 sm:p-8 relative space-y-6">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 text-zinc-400 hover:text-white rounded-xl hover:bg-zinc-800 transition"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Header */}
        <div className="text-center space-y-2">
          <div className="w-12 h-12 bg-indigo-500/10 text-indigo-400 border border-indigo-500/20 rounded-2xl mx-auto flex items-center justify-center font-bold">
            <QrCode className="w-6 h-6" />
          </div>
          <h3 className="text-2xl font-bold text-white">Sdílet se studenty</h3>
          <p className="text-xs text-slate-400">
            Naskenujte QR kód pro rychlé otevření aplikace na mobilním telefonu nebo tabletu.
          </p>
        </div>

        {/* QR Code Container */}
        <div className="bg-[#09090b] p-5 rounded-2xl border border-zinc-800 flex justify-center items-center">
          <img
            src={qrImageUrl}
            alt="QR Kód pro sdílení"
            className="w-48 h-48 rounded-xl shadow-md bg-white p-3"
          />
        </div>

        {/* Copy Link Section */}
        <div className="space-y-2">
          <button
            onClick={handleCopy}
            className={`w-full py-3.5 px-4 rounded-2xl font-bold text-sm transition flex items-center justify-center space-x-2 shadow-lg border ${
              copied
                ? 'bg-emerald-600 text-white border-emerald-400/40'
                : 'bg-gradient-to-r from-indigo-500 to-purple-600 hover:from-indigo-600 hover:to-purple-700 text-white shadow-indigo-500/30 border-indigo-400/30'
            }`}
          >
            {copied ? (
              <>
                <Check className="w-4 h-4" />
                <span>Odkaz zkopírován do schránky!</span>
              </>
            ) : (
              <>
                <Copy className="w-4 h-4" />
                <span>Kopírovat URL adresu</span>
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};
