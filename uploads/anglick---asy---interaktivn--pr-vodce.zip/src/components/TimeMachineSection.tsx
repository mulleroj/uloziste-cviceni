import React, { useState } from 'react';
import { Volume2, Sparkles, HelpCircle, ArrowRight, Play } from 'lucide-react';
import { timeMachineData } from '../data/timeMachineData';
import { speakEnglishSentence } from '../utils/speech';

interface TimeMachineSectionProps {
  onGoToTest: () => void;
  onGoToTheory: (tenseId?: string) => void;
}

export const TimeMachineSection: React.FC<TimeMachineSectionProps> = ({
  onGoToTest,
  onGoToTheory,
}) => {
  const [sliderValue, setSliderValue] = useState<number>(0);
  const [isPlayingAudio, setIsPlayingAudio] = useState(false);

  // Find corresponding time machine point
  const currentPoint =
    timeMachineData.find((pt) => sliderValue >= pt.min && sliderValue <= pt.max) ||
    timeMachineData[3]; // default present continuous

  const handleSpeak = (text: string) => {
    setIsPlayingAudio(true);
    speakEnglishSentence(text, () => setIsPlayingAudio(false));
  };

  return (
    <div className="space-y-10">
      {/* Intro Hero Banner */}
      <div className="text-center max-w-3xl mx-auto space-y-4">
        <div className="inline-flex items-center space-x-2 px-4 py-1.5 rounded-full bg-indigo-500/10 text-indigo-400 border border-indigo-500/20 text-xs font-bold uppercase tracking-widest">
          <Sparkles className="w-4 h-4 text-indigo-400" />
          <span>Vizuální průvodce • Bento Grid Engine</span>
        </div>
        <h1 className="text-3xl sm:text-5xl font-bold text-white tracking-tight leading-tight">
          Pochopte anglické časy prostorově
        </h1>
        <p className="text-base sm:text-lg text-slate-400 leading-relaxed font-normal">
          Angličtina nevnímá čas jen jako tabulku pouček, ale jako prostornou časovou osu. Posouvejte
          jezdcem ze dřívější minulosti přes přítomnost až do budoucnosti a sledujte proměnu věty.
        </p>
      </div>

      {/* Visual Timeline Bar Card */}
      <div className="bg-[#18181b] rounded-3xl shadow-xl p-6 sm:p-8 border border-zinc-800 space-y-6">
        <div className="flex items-center justify-between border-b border-zinc-800 pb-4">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-2xl bg-indigo-500/10 text-indigo-400 border border-indigo-500/20 flex items-center justify-center font-bold">
              1
            </div>
            <div>
              <h2 className="text-xl font-bold text-white">Interaktivní časová osa</h2>
              <p className="text-xs text-slate-400">
                Kliknutím na pruh zobrazíte vysvětlení daného mluvnického času
              </p>
            </div>
          </div>
        </div>

        {/* Timeline Graphic Container */}
        <div className="relative w-full border border-zinc-800/90 rounded-2xl bg-[#09090b] p-4 overflow-hidden shadow-inner">
          {/* Vertical NOW marker line */}
          <div className="absolute left-1/2 top-0 bottom-0 w-0.5 bg-indigo-500/80 z-0 border-dashed border-l-2 border-indigo-400"></div>
          <div className="absolute left-1/2 top-2 transform -translate-x-1/2 bg-indigo-600 text-white text-[11px] px-3 py-0.5 rounded-full font-bold z-10 shadow-md uppercase tracking-wider">
            NYNÍ (0)
          </div>

          <div className="flex flex-col pt-9 pb-3 space-y-2 relative z-10">
            {/* Past Simple */}
            <div
              onClick={() => setSliderValue(-80)}
              className="group relative h-10 w-full flex items-center hover:bg-zinc-800/70 rounded-xl px-3 cursor-pointer transition border border-transparent hover:border-rose-500/30"
            >
              <span className="text-xs font-bold text-zinc-300 group-hover:text-rose-400 transition w-36 sm:w-44">
                Past Simple
              </span>
              <div className="absolute left-[25%] w-3.5 h-3.5 bg-rose-500 rounded-full transform -translate-y-1/2 top-1/2 shadow-sm group-hover:scale-125 transition"></div>
              <span className="ml-auto text-xs text-zinc-500 group-hover:text-zinc-300 font-mono hidden sm:inline">
                -80% (Minulost)
              </span>
            </div>

            {/* Past Continuous */}
            <div
              onClick={() => setSliderValue(-45)}
              className="group relative h-10 w-full flex items-center hover:bg-zinc-800/70 rounded-xl px-3 cursor-pointer transition border border-transparent hover:border-amber-500/30"
            >
              <span className="text-xs font-bold text-zinc-300 group-hover:text-amber-400 transition w-36 sm:w-44">
                Past Continuous
              </span>
              <div className="absolute left-[20%] w-[18%] h-2 bg-amber-400 rounded-full transform -translate-y-1/2 top-1/2 shadow-sm"></div>
              <span className="ml-auto text-xs text-zinc-500 group-hover:text-zinc-300 font-mono hidden sm:inline">
                -45% (Průběh)
              </span>
            </div>

            {/* Present Perfect */}
            <div
              onClick={() => setSliderValue(-15)}
              className="group relative h-10 w-full flex items-center hover:bg-zinc-800/70 rounded-xl px-3 cursor-pointer transition border border-transparent hover:border-purple-500/30"
            >
              <span className="text-xs font-bold text-zinc-300 group-hover:text-purple-400 transition w-36 sm:w-44">
                Present Perfect
              </span>
              <div className="absolute left-[30%] w-[20%] h-1 bg-purple-500 transform -translate-y-1/2 top-1/2 shadow-sm"></div>
              <div className="absolute left-[50%] transform -translate-y-1/2 -translate-x-1 top-1/2 border-t-[5px] border-t-transparent border-b-[5px] border-b-transparent border-l-[8px] border-l-purple-500"></div>
              <span className="ml-auto text-xs text-zinc-500 group-hover:text-zinc-300 font-mono hidden sm:inline">
                -15% (Spojení doteď)
              </span>
            </div>

            {/* Present Continuous */}
            <div
              onClick={() => setSliderValue(0)}
              className="group relative h-10 w-full flex items-center hover:bg-zinc-800/70 rounded-xl px-3 cursor-pointer transition border border-transparent hover:border-indigo-500/30"
            >
              <span className="text-xs font-bold text-zinc-300 group-hover:text-indigo-400 transition w-36 sm:w-44">
                Present Continuous
              </span>
              <div className="absolute left-[50%] transform -translate-x-1/2 -translate-y-1/2 top-1/2 w-4 h-4 bg-indigo-500 rounded-full shadow-md z-20"></div>
              <div className="absolute left-[50%] transform -translate-x-1/2 -translate-y-1/2 top-1/2 w-4 h-4 bg-indigo-400 rounded-full animate-ping opacity-75 z-10"></div>
              <span className="ml-auto text-xs text-zinc-500 group-hover:text-zinc-300 font-mono hidden sm:inline">
                0% (Právě teď)
              </span>
            </div>

            {/* Present Simple */}
            <div
              onClick={() => setSliderValue(15)}
              className="group relative h-10 w-full flex items-center hover:bg-zinc-800/70 rounded-xl px-3 cursor-pointer transition border border-transparent hover:border-emerald-500/30"
            >
              <span className="text-xs font-bold text-zinc-300 group-hover:text-emerald-400 transition w-36 sm:w-44">
                Present Simple
              </span>
              <div className="absolute left-[25%] w-2.5 h-2.5 bg-emerald-400 rounded-full transform -translate-y-1/2 top-1/2 shadow-sm"></div>
              <div className="absolute left-[50%] transform -translate-x-1/2 -translate-y-1/2 top-1/2 w-2.5 h-2.5 bg-emerald-400 rounded-full shadow-sm"></div>
              <div className="absolute left-[75%] w-2.5 h-2.5 bg-emerald-400 rounded-full transform -translate-y-1/2 top-1/2 shadow-sm"></div>
              <span className="ml-auto text-xs text-zinc-500 group-hover:text-zinc-300 font-mono hidden sm:inline">
                +15% (Zvyky & fakta)
              </span>
            </div>

            {/* Going to */}
            <div
              onClick={() => setSliderValue(45)}
              className="group relative h-10 w-full flex items-center hover:bg-zinc-800/70 rounded-xl px-3 cursor-pointer transition border border-transparent hover:border-orange-500/30"
            >
              <span className="text-xs font-bold text-zinc-300 group-hover:text-orange-400 transition w-36 sm:w-44">
                Going to (Plán)
              </span>
              <div className="absolute left-[52%] w-[18%] h-1 bg-orange-500 transform -translate-y-1/2 top-1/2 shadow-sm"></div>
              <div className="absolute left-[70%] transform -translate-y-1/2 -translate-x-0.5 top-1/2 border-t-[5px] border-t-transparent border-b-[5px] border-b-transparent border-l-[8px] border-l-orange-500"></div>
              <span className="ml-auto text-xs text-zinc-500 group-hover:text-zinc-300 font-mono hidden sm:inline">
                +45% (Promyšleno)
              </span>
            </div>

            {/* Future Simple */}
            <div
              onClick={() => setSliderValue(85)}
              className="group relative h-10 w-full flex items-center hover:bg-zinc-800/70 rounded-xl px-3 cursor-pointer transition border border-transparent hover:border-indigo-500/30"
            >
              <span className="text-xs font-bold text-zinc-300 group-hover:text-indigo-400 transition w-36 sm:w-44">
                Future Simple (Will)
              </span>
              <div className="absolute left-[85%] w-3.5 h-3.5 bg-indigo-500 rounded-full transform -translate-y-1/2 top-1/2 shadow-sm"></div>
              <span className="ml-auto text-xs text-zinc-500 group-hover:text-zinc-300 font-mono hidden sm:inline">
                +85% (Spontánně)
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Time Machine Interactive Controls */}
      <div className="bg-[#18181b] rounded-3xl shadow-xl p-6 sm:p-8 border border-zinc-800 space-y-8">
        <div className="flex items-center space-x-3 border-b border-zinc-800 pb-4">
          <div className="w-10 h-10 rounded-2xl bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 flex items-center justify-center font-bold">
            2
          </div>
          <div>
            <h2 className="text-xl font-bold text-white">Stroj času: Posouvejte čas</h2>
            <p className="text-xs text-slate-400">
              Táhněte posuvníkem doleva pro minulost a doprava pro budoucnost
            </p>
          </div>
        </div>

        {/* Range Slider */}
        <div className="space-y-4 max-w-3xl mx-auto px-2">
          <div className="flex justify-between text-xs font-bold text-slate-400">
            <span className="text-rose-400">← DÁVNÁ MINULOST (-100)</span>
            <span className="text-indigo-400 uppercase tracking-widest font-black">NYNÍ (0)</span>
            <span className="text-purple-400">BUDOUCNOST (+100) →</span>
          </div>

          <input
            type="range"
            min="-100"
            max="100"
            value={sliderValue}
            onChange={(e) => setSliderValue(parseInt(e.target.value))}
            className="w-full h-3 bg-zinc-800 rounded-full appearance-none cursor-pointer accent-indigo-500 shadow-inner focus:outline-none focus:ring-2 focus:ring-indigo-400/50"
          />

          <div className="flex justify-between px-1 flex-wrap gap-1">
            {timeMachineData.map((item) => (
              <button
                key={item.tenseId}
                onClick={() => setSliderValue(Math.round((item.min + item.max) / 2))}
                className={`text-[10px] sm:text-xs font-semibold px-2.5 py-1 rounded-xl transition ${
                  currentPoint.tenseId === item.tenseId
                    ? 'bg-indigo-600 text-white font-bold shadow-md shadow-indigo-600/30'
                    : 'bg-zinc-800/80 text-zinc-400 hover:bg-zinc-700 hover:text-white border border-zinc-700/50'
                }`}
              >
                {item.name.split(' ')[0]}
              </button>
            ))}
          </div>
        </div>

        {/* Dynamic Result Bento Card */}
        <div className="p-6 sm:p-8 rounded-3xl border border-zinc-800 bg-[#121215] transition-all duration-300 shadow-2xl space-y-6">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
              <span className="inline-block px-3 py-1 rounded-full text-xs font-bold tracking-widest uppercase mb-3 bg-indigo-500/10 text-indigo-400 border border-indigo-500/20">
                {currentPoint.name}
              </span>
              <div className="flex items-center space-x-3">
                <h3 className="text-2xl sm:text-4xl font-extrabold text-white tracking-tight">
                  "{currentPoint.sentenceEn}"
                </h3>
                <button
                  onClick={() => handleSpeak(currentPoint.sentenceEn)}
                  className={`p-3 rounded-2xl bg-zinc-800 hover:bg-indigo-600 text-indigo-400 hover:text-white border border-zinc-700 shadow-sm transition transform active:scale-95 ${
                    isPlayingAudio ? 'ring-2 ring-indigo-400 animate-pulse text-indigo-300' : ''
                  }`}
                  title="Přehrát anglickou výslovnost"
                >
                  <Volume2 className="w-5 h-5" />
                </button>
              </div>
              <p className="text-base font-semibold text-slate-300 italic mt-2">
                "{currentPoint.sentenceCz}"
              </p>
            </div>

            <button
              onClick={() => onGoToTheory(currentPoint.tenseId)}
              className="inline-flex items-center space-x-2 px-5 py-2.5 bg-zinc-800 hover:bg-zinc-700 border border-zinc-700 rounded-2xl text-xs font-bold text-white shadow-sm transition self-start md:self-auto"
            >
              <span>Detail mluvnického pravidla</span>
              <ArrowRight className="w-4 h-4 text-indigo-400" />
            </button>
          </div>

          <div className="bg-[#18181b] p-5 rounded-2xl border border-zinc-800 space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-widest text-slate-400 flex items-center space-x-1.5">
              <HelpCircle className="w-4 h-4 text-indigo-400" />
              <span>Kdy a proč se tento čas používá?</span>
            </h4>
            <p className="text-sm sm:text-base text-zinc-200 leading-relaxed font-normal">
              {currentPoint.context}
            </p>

            <div className="pt-2 flex flex-wrap items-center gap-2">
              <span className="text-xs font-bold text-slate-400">Signalizační slovíčka:</span>
              {currentPoint.signalWords.map((word) => (
                <span
                  key={word}
                  className="px-3 py-1 rounded-full bg-zinc-800 text-indigo-300 text-xs font-semibold border border-zinc-700"
                >
                  {word}
                </span>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Call to action bento card */}
      <div className="bg-gradient-to-br from-indigo-900/60 via-purple-900/40 to-zinc-900 border border-indigo-500/30 rounded-3xl p-6 sm:p-8 text-white shadow-2xl flex flex-col md:flex-row items-center justify-between gap-6">
        <div className="space-y-2 text-center md:text-left">
          <h3 className="text-2xl font-bold">Cítíte se připraveni otestovat své znalosti?</h3>
          <p className="text-slate-300 text-sm max-w-xl">
            Vyzkoušejte náš interaktivní test na 15 náhodných otázek z reálných vět s podrobným
            vysvětlením.
          </p>
        </div>
        <button
          onClick={onGoToTest}
          className="px-8 py-3.5 rounded-2xl bg-gradient-to-r from-indigo-500 to-purple-600 hover:from-indigo-600 hover:to-purple-700 text-white font-extrabold text-base shadow-lg shadow-indigo-500/30 transition transform hover:scale-105 flex items-center space-x-2 shrink-0 border border-indigo-400/40"
        >
          <Play className="w-5 h-5 fill-current text-emerald-400" />
          <span>Spustit hlavní test</span>
        </button>
      </div>
    </div>
  );
};
