import React, { useState } from 'react';
import { Volume2, CheckCircle2, XCircle, Info, Sparkles, HelpCircle } from 'lucide-react';
import { tensesDetails } from '../data/tensesData';
import { speakEnglishSentence } from '../utils/speech';

interface TheorySectionProps {
  initialTenseId?: string;
  onGoToTest: () => void;
}

export const TheorySection: React.FC<TheorySectionProps> = ({
  onGoToTest,
}) => {
  const [activeTab, setActiveTab] = useState<'present' | 'past' | 'future' | 'matrix'>('present');
  const [miniQuizStates, setMiniQuizStates] = useState<Record<string, { selected: number; checked: boolean }>>({});
  const [playingAudioKey, setPlayingAudioKey] = useState<string | null>(null);

  const filteredTenses = tensesDetails.filter((t) => t.category === activeTab);

  const handleOptionSelect = (tenseId: string, optionIdx: number) => {
    setMiniQuizStates((prev) => ({
      ...prev,
      [tenseId]: { selected: optionIdx, checked: true },
    }));
  };

  const handleSpeak = (text: string, key: string) => {
    setPlayingAudioKey(key);
    speakEnglishSentence(text, () => setPlayingAudioKey(null));
  };

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="text-center max-w-3xl mx-auto space-y-3">
        <div className="inline-flex items-center space-x-2 px-4 py-1.5 rounded-full bg-indigo-500/10 text-indigo-400 border border-indigo-500/20 text-xs font-bold uppercase tracking-widest">
          <Sparkles className="w-4 h-4 text-indigo-400" />
          <span>Kompletní gramatická kniha • Bento Matrix</span>
        </div>
        <h2 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight">Přehled mluvnické teorie a rozdílů</h2>
        <p className="text-slate-400 text-base font-normal">
          Projděte si vzorce, klíčová signalizační slovíčka i typické větné konstrukce.
          U každého času si vyzkoušejte rychlý mini-kvíz.
        </p>
      </div>

      {/* Category Tabs */}
      <div className="flex flex-wrap justify-center gap-2.5">
        <button
          onClick={() => setActiveTab('present')}
          className={`px-5 py-2.5 rounded-2xl font-bold text-sm transition-all shadow-sm ${
            activeTab === 'present'
              ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-600/30 border border-emerald-400/40'
              : 'bg-[#18181b] text-zinc-400 hover:bg-zinc-800 hover:text-white border border-zinc-800'
          }`}
        >
          Přítomné časy (Present)
        </button>

        <button
          onClick={() => setActiveTab('past')}
          className={`px-5 py-2.5 rounded-2xl font-bold text-sm transition-all shadow-sm ${
            activeTab === 'past'
              ? 'bg-rose-600 text-white shadow-lg shadow-rose-600/30 border border-rose-400/40'
              : 'bg-[#18181b] text-zinc-400 hover:bg-zinc-800 hover:text-white border border-zinc-800'
          }`}
        >
          Minulé časy (Past)
        </button>

        <button
          onClick={() => setActiveTab('future')}
          className={`px-5 py-2.5 rounded-2xl font-bold text-sm transition-all shadow-sm ${
            activeTab === 'future'
              ? 'bg-amber-600 text-white shadow-lg shadow-amber-600/30 border border-amber-400/40'
              : 'bg-[#18181b] text-zinc-400 hover:bg-zinc-800 hover:text-white border border-zinc-800'
          }`}
        >
          Budoucí časy (Future)
        </button>

        <button
          onClick={() => setActiveTab('matrix')}
          className={`px-5 py-2.5 rounded-2xl font-bold text-sm transition-all shadow-sm ${
            activeTab === 'matrix'
              ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/30 border border-indigo-400/40'
              : 'bg-[#18181b] text-zinc-400 hover:bg-zinc-800 hover:text-white border border-zinc-800'
          }`}
        >
          Srovnávací tabulka
        </button>
      </div>

      {/* Detailed Tense Cards (Present / Past / Future) */}
      {activeTab !== 'matrix' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {filteredTenses.map((tense) => {
            const quizState = miniQuizStates[tense.id];

            return (
              <div
                key={tense.id}
                id={tense.id}
                className="bg-[#18181b] rounded-3xl shadow-xl border border-zinc-800 p-6 sm:p-7 flex flex-col justify-between transition hover:border-zinc-700"
              >
                <div className="space-y-5">
                  {/* Badge & Title */}
                  <div className="flex items-center justify-between border-b border-zinc-800 pb-4">
                    <div>
                      <span className="px-3 py-1 rounded-full text-xs font-bold uppercase tracking-widest bg-indigo-500/10 text-indigo-400 border border-indigo-500/20">
                        {tense.name}
                      </span>
                      <h3 className="text-2xl font-bold text-white mt-2">{tense.nameCz}</h3>
                    </div>
                  </div>

                  {/* Descriptions */}
                  <p className="text-sm font-medium text-slate-300 leading-relaxed">
                    {tense.shortDesc}
                  </p>

                  <div className="bg-[#09090b] p-4 rounded-2xl text-xs text-slate-400 leading-relaxed border border-zinc-800">
                    {tense.detailedDesc}
                  </div>

                  {/* Formula Box */}
                  <div className="bg-[#09090b] text-white p-4.5 rounded-2xl space-y-2.5 text-xs font-mono border border-zinc-800">
                    <div className="text-slate-400 font-bold uppercase tracking-widest text-[10px] border-b border-zinc-800 pb-1.5">
                      Vzorce pro tvorbu věty
                    </div>
                    <div className="flex items-center space-x-2">
                      <span className="text-emerald-400 font-bold w-5">+</span>
                      <span>{tense.formula.positive}</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <span className="text-rose-400 font-bold w-5">-</span>
                      <span>{tense.formula.negative}</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <span className="text-amber-400 font-bold w-5">?</span>
                      <span>{tense.formula.question}</span>
                    </div>
                  </div>

                  {/* Signal Words */}
                  <div>
                    <span className="text-xs font-bold text-slate-400 block mb-2">
                      Klíčová signalizační slovíčka:
                    </span>
                    <div className="flex flex-wrap gap-2">
                      {tense.signalWords.map((word) => (
                        <span
                          key={word}
                          className="px-3 py-1 rounded-xl bg-zinc-800 text-zinc-300 text-xs font-semibold border border-zinc-700/60"
                        >
                          {word}
                        </span>
                      ))}
                    </div>
                  </div>

                  {/* Example Sentences */}
                  <div className="space-y-2.5">
                    <span className="text-xs font-bold text-slate-400 block">Příklady věcí z praxe:</span>
                    {tense.examples.map((ex, idx) => {
                      const audioKey = `${tense.id}-ex-${idx}`;
                      return (
                        <div
                          key={idx}
                          className="bg-[#121215] hover:bg-zinc-800/80 p-3.5 rounded-2xl border border-zinc-800 flex items-center justify-between gap-3 text-xs transition"
                        >
                          <div>
                            <p className="font-bold text-white">{ex.en}</p>
                            <p className="text-slate-400 italic mt-0.5">{ex.cz}</p>
                          </div>
                          <button
                            onClick={() => handleSpeak(ex.en, audioKey)}
                            className={`p-2.5 rounded-xl bg-zinc-800 border border-zinc-700 text-indigo-400 hover:text-white hover:bg-indigo-600 transition shrink-0 ${
                              playingAudioKey === audioKey ? 'ring-2 ring-indigo-400 text-white bg-indigo-600 animate-pulse' : ''
                            }`}
                            title="Poslechnout anglickou výslovnost"
                          >
                            <Volume2 className="w-4 h-4" />
                          </button>
                        </div>
                      );
                    })}
                  </div>
                </div>

                {/* Embedded Mini Quiz */}
                <div className="mt-6 pt-4 border-t border-zinc-800 bg-[#121215] p-5 rounded-2xl border border-zinc-800 space-y-3">
                  <div className="flex items-center space-x-2">
                    <HelpCircle className="w-4 h-4 text-indigo-400" />
                    <span className="text-xs font-extrabold uppercase tracking-widest text-slate-300">
                      Rychlé ověření znalosti
                    </span>
                  </div>
                  <p className="text-sm font-semibold text-white">
                    {tense.miniQuiz.question}
                  </p>

                  <div className="space-y-2">
                    {tense.miniQuiz.options.map((opt, oIdx) => {
                      const isSelected = quizState?.selected === oIdx;
                      return (
                        <button
                          key={oIdx}
                          onClick={() => handleOptionSelect(tense.id, oIdx)}
                          className={`w-full text-left p-3 rounded-xl text-xs font-medium border transition flex items-center justify-between ${
                            isSelected
                              ? opt.correct
                                ? 'bg-emerald-950/80 border-emerald-500 text-emerald-200'
                                : 'bg-rose-950/80 border-rose-500 text-rose-200'
                              : 'bg-[#18181b] border-zinc-800 text-zinc-300 hover:bg-zinc-800'
                          }`}
                        >
                          <span>{opt.text}</span>
                          {isSelected &&
                            (opt.correct ? (
                              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                            ) : (
                              <XCircle className="w-4 h-4 text-rose-400 shrink-0" />
                            ))}
                        </button>
                      );
                    })}
                  </div>

                  {/* Feedback Explanation */}
                  {quizState?.checked && (
                    <div
                      className={`mt-3 p-3.5 rounded-xl text-xs font-medium animate-fadeIn ${
                        tense.miniQuiz.options[quizState.selected].correct
                          ? 'bg-emerald-950/90 text-emerald-200 border border-emerald-700/60'
                          : 'bg-rose-950/90 text-rose-200 border border-rose-700/60'
                      }`}
                    >
                      {tense.miniQuiz.options[quizState.selected].explanation}
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Comparison Matrix View */}
      {activeTab === 'matrix' && (
        <div className="bg-[#18181b] rounded-3xl shadow-xl p-6 sm:p-8 border border-zinc-800 overflow-x-auto">
          <h3 className="text-xl font-bold text-white mb-6 flex items-center space-x-2.5">
            <Sparkles className="w-5 h-5 text-indigo-400" />
            <span>Přehledná matice anglických časů</span>
          </h3>

          <table className="w-full text-left border-collapse min-w-[650px]">
            <thead>
              <tr className="bg-[#09090b] text-slate-400 text-xs font-bold uppercase tracking-widest border-b border-zinc-800">
                <th className="p-3.5 border border-zinc-800">Mluvnický čas</th>
                <th className="p-3.5 border border-zinc-800">Kladný tvar (+)</th>
                <th className="p-3.5 border border-zinc-800">Typické použití</th>
                <th className="p-3.5 border border-zinc-800">Klíčová slovíčka</th>
              </tr>
            </thead>
            <tbody className="text-xs text-zinc-300 divide-y divide-zinc-800 font-medium">
              {tensesDetails.map((t) => (
                <tr key={t.id} className="hover:bg-zinc-800/50 transition">
                  <td className="p-3.5 border border-zinc-800 font-bold text-white">
                    <div>{t.name}</div>
                    <div className="text-[11px] text-slate-400 font-normal">{t.nameCz}</div>
                  </td>
                  <td className="p-3.5 border border-zinc-800 font-mono text-indigo-400">
                    {t.formula.positive}
                  </td>
                  <td className="p-3.5 border border-zinc-800 text-slate-300">{t.shortDesc}</td>
                  <td className="p-3.5 border border-zinc-800">
                    <div className="flex flex-wrap gap-1">
                      {t.signalWords.slice(0, 4).map((w) => (
                        <span key={w} className="bg-zinc-800 px-2 py-0.5 rounded-lg text-[10px] text-indigo-300 border border-zinc-700/50">
                          {w}
                        </span>
                      ))}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* Bottom CTA */}
      <div className="text-center pt-6">
        <button
          onClick={onGoToTest}
          className="px-8 py-3.5 bg-gradient-to-r from-indigo-500 to-purple-600 hover:from-indigo-600 hover:to-purple-700 text-white font-extrabold rounded-2xl shadow-lg shadow-indigo-500/30 transition transform hover:scale-105 inline-flex items-center space-x-2 text-base border border-indigo-400/30"
        >
          <span>Spustit test na procvičení</span>
        </button>
      </div>
    </div>
  );
};
