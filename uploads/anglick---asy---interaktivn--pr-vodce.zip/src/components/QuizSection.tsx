import React, { useState, useEffect } from 'react';
import { Volume2, CheckCircle2, XCircle, Award, RotateCcw, ArrowRight, Bookmark, Clock, Sparkles, AlertCircle, Filter } from 'lucide-react';
import confetti from 'canvas-confetti';
import { Question, TenseCategory, QuizResult } from '../types';
import { questionBank } from '../data/questionsData';
import { speakEnglishSentence } from '../utils/speech';

interface QuizSectionProps {
  onQuizFinished: (result: QuizResult) => void;
  onGoToTheory: () => void;
}

export const QuizSection: React.FC<QuizSectionProps> = ({ onQuizFinished, onGoToTheory }) => {
  // Quiz configuration state
  const [category, setCategory] = useState<TenseCategory>('all');
  const [questionCount, setQuestionCount] = useState<number>(15);
  const [isTimed, setIsTimed] = useState<boolean>(false);

  // Active quiz state
  const [quizState, setQuizState] = useState<'setup' | 'active' | 'results'>('setup');
  const [activeQuestions, setActiveQuestions] = useState<Question[]>([]);
  const [currentIndex, setCurrentIndex] = useState<number>(0);
  const [userAnswers, setUserAnswers] = useState<Record<number, number>>({});
  const [bookmarkedIds, setBookmarkedIds] = useState<string[]>([]);
  const [showExplanation, setShowExplanation] = useState<boolean>(false);

  // Timer state
  const [timeRemaining, setTimeRemaining] = useState<number>(30);
  const [totalTimeSpent, setTotalTimeSpent] = useState<number>(0);
  const [score, setScore] = useState<number>(0);
  const [isPlayingAudio, setIsPlayingAudio] = useState<boolean>(false);

  // Review filter
  const [reviewFilter, setReviewFilter] = useState<'all' | 'incorrect'>('all');

  // Start a new quiz session
  const startQuiz = () => {
    let pool = questionBank;
    if (category !== 'all') {
      pool = questionBank.filter((q) => q.category === category);
    }

    // Shuffle
    const shuffled = [...pool].sort(() => Math.random() - 0.5);
    const selected = shuffled.slice(0, Math.min(questionCount, shuffled.length));

    setActiveQuestions(selected);
    setCurrentIndex(0);
    setUserAnswers({});
    setScore(0);
    setShowExplanation(false);
    setTotalTimeSpent(0);
    setTimeRemaining(30);
    setQuizState('active');
  };

  // Timer countdown hook
  useEffect(() => {
    let interval: any = null;
    if (quizState === 'active') {
      interval = setInterval(() => {
        setTotalTimeSpent((prev) => prev + 1);
        if (isTimed) {
          setTimeRemaining((prev) => {
            if (prev <= 1) {
              handleAutoNext();
              return 30;
            }
            return prev - 1;
          });
        }
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [quizState, isTimed, currentIndex]);

  const handleAutoNext = () => {
    if (userAnswers[currentIndex] === undefined) {
      // Mark as unanswered / wrong
      setUserAnswers((prev) => ({ ...prev, [currentIndex]: -1 }));
    }
    if (currentIndex < activeQuestions.length - 1) {
      setCurrentIndex((prev) => prev + 1);
      setShowExplanation(false);
      setTimeRemaining(30);
    } else {
      finishQuiz();
    }
  };

  const handleSelectOption = (optionIndex: number) => {
    if (showExplanation) return; // locked after checking
    setUserAnswers((prev) => ({ ...prev, [currentIndex]: optionIndex }));
  };

  const handleCheckAnswer = () => {
    if (userAnswers[currentIndex] === undefined) return;
    setShowExplanation(true);
  };

  const handleNextQuestion = () => {
    if (currentIndex < activeQuestions.length - 1) {
      setCurrentIndex((prev) => prev + 1);
      setShowExplanation(false);
      setTimeRemaining(30);
    } else {
      finishQuiz();
    }
  };

  const finishQuiz = () => {
    let calculatedScore = 0;
    activeQuestions.forEach((q, idx) => {
      if (userAnswers[idx] === q.answer) {
        calculatedScore++;
      }
    });

    setScore(calculatedScore);
    const percentage = Math.round((calculatedScore / activeQuestions.length) * 100);

    const result: QuizResult = {
      id: Date.now().toString(),
      date: new Date().toLocaleDateString('cs-CZ'),
      score: calculatedScore,
      totalQuestions: activeQuestions.length,
      category,
      percentage,
      timeSpentSeconds: totalTimeSpent,
    };

    onQuizFinished(result);
    setQuizState('results');

    if (percentage >= 80) {
      try {
        confetti({
          particleCount: 100,
          spread: 70,
          origin: { y: 0.6 },
        });
      } catch (e) {
        // ignore fallback
      }
    }
  };

  const toggleBookmark = (id: string) => {
    setBookmarkedIds((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]
    );
  };

  const currentQ = activeQuestions[currentIndex];

  const handleSpeakCurrent = () => {
    if (!currentQ) return;
    setIsPlayingAudio(true);
    speakEnglishSentence(currentQ.q, () => setIsPlayingAudio(false));
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      {/* ---------------- SETUP SCREEN ---------------- */}
      {quizState === 'setup' && (
        <div className="bg-[#18181b] rounded-3xl shadow-xl p-6 sm:p-10 border border-zinc-800 space-y-8 animate-fadeIn">
          <div className="text-center space-y-3">
            <div className="w-16 h-16 rounded-2xl bg-indigo-500/10 text-indigo-400 border border-indigo-500/20 mx-auto flex items-center justify-center font-bold shadow-sm">
              <Award className="w-8 h-8" />
            </div>
            <h2 className="text-3xl font-extrabold text-white">Procvičování & Hlavní Test</h2>
            <p className="text-slate-400 text-sm max-w-xl mx-auto">
              Vyberte si kategorii a náročnost testu. Každá otázka obsahuje přesný anglický větný příklad s vysvětlením a zvukovou výslovností.
            </p>
          </div>

          <div className="space-y-6 max-w-2xl mx-auto">
            {/* Category selection */}
            <div className="space-y-2.5">
              <label className="text-xs font-bold uppercase tracking-widest text-slate-400 block">
                1. Vyberte mluvnickou oblast:
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                {[
                  { id: 'all', label: 'Všechny časy' },
                  { id: 'present', label: 'Přítomné časy' },
                  { id: 'past', label: 'Minulé časy' },
                  { id: 'future', label: 'Budoucí časy' },
                  { id: 'advanced', label: 'Pokročilé & Kondicionály' },
                ].map((cat) => (
                  <button
                    key={cat.id}
                    onClick={() => setCategory(cat.id as TenseCategory)}
                    className={`p-3.5 rounded-2xl border text-xs font-bold transition flex items-center justify-center text-center ${
                      category === cat.id
                        ? 'bg-indigo-600 text-white border-indigo-500 shadow-md shadow-indigo-600/30'
                        : 'bg-[#09090b] text-zinc-300 border-zinc-800 hover:bg-zinc-800 hover:text-white'
                    }`}
                  >
                    {cat.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Question count selection */}
            <div className="space-y-2.5">
              <label className="text-xs font-bold uppercase tracking-widest text-slate-400 block">
                2. Počet otázek v testu:
              </label>
              <div className="grid grid-cols-4 gap-3">
                {[10, 15, 20, 30].map((cnt) => (
                  <button
                    key={cnt}
                    onClick={() => setQuestionCount(cnt)}
                    className={`py-3 rounded-2xl border text-sm font-bold transition flex items-center justify-center ${
                      questionCount === cnt
                        ? 'bg-indigo-600 text-white border-indigo-500 shadow-md shadow-indigo-600/30'
                        : 'bg-[#09090b] text-zinc-300 border-zinc-800 hover:bg-zinc-800 hover:text-white'
                    }`}
                  >
                    {cnt} otázek
                  </button>
                ))}
              </div>
            </div>

            {/* Timed Mode Toggle */}
            <div className="bg-[#09090b] p-4.5 rounded-2xl border border-zinc-800 flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <Clock className="w-5 h-5 text-indigo-400" />
                <div>
                  <p className="text-sm font-bold text-white">Časový limit pro otázku (30s)</p>
                  <p className="text-xs text-slate-400">
                    Pro vyšší výzvu zapněte automatický časovač na 30 vteřin pro každou otázku.
                  </p>
                </div>
              </div>
              <input
                type="checkbox"
                checked={isTimed}
                onChange={(e) => setIsTimed(e.target.checked)}
                className="w-5 h-5 accent-indigo-500 rounded cursor-pointer"
              />
            </div>

            {/* Start Button */}
            <button
              onClick={startQuiz}
              className="w-full py-4 bg-gradient-to-r from-indigo-500 to-purple-600 hover:from-indigo-600 hover:to-purple-700 text-white font-extrabold text-lg rounded-2xl shadow-lg shadow-indigo-500/30 transition transform hover:scale-[1.01] flex items-center justify-center space-x-2 border border-indigo-400/40"
            >
              <Sparkles className="w-5 h-5 text-amber-300" />
              <span>Spustit Test Nyní</span>
            </button>
          </div>
        </div>
      )}

      {/* ---------------- ACTIVE QUIZ SCREEN ---------------- */}
      {quizState === 'active' && currentQ && (
        <div className="bg-[#18181b] rounded-3xl shadow-xl border border-zinc-800 overflow-hidden animate-fadeIn space-y-0">
          {/* Header Bar */}
          <div className="bg-[#121215] p-5 text-white flex items-center justify-between border-b border-zinc-800">
            <div className="flex items-center space-x-3">
              <span className="px-3 py-1 rounded-full bg-indigo-500/10 text-indigo-400 border border-indigo-500/20 text-xs font-bold uppercase tracking-widest">
                {currentQ.category}
              </span>
              <span className="text-sm font-semibold text-slate-300">
                Otázka {currentIndex + 1} z {activeQuestions.length}
              </span>
            </div>

            <div className="flex items-center space-x-3">
              {isTimed && (
                <div className="flex items-center space-x-1.5 bg-zinc-800 px-3.5 py-1 rounded-full text-xs font-bold text-amber-400 border border-zinc-700">
                  <Clock className="w-4 h-4 animate-pulse" />
                  <span>{timeRemaining}s</span>
                </div>
              )}
              <button
                onClick={() => toggleBookmark(currentQ.id)}
                className={`p-2 rounded-xl transition ${
                  bookmarkedIds.includes(currentQ.id)
                    ? 'text-amber-400 bg-zinc-800 border border-zinc-700'
                    : 'text-zinc-400 hover:text-white hover:bg-zinc-800'
                }`}
                title="Uložit si otázku do záložek"
              >
                <Bookmark className="w-5 h-5 fill-current" />
              </button>
            </div>
          </div>

          {/* Progress Bar */}
          <div className="w-full bg-zinc-900 h-2">
            <div
              className="bg-gradient-to-r from-indigo-500 to-purple-500 h-2 transition-all duration-300"
              style={{ width: `${((currentIndex + 1) / activeQuestions.length) * 100}%` }}
            ></div>
          </div>

          {/* Question Body */}
          <div className="p-6 sm:p-8 space-y-6">
            <div className="flex items-start justify-between gap-4 border-b border-zinc-800 pb-4">
              <h3 className="text-xl sm:text-2xl font-bold text-white leading-snug">
                {currentQ.q}
              </h3>

              <button
                onClick={handleSpeakCurrent}
                className={`p-3 rounded-2xl bg-zinc-800 text-indigo-400 hover:bg-indigo-600 hover:text-white border border-zinc-700 transition shrink-0 ${
                  isPlayingAudio ? 'ring-2 ring-indigo-400 animate-pulse text-white bg-indigo-600' : ''
                }`}
                title="Přehrát větu"
              >
                <Volume2 className="w-5 h-5" />
              </button>
            </div>

            {/* Multiple Choice Options */}
            <div className="space-y-3">
              {currentQ.options.map((opt, optIdx) => {
                const isSelected = userAnswers[currentIndex] === optIdx;
                const isCorrect = currentQ.answer === optIdx;

                let optionStyle = 'border-zinc-800 bg-[#09090b] hover:bg-zinc-800 text-zinc-200';
                if (isSelected && !showExplanation) {
                  optionStyle = 'border-indigo-500 bg-indigo-500/15 text-white ring-2 ring-indigo-500/40';
                } else if (showExplanation) {
                  if (isCorrect) {
                    optionStyle = 'border-emerald-500 bg-emerald-950/70 text-emerald-200 font-bold';
                  } else if (isSelected && !isCorrect) {
                    optionStyle = 'border-rose-500 bg-rose-950/70 text-rose-200';
                  }
                }

                return (
                  <button
                    key={optIdx}
                    onClick={() => handleSelectOption(optIdx)}
                    disabled={showExplanation}
                    className={`w-full p-4 rounded-2xl border-2 text-left font-medium text-sm sm:text-base transition flex items-center justify-between ${optionStyle}`}
                  >
                    <div className="flex items-center space-x-3">
                      <span className="w-7 h-7 rounded-full border border-zinc-700 flex items-center justify-center text-xs font-bold text-slate-400 shrink-0 bg-zinc-900">
                        {String.fromCharCode(65 + optIdx)}
                      </span>
                      <span>{opt}</span>
                    </div>

                    {showExplanation && (
                      <div>
                        {isCorrect && <CheckCircle2 className="w-5 h-5 text-emerald-400" />}
                        {isSelected && !isCorrect && <XCircle className="w-5 h-5 text-rose-400" />}
                      </div>
                    )}
                  </button>
                );
              })}
            </div>

            {/* Instant Explanation Box */}
            {showExplanation && (
              <div
                className={`p-4.5 rounded-2xl text-xs sm:text-sm font-medium border animate-fadeIn ${
                  userAnswers[currentIndex] === currentQ.answer
                    ? 'bg-emerald-950/80 border-emerald-700/60 text-emerald-200'
                    : 'bg-rose-950/80 border-rose-700/60 text-rose-200'
                }`}
              >
                <div className="font-bold mb-1 flex items-center space-x-1.5">
                  {userAnswers[currentIndex] === currentQ.answer ? (
                    <>
                      <CheckCircle2 className="w-4.5 h-4.5 text-emerald-400" />
                      <span>Správně!</span>
                    </>
                  ) : (
                    <>
                      <AlertCircle className="w-4.5 h-4.5 text-rose-400" />
                      <span>Špatná odpověď</span>
                    </>
                  )}
                </div>
                <p className="leading-relaxed">{currentQ.explanation}</p>
              </div>
            )}

            {/* Action Buttons */}
            <div className="pt-4 border-t border-zinc-800 flex items-center justify-between">
              {!showExplanation ? (
                <button
                  onClick={handleCheckAnswer}
                  disabled={userAnswers[currentIndex] === undefined}
                  className={`px-6 py-3 rounded-2xl font-bold text-sm transition ${
                    userAnswers[currentIndex] !== undefined
                      ? 'bg-indigo-600 hover:bg-indigo-500 text-white shadow-lg shadow-indigo-600/30'
                      : 'bg-zinc-800 text-zinc-500 cursor-not-allowed border border-zinc-800'
                  }`}
                >
                  Zkontrolovat odpoveď
                </button>
              ) : (
                <button
                  onClick={handleNextQuestion}
                  className="px-6 py-3 rounded-2xl bg-gradient-to-r from-indigo-500 to-purple-600 hover:from-indigo-600 hover:to-purple-700 text-white font-bold text-sm transition flex items-center space-x-2 shadow-lg shadow-indigo-500/20 ml-auto"
                >
                  <span>
                    {currentIndex < activeQuestions.length - 1 ? 'Další otázka' : 'Zobrazit výsledky'}
                  </span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              )}
            </div>
          </div>
        </div>
      )}

      {/* ---------------- RESULTS SCREEN ---------------- */}
      {quizState === 'results' && (
        <div className="bg-[#18181b] rounded-3xl shadow-xl p-6 sm:p-10 border border-zinc-800 space-y-8 animate-fadeIn">
          <div className="text-center space-y-4">
            <div className="w-20 h-20 bg-indigo-500/10 text-indigo-400 border border-indigo-500/20 rounded-3xl mx-auto flex items-center justify-center shadow-inner">
              <Award className="w-10 h-10" />
            </div>
            <h2 className="text-3xl font-extrabold text-white">Test dokončen!</h2>
            <div className="inline-block px-8 py-3 rounded-3xl bg-[#09090b] text-4xl sm:text-5xl font-extrabold text-indigo-400 border border-zinc-800 shadow-md">
              {Math.round((score / activeQuestions.length) * 100)}%
            </div>
            <p className="text-slate-400 font-medium text-base">
              Správně {score} z {activeQuestions.length} otázek (Čas: {totalTimeSpent}s)
            </p>
          </div>

          {/* Filter options for review */}
          <div className="flex items-center justify-between border-t border-b border-zinc-800 py-4">
            <h3 className="text-lg font-bold text-white flex items-center space-x-2">
              <Filter className="w-4 h-4 text-indigo-400" />
              <span>Podrobný přehled odpovedí</span>
            </h3>

            <div className="flex items-center space-x-2">
              <button
                onClick={() => setReviewFilter('all')}
                className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition ${
                  reviewFilter === 'all'
                    ? 'bg-indigo-600 text-white'
                    : 'bg-zinc-800 text-zinc-400 hover:bg-zinc-700 hover:text-white'
                }`}
              >
                Všechny ({activeQuestions.length})
              </button>
              <button
                onClick={() => setReviewFilter('incorrect')}
                className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition ${
                  reviewFilter === 'incorrect'
                    ? 'bg-rose-600 text-white'
                    : 'bg-zinc-800 text-zinc-400 hover:bg-zinc-700 hover:text-white'
                }`}
              >
                Chybné ({activeQuestions.length - score})
              </button>
            </div>
          </div>

          {/* Question Review List */}
          <div className="space-y-4 max-h-[450px] overflow-y-auto pr-1">
            {activeQuestions.map((q, idx) => {
              const userAns = userAnswers[idx];
              const isCorrect = userAns === q.answer;

              if (reviewFilter === 'incorrect' && isCorrect) return null;

              return (
                <div
                  key={q.id}
                  className={`p-4.5 rounded-2xl border text-xs sm:text-sm space-y-2 ${
                    isCorrect ? 'bg-emerald-950/40 border-emerald-800/60' : 'bg-rose-950/40 border-rose-800/60'
                  }`}
                >
                  <div className="flex items-start justify-between">
                    <span className="font-bold text-white">
                      {idx + 1}. {q.q}
                    </span>
                    {isCorrect ? (
                      <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
                    ) : (
                      <XCircle className="w-5 h-5 text-rose-400 shrink-0" />
                    )}
                  </div>

                  <div className="text-zinc-300">
                    <div>
                      Vaše odpoveď:{' '}
                      <span className={isCorrect ? 'font-bold text-emerald-400' : 'font-bold text-rose-400'}>
                        {userAns !== undefined && userAns >= 0 ? q.options[userAns] : 'Nezodpovězeno'}
                      </span>
                    </div>
                    {!isCorrect && (
                      <div>
                        Správná odpoveď:{' '}
                        <span className="font-bold text-emerald-400">{q.options[q.answer]}</span>
                      </div>
                    )}
                  </div>

                  <p className="text-slate-400 italic bg-[#09090b] p-3 rounded-xl border border-zinc-800">
                    {q.explanation}
                  </p>
                </div>
              );
            })}
          </div>

          {/* Bottom Control Buttons */}
          <div className="flex flex-col sm:flex-row gap-4 pt-4 border-t border-zinc-800">
            <button
              onClick={startQuiz}
              className="flex-1 py-3.5 bg-gradient-to-r from-indigo-500 to-purple-600 hover:from-indigo-600 hover:to-purple-700 text-white font-bold rounded-2xl shadow-lg shadow-indigo-500/20 transition flex items-center justify-center space-x-2"
            >
              <RotateCcw className="w-4 h-4" />
              <span>Spustit nový test</span>
            </button>
            <button
              onClick={onGoToTheory}
              className="px-6 py-3.5 bg-zinc-800 hover:bg-zinc-700 text-white font-bold rounded-2xl transition text-center border border-zinc-700"
            >
              Projít si znovu teorii
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
