import React from 'react';
import { BarChart2, Award, Clock, CheckCircle2, Trash2, RotateCcw } from 'lucide-react';
import { QuizResult } from '../types';

interface StatsSectionProps {
  quizHistory: QuizResult[];
  onClearStats: () => void;
  onGoToTest: () => void;
}

export const StatsSection: React.FC<StatsSectionProps> = ({
  quizHistory,
  onClearStats,
  onGoToTest,
}) => {
  const totalTests = quizHistory.length;
  const averageScore =
    totalTests > 0
      ? Math.round(quizHistory.reduce((acc, curr) => acc + curr.percentage, 0) / totalTests)
      : 0;
  const bestScore =
    totalTests > 0 ? Math.max(...quizHistory.map((curr) => curr.percentage)) : 0;
  const totalTimeSeconds = quizHistory.reduce((acc, curr) => acc + curr.timeSpentSeconds, 0);

  const formatMinutes = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}m ${secs}s`;
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      {/* Header */}
      <div className="text-center space-y-3 max-w-2xl mx-auto">
        <div className="inline-flex items-center space-x-2 px-4 py-1.5 rounded-full bg-indigo-500/10 text-indigo-400 border border-indigo-500/20 text-xs font-bold uppercase tracking-widest">
          <BarChart2 className="w-4 h-4 text-indigo-400" />
          <span>Analytický Přehled • Progress Engine</span>
        </div>
        <h2 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight">Přehled vašeho pokroku</h2>
        <p className="text-slate-400 text-sm sm:text-base leading-relaxed">
          Zde vidíte historii dokončených testů, celkovou úspěšnost a čas strávený procvičováním.
        </p>
      </div>

      {/* Summary KPI Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div className="bg-[#18181b] p-5.5 rounded-3xl shadow-xl border border-zinc-800 flex flex-col justify-between space-y-3">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-xs font-bold uppercase tracking-widest">Testy</span>
            <Award className="w-5 h-5 text-indigo-400" />
          </div>
          <p className="text-3xl sm:text-4xl font-black text-white tracking-tight">{totalTests}</p>
          <span className="text-xs text-slate-400 font-medium">dokončených testů</span>
        </div>

        <div className="bg-[#18181b] p-5.5 rounded-3xl shadow-xl border border-zinc-800 flex flex-col justify-between space-y-3">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-xs font-bold uppercase tracking-widest">Průměr</span>
            <BarChart2 className="w-5 h-5 text-emerald-400" />
          </div>
          <p className="text-3xl sm:text-4xl font-black text-white tracking-tight">{averageScore}%</p>
          <span className="text-xs text-slate-400 font-medium">průměrná úspěšnost</span>
        </div>

        <div className="bg-[#18181b] p-5.5 rounded-3xl shadow-xl border border-zinc-800 flex flex-col justify-between space-y-3">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-xs font-bold uppercase tracking-widest">Nejlepší</span>
            <CheckCircle2 className="w-5 h-5 text-purple-400" />
          </div>
          <p className="text-3xl sm:text-4xl font-black text-white tracking-tight">{bestScore}%</p>
          <span className="text-xs text-slate-400 font-medium">osobní rekord</span>
        </div>

        <div className="bg-[#18181b] p-5.5 rounded-3xl shadow-xl border border-zinc-800 flex flex-col justify-between space-y-3">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-xs font-bold uppercase tracking-widest">Čas</span>
            <Clock className="w-5 h-5 text-amber-400" />
          </div>
          <p className="text-2xl sm:text-3xl font-black text-white tracking-tight">{formatMinutes(totalTimeSeconds)}</p>
          <span className="text-xs text-slate-400 font-medium">celkový čas testů</span>
        </div>
      </div>

      {/* History Table */}
      <div className="bg-[#18181b] rounded-3xl shadow-xl p-6 sm:p-8 border border-zinc-800 space-y-5">
        <div className="flex items-center justify-between border-b border-zinc-800 pb-4">
          <h3 className="text-xl font-bold text-white">Historie výsledků</h3>

          {totalTests > 0 && (
            <button
              onClick={onClearStats}
              className="text-xs font-bold text-rose-400 hover:text-rose-300 flex items-center space-x-1.5 px-3.5 py-1.5 rounded-xl hover:bg-rose-950/50 border border-transparent hover:border-rose-800/60 transition"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>Smazat historii</span>
            </button>
          )}
        </div>

        {totalTests === 0 ? (
          <div className="text-center py-10 space-y-3">
            <p className="text-slate-400 text-sm">Zatím jste nedokončili žádný test.</p>
            <button
              onClick={onGoToTest}
              className="px-6 py-3 bg-gradient-to-r from-indigo-500 to-purple-600 hover:from-indigo-600 hover:to-purple-700 text-white font-bold rounded-2xl text-xs transition shadow-lg shadow-indigo-500/20 border border-indigo-400/30"
            >
              Spustit první test
            </button>
          </div>
        ) : (
          <div className="space-y-3 max-h-[400px] overflow-y-auto pr-1">
            {quizHistory.map((res) => (
              <div
                key={res.id}
                className="p-4 rounded-2xl border border-zinc-800 bg-[#09090b] flex items-center justify-between text-xs sm:text-sm hover:border-zinc-700 transition"
              >
                <div>
                  <div className="font-bold text-white">
                    Kategorie: {res.category === 'all' ? 'Všechny časy' : res.category}
                  </div>
                  <div className="text-slate-400 text-xs mt-0.5">
                    {res.date} • {res.score} z {res.totalQuestions} správně ({res.timeSpentSeconds}s)
                  </div>
                </div>

                <div
                  className={`px-3.5 py-1.5 rounded-xl font-black text-sm border ${
                    res.percentage >= 80
                      ? 'bg-emerald-950/80 text-emerald-300 border-emerald-800/80'
                      : res.percentage >= 50
                      ? 'bg-amber-950/80 text-amber-300 border-amber-800/80'
                      : 'bg-rose-950/80 text-rose-300 border-rose-800/80'
                  }`}
                >
                  {res.percentage}%
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
