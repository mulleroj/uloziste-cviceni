
export enum GameState {
  START = 'START',
  PLAYING = 'PLAYING',
  RESULT = 'RESULT'
}

export enum Difficulty {
  EASY = 'EASY',
  MEDIUM = 'MEDIUM',
  HARD = 'HARD'
}

export type FeedbackType = 'correct' | 'wrong' | null;

export interface Building {
  id: string;
  name: string;
  x: number;
  y: number;
  color: string;
  isEasy?: boolean; // If true, visible in Easy mode
}

export interface Task {
  start: string;
  directions: string;
  correctId: string;
  clue: string;
  difficulty: Difficulty;
}

export interface SessionResult {
  id: string;
  score: number;
  total: number;
  difficulty: Difficulty;
  timestamp: number;
}

/**
 * Interface for AI-generated feedback and grammar tips.
 * Added to fix the 'Module "../types" has no exported member "ExplanationResponse"' error.
 */
export interface ExplanationResponse {
  explanation: string;
  grammarTip: string;
}
