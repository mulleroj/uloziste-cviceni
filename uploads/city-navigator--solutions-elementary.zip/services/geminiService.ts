
import { GoogleGenAI, Type } from "@google/genai";
import { ExplanationResponse } from "../types";

// Always use const ai = new GoogleGenAI({apiKey: process.env.API_KEY}); as per guidelines
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const getGeminiExplanation = async (direction: string, startPoint: string, destination: string): Promise<ExplanationResponse> => {
  // Graceful handling for offline
  if (!navigator.onLine) {
    return {
      explanation: "AI explanation is not available in offline mode. Please connect to the internet.",
      grammarTip: "Check your connection!"
    };
  }

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `Explain why the following directions lead from ${startPoint} to ${destination}. Directions: "${direction}". Also, provide a short grammar tip related to prepositions of place or motion (e.g., 'next to', 'past', 'along').`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            explanation: {
              type: Type.STRING,
              description: "A clear explanation of the path taken.",
            },
            grammarTip: {
              type: Type.STRING,
              description: "A short educational tip about the English grammar used.",
            },
          },
          required: ["explanation", "grammarTip"],
        },
      },
    });

    // Accessing .text property directly (not a method) as per Google GenAI SDK rules
    const text = response.text;
    if (!text) {
      throw new Error("Empty response from AI");
    }

    return JSON.parse(text.trim());
  } catch (error) {
    console.error("Gemini API Error:", error);
    return {
      explanation: "Could not retrieve AI explanation at this moment.",
      grammarTip: "Keep practicing your directions!"
    };
  }
};
