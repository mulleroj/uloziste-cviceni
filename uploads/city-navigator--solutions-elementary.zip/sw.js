
const CACHE_NAME = 'city-navigator-v3';
const ASSETS_TO_CACHE = [
  './',
  './index.html',
  './manifest.json',
  'https://cdn.tailwindcss.com',
  'https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap'
];

// Instalace - uložení základních souborů
self.addEventListener('install', (event) => {
  self.skipWaiting();
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => {
      return cache.addAll(ASSETS_TO_CACHE);
    })
  );
});

// Aktivace - vyčištění starých verzí
self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((keys) => {
      return Promise.all(
        keys.filter((key) => key !== CACHE_NAME).map((key) => caches.delete(key))
      );
    })
  );
});

// Strategie: Cache First, pak Network (pro offline rychlost)
self.addEventListener('fetch', (event) => {
  // AI požadavky ignorujeme (vždy vyžadují síť)
  if (event.request.url.includes('generativelanguage.googleapis.com')) {
    return;
  }

  event.respondWith(
    caches.match(event.request).then((cachedResponse) => {
      if (cachedResponse) {
        return cachedResponse;
      }
      return fetch(event.request).then((response) => {
        // Ukládáme externí moduly z esm.sh do mezipaměti pro příště
        if (event.request.url.includes('esm.sh') || event.request.url.includes('fonts.gstatic.com')) {
          const responseToCache = response.clone();
          caches.open(CACHE_NAME).then((cache) => {
            cache.put(event.request, responseToCache);
          });
        }
        return response;
      });
    }).catch(() => {
      // Pokud selže i síť, vrátíme index.html (pro Single Page App)
      if (event.request.mode === 'navigate') {
        return caches.match('./index.html');
      }
    })
  );
});
