
import React, { useState, useCallback, useEffect } from 'react';
import { 
  Compass, 
  Trophy, 
  QrCode, 
  XCircle, 
  Navigation, 
  RefreshCw,
  Zap,
  Gamepad2,
  Mountain,
  History,
  Trash2,
  BookOpen
} from 'lucide-react';
import { GameState, Task, FeedbackType, Difficulty, SessionResult } from './types';
import { BUILDINGS, TASK_DATABASE } from './constants';
import CityMap from './components/CityMap';
import InstructionPanel from './components/InstructionPanel';
import GameResult from './components/GameResult';
import Header from './components/Header';

const STORAGE_KEY = 'city_navigator_history';

const App: React.FC = () => {
  const [gameState, setGameState] = useState<GameState>(GameState.START);
  const [difficulty, setDifficulty] = useState<Difficulty>(Difficulty.MEDIUM);
  const [activeLevels, setActiveLevels] = useState<Task[]>([]);
  const [currentLevelIdx, setCurrentLevelIdx] = useState(0);
  const [score, setScore] = useState(0);
  const [feedback, setFeedback] = useState<FeedbackType>(null);
  const [selectedBuildingId, setSelectedBuildingId] = useState<string | null>(null);
  const [showQr, setShowQr] = useState(false);
  const [history, setHistory] = useState<SessionResult[]>([]);

  // Load history on mount
  useEffect(() => {
    const stored = localStorage.getItem(STORAGE_KEY);
    if (stored) {
      try {
        setHistory(JSON.parse(stored));
      } catch (e) {
        console.error("Failed to parse history", e);
      }
    }
  }, []);

  const saveResult = useCallback((finalScore: number, total: number, diff: Difficulty) => {
    const newResult: SessionResult = {
      id: crypto.randomUUID(),
      score: finalScore,
      total,
      difficulty: diff,
      timestamp: Date.now()
    };
    const updatedHistory = [newResult, ...history].slice(0, 10);
    setHistory(updatedHistory);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(updatedHistory));
  }, [history]);

  const clearHistory = () => {
    setHistory([]);
    localStorage.removeItem(STORAGE_KEY);
  };

  const handleStart = useCallback((selectedDiff: Difficulty) => {
    setDifficulty(selectedDiff);
    const filteredTasks = TASK_DATABASE.filter(task => task.difficulty === selectedDiff);
    const count = selectedDiff === Difficulty.EASY ? 5 : selectedDiff === Difficulty.MEDIUM ? 10 : 15;
    
    const shuffled = [...filteredTasks].sort(() => 0.5 - Math.random());
    setActiveLevels(shuffled.slice(0, count));
    
    setGameState(GameState.PLAYING);
    setCurrentLevelIdx(0);
    setScore(0);
    setFeedback(null);
    setSelectedBuildingId(null);
  }, []);

  const handleBuildingClick = useCallback(async (id: string) => {
    if (feedback || gameState !== GameState.PLAYING) return;
    
    setSelectedBuildingId(id);
    const currentTask = activeLevels[currentLevelIdx];
    
    if (id === currentTask.correctId) {
      setFeedback('correct');
      setScore(prev => prev + 1);
    } else {
      setFeedback('wrong');
    }
  }, [feedback, gameState, activeLevels, currentLevelIdx]);

  const nextLevel = useCallback(() => {
    if (currentLevelIdx < activeLevels.length - 1) {
      setCurrentLevelIdx(prev => prev + 1);
      setFeedback(null);
      setSelectedBuildingId(null);
    } else {
      saveResult(score, activeLevels.length, difficulty);
      setGameState(GameState.RESULT);
    }
  }, [currentLevelIdx, activeLevels.length, score, difficulty, saveResult]);

  const appUrl = window.location.href;
  const qrImageUrl = `https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=${encodeURIComponent(appUrl)}`;

  const getDiffIcon = (diff: Difficulty) => {
    switch (diff) {
      case Difficulty.EASY: return <Zap className="w-4 h-4 text-emerald-500" />;
      case Difficulty.MEDIUM: return <Gamepad2 className="w-4 h-4 text-amber-500" />;
      case Difficulty.HARD: return <Mountain className="w-4 h-4 text-rose-500" />;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col items-center">
      <div className="max-w-6xl w-full p-4 md:p-8 flex flex-col gap-6">
        
        <Header 
          score={score} 
          total={activeLevels.length || 10} 
          currentIdx={currentLevelIdx} 
          gameState={gameState} 
          difficulty={difficulty}
        />

        {gameState === GameState.START && (
          <div className="flex flex-col gap-8 animate-in fade-in duration-700">
            <div className="bg-white rounded-3xl shadow-xl border border-gray-100 p-8 md:p-16 text-center">
              <div className="bg-indigo-50 w-28 h-28 rounded-full flex items-center justify-center mx-auto mb-8 shadow-inner">
                <Compass className="w-14 h-14 text-indigo-600 animate-pulse" />
              </div>
              <h2 className="text-4xl font-extrabold text-gray-900 mb-4 tracking-tight">City Navigator Challenge</h2>
              <p className="text-gray-600 mb-10 text-xl max-w-xl mx-auto leading-relaxed">
                Master your English directions! Choose your level and navigate the city.
                <span className="block mt-2 text-emerald-600 text-sm font-bold uppercase tracking-widest">Fully Offline Experience</span>
              </p>
              
              <div className="grid md:grid-cols-3 gap-6 mb-12 max-w-4xl mx-auto">
                <button onClick={() => handleStart(Difficulty.EASY)} className="group p-6 bg-emerald-50 hover:bg-emerald-100 border-2 border-emerald-200 rounded-3xl transition-all hover:scale-105 text-left">
                  <div className="bg-emerald-500 w-12 h-12 rounded-2xl flex items-center justify-center mb-4 shadow-lg group-hover:rotate-12 transition-transform">
                    <Zap className="text-white w-6 h-6" />
                  </div>
                  <h3 className="text-xl font-black text-emerald-900 mb-2 uppercase tracking-tight">Easy</h3>
                  <p className="text-sm text-emerald-700 font-medium">5 Missions. Simple directions.</p>
                </button>
                <button onClick={() => handleStart(Difficulty.MEDIUM)} className="group p-6 bg-amber-50 hover:bg-amber-100 border-2 border-amber-200 rounded-3xl transition-all hover:scale-105 text-left">
                  <div className="bg-amber-500 w-12 h-12 rounded-2xl flex items-center justify-center mb-4 shadow-lg group-hover:rotate-12 transition-transform">
                    <Gamepad2 className="text-white w-6 h-6" />
                  </div>
                  <h3 className="text-xl font-black text-amber-900 mb-2 uppercase tracking-tight">Medium</h3>
                  <p className="text-sm text-amber-700 font-medium">10 Missions. Standard vocabulary.</p>
                </button>
                <button onClick={() => handleStart(Difficulty.HARD)} className="group p-6 bg-rose-50 hover:bg-rose-100 border-2 border-rose-200 rounded-3xl transition-all hover:scale-105 text-left">
                  <div className="bg-rose-500 w-12 h-12 rounded-2xl flex items-center justify-center mb-4 shadow-lg group-hover:rotate-12 transition-transform">
                    <Mountain className="text-white w-6 h-6" />
                  </div>
                  <h3 className="text-xl font-black text-rose-900 mb-2 uppercase tracking-tight">Hard</h3>
                  <p className="text-sm text-rose-700 font-medium">15 Missions. Complex routes.</p>
                </button>
              </div>

              <div className="flex flex-col items-center gap-6">
                <button onClick={() => setShowQr(!showQr)} className="flex items-center justify-center gap-2 text-indigo-600 font-bold hover:text-indigo-800 transition-colors">
                  {showQr ? <XCircle className="w-5 h-5" /> : <QrCode className="w-5 h-5" />}
                  {showQr ? "Close QR Code" : "Share with Students"}
                </button>
                {showQr && (
                  <div className="p-6 bg-gray-50 rounded-2xl border-2 border-dashed border-gray-200 flex flex-col items-center animate-in zoom-in duration-300">
                    <div className="bg-white p-4 rounded-xl shadow-md"><img src={qrImageUrl} alt="QR Code" className="w-32 h-32" /></div>
                  </div>
                )}
              </div>
            </div>

            {history.length > 0 && (
              <div className="bg-white rounded-3xl shadow-lg border border-gray-100 p-8">
                <div className="flex items-center justify-between mb-6">
                  <h3 className="text-xl font-black text-gray-800 flex items-center gap-3"><History className="w-6 h-6 text-indigo-500" />Recent Results</h3>
                  <button onClick={clearHistory} className="text-rose-500 hover:text-rose-700 p-2 rounded-xl hover:bg-rose-50 transition-colors flex items-center gap-2 text-sm font-bold"><Trash2 className="w-4 h-4" />Clear</button>
                </div>
                <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
                  {history.map((res) => (
                    <div key={res.id} className="bg-gray-50 rounded-2xl p-4 border border-gray-100 flex items-center justify-between group hover:border-indigo-200 transition-colors">
                      <div className="flex items-center gap-3">
                        <div className="p-2 bg-white rounded-xl shadow-sm">{getDiffIcon(res.difficulty)}</div>
                        <div>
                          <p className="text-xs font-black text-gray-400 uppercase tracking-widest">{res.difficulty}</p>
                          <p className="text-[10px] text-gray-400 font-medium">{new Date(res.timestamp).toLocaleDateString()}</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="text-xl font-black text-indigo-600 leading-none">{res.score}<span className="text-gray-300 text-sm font-bold">/{res.total}</span></p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}

        {gameState === GameState.PLAYING && activeLevels.length > 0 && (
          <div className="grid lg:grid-cols-12 gap-8 items-start">
            <div className="lg:col-span-5 flex flex-col gap-6">
              <InstructionPanel task={activeLevels[currentLevelIdx]} feedback={feedback} onNext={nextLevel} isLastLevel={currentLevelIdx === activeLevels.length - 1} />

              {feedback && (
                <div className="bg-white p-6 rounded-2xl shadow-lg border-2 border-emerald-100 flex flex-col gap-4 animate-in slide-in-from-bottom duration-500">
                  <h4 className="flex items-center gap-2 font-bold uppercase tracking-wider text-sm text-emerald-700">
                    <BookOpen className="w-4 h-4" /> Learning Tip
                  </h4>
                  <div className="bg-emerald-50 p-4 rounded-xl">
                    <p className="text-sm text-emerald-800 font-medium">
                      Always pay attention to keywords:
                    </p>
                    <ul className="text-xs text-emerald-600 mt-2 list-disc list-inside space-y-1">
                      <li><strong>Next to:</strong> side by side</li>
                      <li><strong>Past:</strong> go further than</li>
                      <li><strong>Along:</strong> follow the path of the street</li>
                      <li><strong>Opposite:</strong> on the other side of the road</li>
                    </ul>
                  </div>
                </div>
              )}
            </div>

            <div className="lg:col-span-7">
              <CityMap buildings={BUILDINGS} selectedId={selectedBuildingId} feedback={feedback} correctId={activeLevels[currentLevelIdx].correctId} startBuildingName={activeLevels[currentLevelIdx].start} difficulty={difficulty} onBuildingClick={handleBuildingClick} />
            </div>
          </div>
        )}

        {gameState === GameState.RESULT && (
          <GameResult score={score} total={activeLevels.length} onRestart={() => setGameState(GameState.START)} />
        )}

      </div>
      
      <footer className="mt-auto py-8 text-gray-400 text-[10px] font-bold tracking-[0.2em] uppercase text-center w-full bg-white border-t border-gray-100">
        Interactive Learning System &bull; Offline Ready
      </footer>
    </div>
  );
};

export default App;
