
import React from 'react';
import { MapPin, CheckCircle, XCircle, ArrowRight } from 'lucide-react';
import { Task, FeedbackType } from '../types';

interface InstructionPanelProps {
  task: Task;
  feedback: FeedbackType;
  onNext: () => void;
  isLastLevel: boolean;
}

const InstructionPanel: React.FC<InstructionPanelProps> = ({ task, feedback, onNext, isLastLevel }) => {
  return (
    <div className="flex flex-col gap-6">
      <div className="bg-white border border-gray-100 rounded-3xl p-8 shadow-xl relative overflow-hidden group">
        <div className="absolute top-0 left-0 w-2 h-full bg-indigo-600 group-hover:w-3 transition-all duration-300"></div>
        
        <div className="flex items-center gap-3 mb-6">
          <div className="bg-indigo-50 p-2 rounded-xl text-indigo-600">
            <MapPin className="w-5 h-5" />
          </div>
          <div>
            <p className="text-[10px] font-black text-indigo-400 uppercase tracking-widest leading-none mb-1">Starting Point</p>
            <p className="text-xl font-black text-gray-800">{task.start}</p>
          </div>
        </div>

        <div className="space-y-4">
          <p className="text-2xl md:text-3xl font-bold text-gray-800 leading-tight italic decoration-indigo-200 underline decoration-4 underline-offset-8">
            "{task.directions}"
          </p>
        </div>
      </div>

      {feedback && (
        <div className={`
          p-8 rounded-3xl shadow-2xl flex flex-col gap-6 animate-in zoom-in duration-300 border-4
          ${feedback === 'correct' ? 'bg-emerald-50 border-emerald-200' : 'bg-rose-50 border-rose-200'}
        `}>
          <div className="flex items-center gap-5">
            <div className={`p-4 rounded-2xl ${feedback === 'correct' ? 'bg-emerald-500 shadow-emerald-200 shadow-lg' : 'bg-rose-500 shadow-rose-200 shadow-lg'}`}>
              {feedback === 'correct' ? 
                <CheckCircle className="w-8 h-8 text-white" /> : 
                <XCircle className="w-8 h-8 text-white" />
              }
            </div>
            <div>
              <h3 className={`text-2xl font-black uppercase tracking-tight ${feedback === 'correct' ? 'text-emerald-700' : 'text-rose-700'}`}>
                {feedback === 'correct' ? 'Excellent!' : 'Missed it!'}
              </h3>
              <p className={`text-sm font-bold opacity-80 ${feedback === 'correct' ? 'text-emerald-600' : 'text-rose-600'}`}>
                {feedback === 'correct' ? 'You reached the correct destination.' : task.clue}
              </p>
            </div>
          </div>

          <button 
            onClick={onNext}
            className={`
              w-full py-5 rounded-2xl font-black text-xl transition-all shadow-xl flex items-center justify-center gap-3
              ${feedback === 'correct' ? 'bg-emerald-600 hover:bg-emerald-700 text-white' : 'bg-rose-600 hover:bg-rose-700 text-white'}
              hover:scale-[1.02] active:scale-95
            `}
          >
            {isLastLevel ? 'View Results' : 'Next Challenge'}
            <ArrowRight className="w-6 h-6" />
          </button>
        </div>
      )}
    </div>
  );
};

export default InstructionPanel;
