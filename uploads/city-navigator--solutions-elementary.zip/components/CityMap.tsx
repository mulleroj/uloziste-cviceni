
import React from 'react';
import { Building, FeedbackType, Difficulty } from '../types';
import { MapPin } from 'lucide-react';

interface CityMapProps {
  buildings: Building[];
  selectedId: string | null;
  feedback: FeedbackType;
  correctId: string;
  startBuildingName: string;
  difficulty: Difficulty;
  onBuildingClick: (id: string) => void;
}

const CityMap: React.FC<CityMapProps> = ({ buildings, selectedId, feedback, correctId, startBuildingName, difficulty, onBuildingClick }) => {
  // In Easy mode, we hide some distracting buildings
  const visibleBuildings = buildings.filter(b => difficulty !== Difficulty.EASY || b.isEasy);

  return (
    <div className="relative bg-gray-200 rounded-[2.5rem] p-6 md:p-10 aspect-square shadow-2xl border-[12px] border-gray-300 ring-1 ring-gray-400/20 overflow-hidden">
      {/* Street Background Lines */}
      <div className="absolute inset-0 grid grid-cols-5 grid-rows-5 pointer-events-none p-6 md:p-10 opacity-60">
        <div className="col-start-2 col-end-2 row-span-full border-x-4 border-gray-400 border-dashed bg-gray-400/5"></div>
        <div className="col-start-4 col-end-4 row-span-full border-x-4 border-gray-400 border-dashed bg-gray-400/5"></div>
        <div className="row-start-2 row-end-2 col-span-full border-y-4 border-gray-400 border-dashed bg-gray-400/5"></div>
        <div className="row-start-4 row-end-4 col-span-full border-y-4 border-gray-400 border-dashed bg-gray-400/5"></div>
      </div>

      {/* Street Name Labels */}
      <div className="absolute top-[30%] left-0 w-full text-center -translate-y-1/2 pointer-events-none z-20">
        <span className="bg-gray-800 text-white px-3 py-1 rounded-md text-[9px] md:text-[11px] font-black uppercase tracking-[0.2em] shadow-lg border border-gray-600">High Street</span>
      </div>
      <div className="absolute top-[70%] left-0 w-full text-center -translate-y-1/2 pointer-events-none z-20">
        <span className="bg-gray-800 text-white px-3 py-1 rounded-md text-[9px] md:text-[11px] font-black uppercase tracking-[0.2em] shadow-lg border border-gray-600">Park Road</span>
      </div>
      
      <div className="absolute left-[30%] top-0 h-full flex items-center -translate-x-1/2 pointer-events-none z-20">
        <span className="bg-gray-700 text-white px-2 py-1 rounded-md text-[8px] md:text-[10px] font-black uppercase tracking-widest origin-center -rotate-90 whitespace-nowrap shadow-lg border border-gray-600">Station Road</span>
      </div>
      <div className="absolute left-[70%] top-0 h-full flex items-center -translate-x-1/2 pointer-events-none z-20">
        <span className="bg-gray-700 text-white px-2 py-1 rounded-md text-[8px] md:text-[10px] font-black uppercase tracking-widest origin-center -rotate-90 whitespace-nowrap shadow-lg border border-gray-600">Main Street</span>
      </div>

      {/* Building Grid */}
      <div className="grid grid-cols-5 grid-rows-5 gap-3 h-full relative z-30">
        {visibleBuildings.map((b) => {
          const isStart = b.name === startBuildingName;
          
          return (
            <button
              key={b.id}
              onClick={() => onBuildingClick(b.id)}
              style={{ gridColumn: b.x, gridRow: b.y }}
              className={`
                ${b.color} border-b-8 border-r-8 border-gray-400/40 rounded-3xl flex flex-col items-center justify-center p-3
                transition-all duration-300 transform active:scale-90 relative
                ${!feedback ? 'hover:scale-105 hover:shadow-xl hover:brightness-105 cursor-pointer' : 'cursor-default'}
                ${selectedId === b.id ? 'ring-8 ring-indigo-500 shadow-2xl scale-110 z-40' : 'shadow-md'}
                ${feedback === 'wrong' && b.id === correctId ? 'animate-bounce ring-8 ring-emerald-500 z-40 bg-emerald-50' : ''}
                ${feedback === 'correct' && b.id === correctId ? 'ring-8 ring-emerald-500 z-40' : ''}
              `}
            >
              {isStart && (
                <div className="absolute -top-6 left-1/2 -translate-x-1/2 flex flex-col items-center animate-bounce pointer-events-none z-50">
                   <div className="bg-indigo-600 text-white text-[8px] md:text-[10px] font-black px-2 py-0.5 rounded-full shadow-lg whitespace-nowrap uppercase tracking-tighter">
                    You are here
                  </div>
                  <div className="w-2 h-2 bg-indigo-600 rotate-45 -mt-1 shadow-lg"></div>
                </div>
              )}

              <span className="text-[10px] sm:text-sm md:text-base font-black text-gray-800 text-center leading-tight uppercase tracking-tight break-words px-1">
                {b.name}
              </span>
              
              {isStart && (
                <div className="mt-1">
                  <div className="w-2 h-2 bg-indigo-600 rounded-full animate-ping absolute"></div>
                  <div className="w-2 h-2 bg-indigo-600 rounded-full relative"></div>
                </div>
              )}
            </button>
          );
        })}
      </div>
    </div>
  );
};

export default CityMap;
