
import React from 'react';
import { RefreshCw, Star, Trophy } from 'lucide-react';

interface GameResultProps {
  score: number;
  total: number;
  onRestart: () => void;
}

const GameResult: React.FC<GameResultProps> = ({ score, total, onRestart }) => {
  const percentage = (score / total) * 100;
  
  const getFeedback = () => {
    if (percentage === 100) return "Master Navigator! You found every location perfectly.";
    if (percentage >= 80) return "Impressive! You have a great sense of direction.";
    if (percentage >= 50) return "Good job! A few more practice runs and you'll be an expert.";
    return "Keep practicing. Every great traveler gets lost sometimes!";
  };

  return (
    <div className="bg-white rounded-[3rem] shadow-2xl border border-gray-100 p-12 md:p-20 text-center animate-in zoom-in duration-700 overflow-hidden relative">
      <div className="absolute top-0 left-0 w-full h-2 bg-gradient-to-r from-indigo-500 via-purple-500 to-pink-500"></div>
      
      <div className="relative mb-12">
        <div className="absolute inset-0 bg-indigo-500/10 blur-3xl rounded-full scale-150"></div>
        <div className="relative inline-flex items-center justify-center">
          <div className="bg-indigo-600 w-48 h-48 rounded-full flex flex-col items-center justify-center shadow-[0_20px_50px_rgba(79,70,229,0.3)] border-[8px] border-white">
            <span className="text-6xl font-black text-white">{score}</span>
            <span className="text-indigo-200 font-bold uppercase text-[10px] tracking-[0.3em] mt-1">Out of {total}</span>
          </div>
          <div className="absolute -top-4 -right-4 bg-amber-400 p-3 rounded-2xl rotate-12 shadow-lg border-4 border-white">
            <Star className="w-8 h-8 text-white fill-white" />
          </div>
        </div>
      </div>

      <h2 className="text-5xl font-black text-gray-900 mb-4 tracking-tight">Mission Accomplished</h2>
      <p className="text-gray-500 text-xl mb-12 max-w-lg mx-auto leading-relaxed italic">
        "{getFeedback()}"
      </p>

      <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
        <button 
          onClick={onRestart}
          className="group flex items-center gap-4 bg-gray-900 hover:bg-black text-white px-12 py-6 rounded-[2rem] font-black text-2xl transition-all shadow-2xl hover:scale-105 active:scale-95"
        >
          <RefreshCw className="w-7 h-7 group-hover:rotate-180 transition-transform duration-500" />
          New Adventure
        </button>
      </div>

      <div className="mt-16 pt-8 border-t border-gray-50 flex items-center justify-center gap-2 text-indigo-400 font-bold uppercase tracking-widest text-[10px]">
        <Trophy className="w-4 h-4" />
        Shared on Leaderboard
      </div>
    </div>
  );
};

export default GameResult;
