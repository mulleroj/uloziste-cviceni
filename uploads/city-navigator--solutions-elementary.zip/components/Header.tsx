
import React from 'react';
import { Navigation, Trophy, Zap, Gamepad2, Mountain } from 'lucide-react';
import { GameState, Difficulty } from '../types';

interface HeaderProps {
  score: number;
  total: number;
  currentIdx: number;
  gameState: GameState;
  difficulty: Difficulty;
}

const Header: React.FC<HeaderProps> = ({ score, total, currentIdx, gameState, difficulty }) => {
  const getDifficultyIcon = () => {
    switch (difficulty) {
      case Difficulty.EASY: return <Zap className="w-3 h-3 text-emerald-500" />;
      case Difficulty.MEDIUM: return <Gamepad2 className="w-3 h-3 text-amber-500" />;
      case Difficulty.HARD: return <Mountain className="w-3 h-3 text-rose-500" />;
    }
  };

  const getDifficultyColor = () => {
    switch (difficulty) {
      case Difficulty.EASY: return 'text-emerald-300';
      case Difficulty.MEDIUM: return 'text-amber-300';
      case Difficulty.HARD: return 'text-rose-300';
    }
  };

  return (
    <div className="bg-indigo-600 rounded-3xl p-6 text-white flex justify-between items-center shadow-lg shadow-indigo-100 border border-indigo-500/20">
      <div className="flex items-center gap-4">
        <div className="bg-white/20 p-2 rounded-xl backdrop-blur-md">
          <Navigation className="w-7 h-7" />
        </div>
        <div>
          <h1 className="text-xl md:text-2xl font-black uppercase tracking-tight leading-none mb-1">
            City Navigator
          </h1>
          {gameState !== GameState.START && (
            <div className="flex items-center gap-1.5">
              {getDifficultyIcon()}
              <span className={`text-[10px] font-black uppercase tracking-[0.2em] ${getDifficultyColor()}`}>
                {difficulty} MODE
              </span>
            </div>
          )}
        </div>
      </div>
      
      <div className="flex items-center gap-3 md:gap-6">
        <div className="bg-white/10 px-4 py-2 rounded-2xl backdrop-blur-sm border border-white/10 flex items-center gap-2">
          <Trophy className="w-4 h-4 text-amber-300" />
          <span className="font-mono font-bold text-lg">{score}/{total}</span>
        </div>
        
        {gameState === GameState.PLAYING && (
          <div className="hidden sm:flex flex-col items-end">
            <span className="text-[10px] font-black uppercase tracking-widest text-indigo-200">Current Task</span>
            <span className="text-sm font-bold">{currentIdx + 1} of {total}</span>
          </div>
        )}
      </div>
    </div>
  );
};

export default Header;
