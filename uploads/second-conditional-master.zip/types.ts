
export interface Exercise {
  id: number;
  sentence: string; // e.g., "If I ___ (win) the lottery, I ___ (travel) around the world."
  parts: {
    before: string;
    gap1Label: string; // "win"
    middle: string;
    gap2Label: string; // "travel"
    after: string;
  };
  correctAnswers: {
    gap1: string[]; // ["won"]
    gap2: string[]; // ["would travel", "'d travel"]
  };
}

export type AppState = 'HOME' | 'QUIZ' | 'RESULTS';

export interface QuizResult {
  exerciseId: number;
  userAnswer1: string;
  userAnswer2: string;
  isCorrect1: boolean;
  isCorrect2: boolean;
}
