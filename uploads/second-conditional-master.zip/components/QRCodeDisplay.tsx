
import React from 'react';
import { QRCodeSVG } from 'qrcode.react';

const QRCodeDisplay: React.FC = () => {
  const currentUrl = window.location.href;

  return (
    <div className="flex flex-col items-center p-6 bg-white rounded-2xl shadow-sm border border-slate-100">
      <h3 className="text-lg font-semibold text-slate-800 mb-4">Sdílej se třídou</h3>
      <div className="p-4 bg-white border-4 border-indigo-50 rounded-xl">
        <QRCodeSVG value={currentUrl} size={180} />
      </div>
      <p className="mt-4 text-sm text-slate-500 text-center max-w-[200px]">
        Naskenuj kód a připoj se k procvičování na svém telefonu!
      </p>
    </div>
  );
};

export default QRCodeDisplay;
