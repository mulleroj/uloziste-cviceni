import React, { useState, useEffect, useRef } from 'react';
import { BookOpen, GraduationCap, CheckCircle, RotateCcw, ArrowRight, Trophy, Star, Clock, AlertTriangle } from 'lucide-react';
import QRCodeDisplay from './components/QRCodeDisplay';
import { Exercise, AppState, QuizResult } from './types';
import { EXERCISES_DB } from './data/exercises';

const App: React.FC = () => {
  const [appState, setAppState] = useState<AppState>('HOME');
  const [exercises, setExercises] = useState<Exercise[]>([]);
  const [results, setResults] = useState<QuizResult[]>([]);
  const [userAnswers, setUserAnswers] = useState<Record<string, string>>({});
  
  // Timer State
  const [isTimerEnabled, setIsTimerEnabled] = useState(false);
  const [timeLeft, setTimeLeft] = useState(15 * 60); // 15 minutes in seconds
  // Fix: Use number instead of NodeJS.Timeout to resolve "Cannot find namespace 'NodeJS'" error in browser environments.
  const timerRef = useRef<number | null>(null);

  const startQuiz = () => {
    const shuffled = [...EXERCISES_DB].sort(() => 0.5 - Math.random());
    const selected = shuffled.slice(0, 30);
    
    setExercises(selected);
    setUserAnswers({});
    setResults([]);
    setTimeLeft(15 * 60);
    setAppState('QUIZ');

    if (isTimerEnabled) {
      startTimer();
    }
  };

  const startTimer = () => {
    if (timerRef.current) clearInterval(timerRef.current);
    // Fix: Explicitly use window.setInterval to match the numeric type for timerRef in browser context
    timerRef.current = window.setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          if (timerRef.current) clearInterval(timerRef.current);
          checkResults(); // Auto-submit when time is up
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
  };

  useEffect(() => {
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, []);

  const simulatePerfectScore = () => {
    const shuffled = [...EXERCISES_DB].sort(() => 0.5 - Math.random());
    const selected = shuffled.slice(0, 30);
    setExercises(selected);
    
    const perfectResults: QuizResult[] = selected.map(ex => ({
      exerciseId: ex.id,
      userAnswer1: ex.correctAnswers.gap1[0],
      userAnswer2: ex.correctAnswers.gap2[0],
      isCorrect1: true,
      isCorrect2: true
    }));
    
    if (timerRef.current) clearInterval(timerRef.current);
    setResults(perfectResults);
    setAppState('RESULTS');
  };

  const handleInputChange = (exerciseId: number, gap: 'gap1' | 'gap2', value: string) => {
    setUserAnswers(prev => ({
      ...prev,
      [`${exerciseId}_${gap}`]: value
    }));
  };

  const checkResults = () => {
    if (timerRef.current) clearInterval(timerRef.current);
    
    const newResults: QuizResult[] = exercises.map(ex => {
      const ans1 = (userAnswers[`${ex.id}_gap1`] || '').trim().toLowerCase();
      const ans2 = (userAnswers[`${ex.id}_gap2`] || '').trim().toLowerCase();
      
      const isCorrect1 = ex.correctAnswers.gap1.some(a => a.toLowerCase() === ans1);
      const isCorrect2 = ex.correctAnswers.gap2.some(a => a.toLowerCase() === ans2);

      return {
        exerciseId: ex.id,
        userAnswer1: ans1,
        userAnswer2: ans2,
        isCorrect1,
        isCorrect2
      };
    });
    setResults(newResults);
    setAppState('RESULTS');
  };

  const score = results.filter(r => r.isCorrect1 && r.isCorrect2).length;
  const isPerfect = score === exercises.length && exercises.length > 0;

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs < 10 ? '0' : ''}${secs}`;
  };

  const timerColor = timeLeft > 300 ? 'text-slate-600' : timeLeft > 60 ? 'text-orange-500' : 'text-red-500 animate-pulse';

  return (
    <div className="min-h-screen flex flex-col items-center pb-20 bg-slate-50">
      {/* Header */}
      <header className="w-full max-w-4xl px-6 py-8 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="bg-indigo-600 p-2 rounded-lg text-white shadow-lg shadow-indigo-100">
            <GraduationCap size={24} />
          </div>
          <h1 className="text-2xl font-bold text-slate-800 tracking-tight">Second Conditional Master</h1>
        </div>
      </header>

      <main className="w-full max-w-4xl px-6">
        {appState === 'HOME' && (
          <div className="grid md:grid-cols-2 gap-12 items-center py-10">
            <div className="space-y-6">
              <div className="space-y-2">
                <span className="inline-block px-3 py-1 bg-indigo-100 text-indigo-700 text-xs font-bold rounded-full uppercase tracking-wider">
                  Grammar Practice
                </span>
                <h2 className="text-4xl font-extrabold text-slate-900 leading-tight">
                  Ovládni Druhý Kondicionál hravě!
                </h2>
                <p className="text-lg text-slate-600">
                  Cvičení pro úroveň <strong>Pre-Intermediate</strong>. Procvič si nereálné situace a sny v angličtině.
                </p>
              </div>

              <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 space-y-4">
                <h4 className="font-bold text-slate-800 flex items-center gap-2">
                  <BookOpen className="text-indigo-500" size={18} />
                  Rychlá pomůcka:
                </h4>
                <p className="text-sm text-slate-600 italic">
                  "If I <strong>won</strong> the lottery, I <strong>would buy</strong> a Ferrari."
                </p>
                <div className="grid grid-cols-2 gap-4 text-xs font-medium uppercase text-slate-500 tracking-wide">
                  <div className="p-3 bg-slate-50 rounded-lg border border-slate-100">
                    IF + PAST SIMPLE
                  </div>
                  <div className="p-3 bg-slate-50 rounded-lg border border-slate-100">
                    WOULD + INFINITIVE
                  </div>
                </div>
              </div>

              {/* Timer Toggle */}
              <div className="flex items-center gap-3 p-4 bg-white rounded-2xl border border-slate-100 shadow-sm">
                <div className={`p-2 rounded-lg ${isTimerEnabled ? 'bg-orange-100 text-orange-600' : 'bg-slate-100 text-slate-400'}`}>
                  <Clock size={20} />
                </div>
                <div className="flex-1">
                  <h5 className="text-sm font-bold text-slate-800">Časový limit (15 min)</h5>
                  <p className="text-xs text-slate-500">Test se automaticky ukončí po vypršení času.</p>
                </div>
                <button 
                  onClick={() => setIsTimerEnabled(!isTimerEnabled)}
                  className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors focus:outline-none ${isTimerEnabled ? 'bg-indigo-600' : 'bg-slate-200'}`}
                >
                  <span className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${isTimerEnabled ? 'translate-x-6' : 'translate-x-1'}`} />
                </button>
              </div>

              <button
                onClick={startQuiz}
                className="w-full sm:w-auto bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-4 px-8 rounded-2xl shadow-lg shadow-indigo-200 transition-all flex items-center justify-center gap-2 group"
              >
                Spustit cvičení (30 vět)
                <ArrowRight className="group-hover:translate-x-1 transition-transform" size={20} />
              </button>
            </div>

            <div className="flex justify-center">
              <QRCodeDisplay />
            </div>
          </div>
        )}

        {appState === 'QUIZ' && (
          <div className="space-y-8 py-6">
            <div className="flex items-center justify-between sticky top-4 z-20 bg-slate-50/90 backdrop-blur-md py-2 px-1 rounded-xl">
              <h3 className="text-xl font-bold text-slate-800">Doplň správné tvary sloves</h3>
              <div className="flex items-center gap-4">
                {isTimerEnabled && (
                  <div className={`flex items-center gap-2 px-3 py-1 rounded-full bg-white border border-slate-200 shadow-sm font-mono font-bold ${timerColor}`}>
                    <Clock size={16} />
                    {formatTime(timeLeft)}
                  </div>
                )}
                <span className="bg-white px-3 py-1 rounded-full border border-slate-200 text-sm font-bold text-slate-600 shadow-sm">
                  Věta: {Object.keys(userAnswers).length / 2 >> 0} / {exercises.length}
                </span>
              </div>
            </div>

            {isTimerEnabled && timeLeft < 60 && timeLeft > 0 && (
              <div className="bg-orange-50 border border-orange-200 text-orange-800 px-4 py-3 rounded-xl flex items-center gap-3 animate-pulse">
                <AlertTriangle size={20} />
                <span className="text-sm font-bold">Pozor! Zbývá ti méně než minuta!</span>
              </div>
            )}

            <div className="space-y-6">
              {exercises.map((ex, index) => (
                <div key={ex.id} className="bg-white p-6 md:p-8 rounded-2xl shadow-sm border border-slate-100 hover:border-indigo-100 transition-colors">
                  <div className="flex gap-4">
                    <span className="flex-shrink-0 w-8 h-8 rounded-full bg-indigo-50 text-indigo-600 flex items-center justify-center font-bold text-sm">
                      {index + 1}
                    </span>
                    <div className="text-lg leading-relaxed text-slate-800 flex flex-wrap items-center gap-y-4">
                      <span>{ex.parts.before}</span>
                      <div className="relative inline-flex flex-col mx-2 group">
                        <input
                          type="text"
                          className="px-3 py-1 border-b-2 border-indigo-200 focus:border-indigo-500 outline-none w-32 text-center font-medium bg-slate-50 rounded-t transition-all focus:bg-white"
                          placeholder="..."
                          value={userAnswers[`${ex.id}_gap1`] || ''}
                          onChange={(e) => handleInputChange(ex.id, 'gap1', e.target.value)}
                        />
                        <span className="text-[10px] text-slate-400 absolute -bottom-5 left-0 w-full text-center uppercase font-bold tracking-tighter opacity-70">
                          ({ex.parts.gap1Label})
                        </span>
                      </div>
                      <span>{ex.parts.middle}</span>
                      <div className="relative inline-flex flex-col mx-2 group">
                        <input
                          type="text"
                          className="px-3 py-1 border-b-2 border-indigo-200 focus:border-indigo-500 outline-none w-40 text-center font-medium bg-slate-50 rounded-t transition-all focus:bg-white"
                          placeholder="..."
                          value={userAnswers[`${ex.id}_gap2`] || ''}
                          onChange={(e) => handleInputChange(ex.id, 'gap2', e.target.value)}
                        />
                        <span className="text-[10px] text-slate-400 absolute -bottom-5 left-0 w-full text-center uppercase font-bold tracking-tighter opacity-70">
                          ({ex.parts.gap2Label})
                        </span>
                      </div>
                      <span>{ex.parts.after}</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            <div className="sticky bottom-6 left-0 w-full flex justify-center pt-4">
              <button
                onClick={checkResults}
                className="bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-4 px-10 rounded-2xl shadow-xl shadow-indigo-200 transform hover:scale-105 transition-all flex items-center gap-2"
              >
                Vyhodnotit test
                <CheckCircle size={20} />
              </button>
            </div>
          </div>
        )}

        {appState === 'RESULTS' && (
          <div className="space-y-10 py-10 animate-in fade-in slide-in-from-bottom-4 duration-500">
            <div className="text-center space-y-4 relative">
              {isPerfect && (
                <div className="absolute inset-0 flex items-center justify-center -z-10 overflow-visible">
                   <div className="w-64 h-64 bg-yellow-200 rounded-full blur-3xl opacity-30 animate-pulse"></div>
                </div>
              )}
              
              <div className={`inline-flex p-5 rounded-full mb-2 ${isPerfect ? 'bg-yellow-100 text-yellow-600' : 'bg-green-100 text-green-600'}`}>
                {isPerfect ? <Trophy size={64} className="animate-bounce" /> : <CheckCircle size={56} />}
              </div>
              
              <h2 className={`text-4xl font-black ${isPerfect ? 'text-yellow-600 tracking-widest uppercase' : 'text-slate-900'}`}>
                {isPerfect ? 'Perfektní výsledek!' : 'Skvělý výkon!'}
              </h2>
              
              <div className="flex justify-center items-center gap-3">
                <div className={`px-6 py-2 rounded-2xl border-2 flex items-baseline gap-1 ${isPerfect ? 'bg-yellow-50 border-yellow-200' : 'bg-white border-slate-100'}`}>
                  <span className={`text-6xl font-black ${isPerfect ? 'text-yellow-600' : 'text-indigo-600'}`}>{score}</span>
                  <span className="text-2xl text-slate-400 font-bold">/ {exercises.length}</span>
                </div>
              </div>
              
              <p className="text-slate-500 font-bold text-lg">
                {isPerfect ? 'Jsi mistr druhého kondicionálu! 🏆' : 'Výborně, jen tak dál!'}
              </p>

              {isTimerEnabled && timeLeft === 0 && (
                <div className="inline-block px-4 py-2 bg-red-100 text-red-700 rounded-full text-sm font-bold animate-pulse">
                  Vypršel časový limit!
                </div>
              )}
            </div>

            <div className="space-y-4">
              <h3 className="text-xl font-bold text-slate-800 px-2 flex items-center gap-2">
                <CheckCircle size={20} className="text-green-500" />
                Přehled tvých odpovědí:
              </h3>
              {exercises.map((ex) => {
                const res = results.find(r => r.exerciseId === ex.id);
                const bothCorrect = res?.isCorrect1 && res?.isCorrect2;
                
                return (
                  <div key={ex.id} className={`bg-white p-6 rounded-2xl shadow-sm border transition-all ${bothCorrect ? 'border-green-100 bg-green-50/30' : 'border-slate-100'} space-y-3`}>
                    <div className="text-slate-800 font-medium leading-relaxed flex items-start gap-3">
                      <div className="mt-1">
                         {bothCorrect ? <Star size={18} className="text-yellow-500 fill-yellow-500" /> : <div className="w-[18px]" />}
                      </div>
                      <div className="text-lg">
                        {ex.parts.before}
                        <span className={res?.isCorrect1 ? "text-green-600 font-bold px-1" : "text-red-500 font-bold underline px-1"}>
                          {res?.userAnswer1 || "___"}
                        </span>
                        {ex.parts.middle}
                        <span className={res?.isCorrect2 ? "text-green-600 font-bold px-1" : "text-red-500 font-bold underline px-1"}>
                          {res?.userAnswer2 || "___"}
                        </span>
                        {ex.parts.after}
                      </div>
                    </div>
                    {(!res?.isCorrect1 || !res?.isCorrect2) && (
                      <div className="ml-8 bg-white p-4 rounded-xl border border-red-100 text-sm shadow-sm">
                        <span className="font-bold text-slate-400 mr-2 uppercase tracking-tight">Správné řešení:</span>
                        <span className="text-indigo-600 font-bold">
                          "{ex.parts.before} <span className="underline">{ex.correctAnswers.gap1[0]}</span> {ex.parts.middle} <span className="underline">{ex.correctAnswers.gap2[0]}</span> {ex.parts.after}"
                        </span>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>

            <div className="flex flex-col sm:flex-row gap-4 justify-center pt-8">
              <button
                onClick={() => setAppState('HOME')}
                className="bg-slate-800 hover:bg-slate-900 text-white font-bold py-4 px-10 rounded-2xl shadow-xl shadow-slate-200 transition-all flex items-center justify-center gap-2"
              >
                Zpět na úvod
              </button>
              <button
                onClick={startQuiz}
                className="bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-4 px-10 rounded-2xl shadow-xl shadow-indigo-100 transition-all flex items-center justify-center gap-2"
              >
                Zkusit jiných 30 vět
                <RotateCcw size={20} />
              </button>
            </div>
          </div>
        )}
      </main>

      {/* Footer Branding */}
      <footer className="mt-auto pt-10 px-6 w-full max-w-4xl flex items-center justify-between text-slate-400 text-xs font-medium">
        <div>Grammar Master &copy; {new Date().getFullYear()} • Offline Edition</div>
        {appState === 'HOME' && (
          <button 
            onClick={simulatePerfectScore}
            className="text-slate-300 hover:text-indigo-400 transition-colors"
          >
            [ Simulovat 100% ]
          </button>
        )}
      </footer>
    </div>
  );
};

export default App;