/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { BookOpen, CheckCircle2, XCircle, ArrowRight, RefreshCcw, Info, Trophy, Gauge, PlusCircle, Share2, QrCode, X } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { QRCodeSVG } from 'qrcode.react';

const App = () => {
  const [activeTab, setActiveTab] = useState('theory');
  const [score, setScore] = useState(0);
  const [quizFinished, setQuizFinished] = useState(false);
  const [quizStarted, setQuizStarted] = useState(false);
  const [difficulty, setDifficulty] = useState(null);
  const [currentQuestionIdx, setCurrentQuestionIdx] = useState(0);
  const [selectedQuestions, setSelectedQuestions] = useState([]);
  const [feedback, setFeedback] = useState(null);
  const [hardSelectedIdx, setHardSelectedIdx] = useState(null);
  const [showShareModal, setShowShareModal] = useState(false);

  const appUrl = process.env.APP_URL || window.location.href;

  // --- DATA: Pool of questions ---
  const questionsPool = [
    { type: 'placement', sentence: 'I go to the cinema.', adverb: 'sometimes', options: ['I sometimes go to the cinema.', 'I go sometimes to the cinema.', 'I go to the cinema sometimes.'], correct: 0, level: 'easy' },
    { type: 'placement', sentence: 'We play football.', adverb: 'often', options: ['We often play football.', 'We play often football.', 'Often we play football.'], correct: 0, level: 'easy' },
    { type: 'placement', sentence: 'I help my mum.', adverb: 'usually', options: ['I usually help my mum.', 'I help usually my mum.', 'Usually I help my mum.'], correct: 0, level: 'easy' },
    { type: 'placement', sentence: 'They listen to music.', adverb: 'often', options: ['They often listen to music.', 'They listen often to music.', 'Often they listen to music.'], correct: 0, level: 'easy' },
    { type: 'placement', sentence: 'I eat vegetables.', adverb: 'always', options: ['I always eat vegetables.', 'I eat always vegetables.', 'Always I eat vegetables.'], correct: 0, level: 'easy' },
    { type: 'placement', sentence: 'She drinks coffee.', adverb: 'never', options: ['She never drinks coffee.', 'She drinks never coffee.', 'Never she drinks coffee.'], correct: 0, level: 'easy' },
    { type: 'placement', sentence: 'I do my homework.', adverb: 'always', options: ['I always do my homework.', 'I do always my homework.', 'Always I do my homework.'], correct: 0, level: 'easy' },
    { type: 'placement', sentence: 'We walk to school.', adverb: 'usually', options: ['We usually walk to school.', 'We walk usually to school.', 'Usually we walk to school.'], correct: 0, level: 'easy' },
    { type: 'placement', sentence: 'He works in an office.', adverb: 'sometimes', options: ['He sometimes works in an office.', 'He works sometimes in an office.', 'Sometimes he works in an office.'], correct: 0, level: 'easy' },
    { type: 'placement', sentence: 'I clean my room.', adverb: 'always', options: ['I always clean my room.', 'I clean always my room.', 'Always I clean my room.'], correct: 0, level: 'easy' },
    { type: 'placement', sentence: 'I brush my teeth.', adverb: 'always', options: ['I always brush my teeth.', 'I brush always my teeth.', 'Always I brush my teeth.'], correct: 0, level: 'easy' },
    { type: 'placement', sentence: 'She reads books.', adverb: 'often', options: ['She often reads books.', 'She reads often books.', 'Often she reads books.'], correct: 0, level: 'easy' },
    { type: 'placement', sentence: 'They watch TV.', adverb: 'sometimes', options: ['They sometimes watch TV.', 'They watch sometimes TV.', 'Sometimes they watch TV.'], correct: 0, level: 'easy' },
    { type: 'placement', sentence: 'We visit friends.', adverb: 'usually', options: ['We usually visit friends.', 'We visit usually friends.', 'Usually we visit friends.'], correct: 0, level: 'easy' },
    { type: 'placement', sentence: 'He plays tennis.', adverb: 'never', options: ['He never plays tennis.', 'He plays never tennis.', 'Never he plays tennis.'], correct: 0, level: 'easy' },
    { type: 'placement', sentence: 'I drink water.', adverb: 'always', options: ['I always drink water.', 'I drink always water.', 'Always I drink water.'], correct: 0, level: 'easy' },
    { type: 'placement', sentence: 'She cooks dinner.', adverb: 'often', options: ['She often cooks dinner.', 'She cooks often dinner.', 'Often she cooks dinner.'], correct: 0, level: 'easy' },
    { type: 'placement', sentence: 'They swim in the pool.', adverb: 'sometimes', options: ['They sometimes swim in the pool.', 'They swim sometimes in the pool.', 'Sometimes they swim in the pool.'], correct: 0, level: 'easy' },
    { type: 'placement', sentence: 'We use the computer.', adverb: 'usually', options: ['We usually use the computer.', 'We use usually the computer.', 'Usually we use the computer.'], correct: 0, level: 'easy' },
    { type: 'placement', sentence: 'He drives a car.', adverb: 'never', options: ['He never drives a car.', 'He drives never a car.', 'Never he drives a car.'], correct: 0, level: 'easy' },
    { type: 'placement', sentence: 'I wake up early.', adverb: 'always', options: ['I always wake up early.', 'I wake up always early.', 'Always I wake up early.'], correct: 0, level: 'easy' },
    { type: 'placement', sentence: 'She sings songs.', adverb: 'often', options: ['She often sings songs.', 'She sings often songs.', 'Often she sings songs.'], correct: 0, level: 'easy' },
    { type: 'placement', sentence: 'They run in the park.', adverb: 'sometimes', options: ['They sometimes run in the park.', 'They run sometimes in the park.', 'Sometimes they run in the park.'], correct: 0, level: 'easy' },
    { type: 'placement', sentence: 'We buy groceries.', adverb: 'usually', options: ['We usually buy groceries.', 'We buy usually groceries.', 'Usually we buy groceries.'], correct: 0, level: 'easy' },
    { type: 'placement', sentence: 'He speaks English.', adverb: 'never', options: ['He never speaks English.', 'He speaks never English.', 'Never he speaks English.'], correct: 0, level: 'easy' },
    { type: 'placement', sentence: 'I wear a hat.', adverb: 'sometimes', options: ['I sometimes wear a hat.', 'I wear sometimes a hat.', 'Sometimes I wear a hat.'], correct: 0, level: 'easy' },
    { type: 'placement', sentence: 'She takes the bus.', adverb: 'usually', options: ['She usually takes the bus.', 'She takes usually the bus.', 'Usually she takes the bus.'], correct: 0, level: 'easy' },
    { type: 'placement', sentence: 'They go to bed late.', adverb: 'often', options: ['They often go to bed late.', 'They go often to bed late.', 'Often they go to bed late.'], correct: 0, level: 'easy' },
    { type: 'placement', sentence: 'We have lunch at home.', adverb: 'always', options: ['We always have lunch at home.', 'We have always lunch at home.', 'Always we have lunch at home.'], correct: 0, level: 'easy' },
    { type: 'placement', sentence: 'He makes mistakes.', adverb: 'sometimes', options: ['He sometimes makes mistakes.', 'He makes sometimes mistakes.', 'Sometimes he makes mistakes.'], correct: 0, level: 'easy' },

    { type: 'placement', sentence: 'She is late for school.', adverb: 'never', options: ['She never is late.', 'She is never late.', 'Never she is late.'], correct: 1, rule: 'Pozor! U slovesa TO BE (is) stojí příslovce ZA ním.', level: 'medium' },
    { type: 'placement', sentence: 'My dad is tired after work.', adverb: 'always', options: ['My dad always is tired.', 'My dad is always tired.', 'Always my dad is tired.'], correct: 1, level: 'medium' },
    { type: 'placement', sentence: 'You are very kind.', adverb: 'always', options: ['You always are very kind.', 'You are always very kind.', 'Always you are very kind.'], correct: 1, level: 'medium' },
    { type: 'placement', sentence: 'It is sunny in Spain.', adverb: 'often', options: ['It often is sunny.', 'It is often sunny.', 'Often it is sunny.'], correct: 1, level: 'medium' },
    { type: 'placement', sentence: 'We are hungry at 10:00.', adverb: 'usually', options: ['We usually are hungry.', 'We are usually hungry.', 'Usually we are hungry.'], correct: 1, level: 'medium' },
    { type: 'placement', sentence: 'The water is cold in the pool.', adverb: 'sometimes', options: ['The water sometimes is cold.', 'The water is sometimes cold.', 'Sometimes the water is cold.'], correct: 1, level: 'medium' },
    { type: 'placement', sentence: 'Breakfast is important.', adverb: 'always', options: ['Breakfast always is important.', 'Breakfast is always important.', 'Always breakfast is important.'], correct: 1, level: 'medium' },
    { type: 'placement', sentence: 'The restaurant is busy.', adverb: 'usually', options: ['The restaurant usually is busy.', 'The restaurant is usually busy.', 'Usually the restaurant is busy.'], correct: 1, level: 'medium' },
    { type: 'placement', sentence: 'The teacher is angry.', adverb: 'hardly ever', options: ['The teacher hardly ever is angry.', 'The teacher is hardly ever angry.', 'Hardly ever the teacher is angry.'], correct: 1, level: 'medium' },
    { type: 'placement', sentence: 'My parents are at home.', adverb: 'sometimes', options: ['My parents sometimes are home.', 'My parents are sometimes at home.', 'Sometimes my parents are home.'], correct: 1, level: 'medium' },
    { type: 'placement', sentence: 'I am happy.', adverb: 'always', options: ['I always am happy.', 'I am always happy.', 'Always I am happy.'], correct: 1, level: 'medium' },
    { type: 'placement', sentence: 'She is at the library.', adverb: 'often', options: ['She often is at the library.', 'She is often at the library.', 'Often she is at the library.'], correct: 1, level: 'medium' },
    { type: 'placement', sentence: 'They are busy on Mondays.', adverb: 'usually', options: ['They usually are busy...', 'They are usually busy on Mondays.', 'Usually they are busy...'], correct: 1, level: 'medium' },
    { type: 'placement', sentence: 'We are ready for the test.', adverb: 'always', options: ['We always are ready...', 'We are always ready for the test.', 'Always we are ready...'], correct: 1, level: 'medium' },
    { type: 'placement', sentence: 'He is quiet in class.', adverb: 'sometimes', options: ['He sometimes is quiet...', 'He is sometimes quiet in class.', 'Sometimes he is quiet...'], correct: 1, level: 'medium' },
    { type: 'placement', sentence: 'The coffee is hot.', adverb: 'usually', options: ['The coffee usually is hot.', 'The coffee is usually hot.', 'Usually the coffee is hot.'], correct: 1, level: 'medium' },
    { type: 'placement', sentence: 'The shops are open.', adverb: 'often', options: ['The shops often are open.', 'The shops are often open.', 'Often the shops are open.'], correct: 1, level: 'medium' },
    { type: 'placement', sentence: 'I am bored at home.', adverb: 'never', options: ['I never am bored...', 'I am never bored at home.', 'Never I am bored...'], correct: 1, level: 'medium' },
    { type: 'placement', sentence: 'She is helpful to others.', adverb: 'always', options: ['She always is helpful...', 'She is always helpful to others.', 'Always she is helpful...'], correct: 1, level: 'medium' },
    { type: 'placement', sentence: 'They are late for the meeting.', adverb: 'sometimes', options: ['They sometimes are late...', 'They are sometimes late for the meeting.', 'Sometimes they are late...'], correct: 1, level: 'medium' },
    { type: 'placement', sentence: 'We are excited about the trip.', adverb: 'usually', options: ['We usually are excited...', 'We are usually excited about the trip.', 'Usually we are excited...'], correct: 1, level: 'medium' },
    { type: 'placement', sentence: 'He is careful with his money.', adverb: 'always', options: ['He always is careful...', 'He is always careful with his money.', 'Always he is careful...'], correct: 1, level: 'medium' },
    { type: 'placement', sentence: 'The weather is cold in winter.', adverb: 'often', options: ['The weather often is cold...', 'The weather is often cold in winter.', 'Often the weather is cold...'], correct: 1, level: 'medium' },
    { type: 'placement', sentence: 'The bus is crowded.', adverb: 'usually', options: ['The bus usually is crowded.', 'The bus is usually crowded.', 'Usually the bus is crowded.'], correct: 1, level: 'medium' },
    { type: 'placement', sentence: 'I am hungry after school.', adverb: 'sometimes', options: ['I sometimes am hungry...', 'I am sometimes hungry after school.', 'Sometimes I am hungry...'], correct: 1, level: 'medium' },
    { type: 'placement', sentence: 'She is at work at 9:00.', adverb: 'always', options: ['She always is at work...', 'She is always at work at 9:00.', 'Always she is at work...'], correct: 1, level: 'medium' },
    { type: 'placement', sentence: 'They are friendly to neighbors.', adverb: 'usually', options: ['They usually are friendly...', 'They are usually friendly to neighbors.', 'Usually they are friendly...'], correct: 1, level: 'medium' },
    { type: 'placement', sentence: 'We are at the park on Sundays.', adverb: 'often', options: ['We often are at the park...', 'We are often at the park on Sundays.', 'Often we are at the park...'], correct: 1, level: 'medium' },
    { type: 'placement', sentence: 'He is at his desk.', adverb: 'sometimes', options: ['He sometimes is at his desk.', 'He is sometimes at his desk.', 'Sometimes he is at his desk.'], correct: 1, level: 'medium' },
    { type: 'placement', sentence: 'The internet is fast here.', adverb: 'usually', options: ['The internet usually is fast.', 'The internet is usually fast here.', 'Usually the internet is fast.'], correct: 1, level: 'medium' },

    { type: 'translation', sentence: 'Skoro nikdy nesnídám.', options: ['I never have breakfast.', 'I hardly ever have breakfast.', 'I always have breakfast.'], correct: 1, level: 'hard' },
    { type: 'translation', sentence: 'Často jezdíme na dovolenou k moři.', options: ['We often go on holiday to the sea.', 'We go often on holiday...', 'Often we go on holiday...'], correct: 0, level: 'hard' },
    { type: 'translation', sentence: 'Nikdy nechodím do muzea v pondělí.', options: ['I never go to the museum...', 'I go never to the museum...', 'Never I go to the museum...'], correct: 0, level: 'hard' },
    { type: 'translation', sentence: 'Můj telefon je vždycky v mé tašce.', options: ['My phone is always in my bag.', 'My phone always is in my bag.', 'Always my phone is in my bag.'], correct: 0, level: 'hard' },
    { type: 'placement', sentence: 'The museum is closed on Sundays.', adverb: 'always', options: ['The museum always is closed.', 'The museum is always closed on Sundays.', 'Always the museum is closed.'], correct: 1, level: 'hard' },
    { type: 'placement', sentence: 'The internet is slow here.', adverb: 'often', options: ['The internet often is slow.', 'The internet is often slow here.', 'Often the internet is slow.'], correct: 1, level: 'hard' },
    { type: 'placement', sentence: 'The police are helpful.', adverb: 'always', options: ['The police always are helpful.', 'The police are always helpful.', 'Always the police are helpful.'], correct: 1, level: 'hard' },
    { type: 'placement', sentence: 'It is dangerous to walk alone.', adverb: 'never', options: ['It never is dangerous...', 'It is never dangerous to walk alone.', 'Never it is dangerous...'], correct: 1, level: 'hard' },
    { type: 'placement', sentence: 'Printers are noisy.', adverb: 'often', options: ['Printers often are noisy.', 'Printers are often noisy.', 'Often printers are noisy.'], correct: 1, level: 'hard' },
    { type: 'placement', sentence: 'The computer is on.', adverb: 'usually', options: ['The computer usually is on.', 'The computer is usually on.', 'Usually the computer is on.'], correct: 1, level: 'hard' },
    { type: 'translation', sentence: 'Obvykle chodím spát v deset.', options: ['I usually go to bed at ten.', 'I go usually to bed at ten.', 'Usually I go to bed at ten.'], correct: 0, level: 'hard' },
    { type: 'translation', sentence: 'Někdy zapomínám své heslo.', options: ['I sometimes forget my password.', 'I forget sometimes my password.', 'Sometimes I forget my password.'], correct: 0, level: 'hard' },
    { type: 'translation', sentence: 'Vždycky si čistím zuby ráno.', options: ['I always brush my teeth in the morning.', 'I brush always my teeth...', 'Always I brush my teeth...'], correct: 0, level: 'hard' },
    { type: 'translation', sentence: 'Nikdy nepiju mléko k večeři.', options: ['I never drink milk for dinner.', 'I drink never milk for dinner.', 'Never I drink milk for dinner.'], correct: 0, level: 'hard' },
    { type: 'translation', sentence: 'Často prší v dubnu.', options: ['It often rains in April.', 'It rains often in April.', 'Often it rains in April.'], correct: 0, level: 'hard' },
    { type: 'placement', sentence: 'The library is quiet.', adverb: 'always', options: ['The library always is quiet.', 'The library is always quiet.', 'Always the library is quiet.'], correct: 1, level: 'hard' },
    { type: 'placement', sentence: 'The food is delicious.', adverb: 'often', options: ['The food often is delicious.', 'The food is often delicious.', 'Often the food is delicious.'], correct: 1, level: 'hard' },
    { type: 'placement', sentence: 'The street is dark at night.', adverb: 'usually', options: ['The street usually is dark...', 'The street is usually dark at night.', 'Usually the street is dark...'], correct: 1, level: 'hard' },
    { type: 'placement', sentence: 'The park is beautiful in spring.', adverb: 'always', options: ['The park always is beautiful...', 'The park is always beautiful in spring.', 'Always the park is beautiful...'], correct: 1, level: 'hard' },
    { type: 'placement', sentence: 'The mountains are covered in snow.', adverb: 'sometimes', options: ['The mountains sometimes are covered...', 'The mountains are sometimes covered in snow.', 'Sometimes the mountains are covered...'], correct: 1, level: 'hard' },
  ];

  // --- LOGIC ---
  const startQuiz = (level: string) => {
    setDifficulty(level);
    let count = 15;
    let pool = [...questionsPool];

    if (level === 'easy') {
      pool = pool.filter(q => q.level === 'easy');
    } else if (level === 'medium') {
      pool = pool.filter(q => q.level === 'easy' || q.level === 'medium');
    } else if (level === 'hard') {
      // No filter, use all 80
    }

    const shuffled = pool.sort(() => Math.random() - 0.5);
    const selected = shuffled.slice(0, count).map(q => {
      const originalOptions = [...q.options];
      const correctText = originalOptions[q.correct];
      const shuffledOptions = originalOptions.sort(() => Math.random() - 0.5);
      const newCorrectIdx = shuffledOptions.indexOf(correctText);
      
      let correctSlot = null;
      if (q.type === 'placement') {
        const wordsInCorrectSentence = correctText.replace(/[.,!]/g, "").split(' ');
        correctSlot = wordsInCorrectSentence.indexOf(q.adverb);
      }

      return { ...q, options: shuffledOptions, correct: newCorrectIdx, correctSlot };
    });
    
    setSelectedQuestions(selected);
    setScore(0);
    setCurrentQuestionIdx(0);
    setQuizFinished(false);
    setQuizStarted(true);
    setFeedback(null);
    setHardSelectedIdx(null);
  };

  const handleAnswer = (index: number) => {
    if (feedback) return;
    const currentQ = selectedQuestions[currentQuestionIdx];
    const isCorrect = index === currentQ.correct;
    if (isCorrect) setScore(score + 1);
    setFeedback(isCorrect ? 'correct' : 'wrong');
  };

  const handleHardPlacement = (slotIndex: number) => {
    if (feedback) return;
    setHardSelectedIdx(slotIndex);
    const currentQ = selectedQuestions[currentQuestionIdx];
    const isCorrect = slotIndex === currentQ.correctSlot;
    if (isCorrect) setScore(score + 1);
    setFeedback(isCorrect ? 'correct' : 'wrong');
  };

  const nextQuestion = () => {
    setFeedback(null);
    setHardSelectedIdx(null);
    if (currentQuestionIdx < selectedQuestions.length - 1) {
      setCurrentQuestionIdx(currentQuestionIdx + 1);
    } else {
      setQuizFinished(true);
    }
  };

  const adverbsList = [
    { word: 'Always', cz: 'Vždy', percent: 100 },
    { word: 'Usually', cz: 'Obvykle', percent: 80 },
    { word: 'Often', cz: 'Často', percent: 60 },
    { word: 'Sometimes', cz: 'Někdy', percent: 40 },
    { word: 'Hardly ever', cz: 'Skoro nikdy', percent: 10 },
    { word: 'Never', cz: 'Nikdy', percent: 0 },
  ];

  const difficultyConfig = [
    { id: 'easy', label: 'Lehká', desc: 'Základní věty. Výběr z možností.', color: 'bg-emerald-500', icon: '🌱' },
    { id: 'medium', label: 'Střední', desc: 'Včetně slovesa "to be".', color: 'bg-indigo-500', icon: '📘' },
    { id: 'hard', label: 'Těžká', desc: 'Interaktivní vkládání do věty.', color: 'bg-rose-500', icon: '🔥' }
  ];

  return (
    <div className="min-h-screen bg-slate-50 p-4 md:p-8 font-sans text-slate-800">
      <div className="max-w-4xl mx-auto bg-white rounded-2xl shadow-xl overflow-hidden border border-slate-200">
        
        {/* Header */}
        <header className="bg-indigo-600 p-6 text-white text-center relative">
          <h1 className="text-3xl font-bold mb-1">Mistr příslovcí</h1>
          <p className="opacity-90">Adverbs of Frequency</p>
          <button 
            onClick={() => setShowShareModal(true)}
            className="absolute top-6 right-6 p-2 bg-white/20 hover:bg-white/30 rounded-full transition-colors"
            title="Sdílet aplikaci"
          >
            <Share2 size={20} />
          </button>
        </header>

        {/* Navigation */}
        <nav className="flex border-b border-slate-200">
          <button 
            onClick={() => {setActiveTab('theory'); setQuizStarted(false);}}
            className={`flex-1 py-4 px-2 font-semibold transition-colors flex justify-center items-center gap-2 ${activeTab === 'theory' ? 'bg-indigo-50 text-indigo-600 border-b-2 border-indigo-600' : 'text-slate-500 hover:bg-slate-50'}`}
          >
            <BookOpen size={18} /> Výklad
          </button>
          <button 
            onClick={() => setActiveTab('quiz')}
            className={`flex-1 py-4 px-2 font-semibold transition-colors flex justify-center items-center gap-2 ${activeTab === 'quiz' ? 'bg-indigo-50 text-indigo-600 border-b-2 border-indigo-600' : 'text-slate-500 hover:bg-slate-50'}`}
          >
            <Trophy size={18} /> Procvičování
          </button>
        </nav>

        {/* Content Area */}
        <main className="p-6 md:p-10">
          <AnimatePresence mode="wait">
            {activeTab === 'theory' ? (
              <motion.div 
                key="theory"
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 10 }}
                transition={{ duration: 0.2 }}
                className="space-y-8"
              >
                <section>
                  <h2 className="text-2xl font-bold text-slate-900 mb-4 border-l-4 border-indigo-500 pl-3">Žebříček četnosti</h2>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    {adverbsList.map((a, i) => (
                      <div key={i} className="flex items-center gap-4 bg-slate-50 p-4 rounded-xl border border-slate-100">
                        <div className="w-12 h-12 rounded-full bg-indigo-100 text-indigo-700 flex items-center justify-center font-bold">
                          {a.percent}%
                        </div>
                        <div>
                          <div className="text-lg font-bold text-indigo-600">{a.word}</div>
                          <div className="text-slate-500 italic">{a.cz}</div>
                        </div>
                      </div>
                    ))}
                  </div>
                </section>

                <section className="bg-amber-50 p-6 rounded-2xl border border-amber-200">
                  <h2 className="text-xl font-bold text-amber-900 mb-4 flex items-center gap-2">
                    <Info size={24} className="text-amber-600" /> Pravidla pozice
                  </h2>
                  <div className="space-y-4">
                    <div className="bg-white p-4 rounded-lg shadow-sm">
                      <p className="font-semibold text-slate-700">1. Před významovým slovesem</p>
                      <p className="text-lg italic">I <span className="text-indigo-600 font-bold underline">often</span> play football.</p>
                    </div>
                    <div className="bg-white p-4 rounded-lg shadow-sm">
                      <p className="font-semibold text-slate-700">2. Za slovesem "TO BE" (am/is/are)</p>
                      <p className="text-lg italic">She is <span className="text-indigo-600 font-bold underline">never</span> late.</p>
                    </div>
                  </div>
                </section>
              </motion.div>
            ) : (
              <motion.div 
                key="quiz"
                initial={{ opacity: 0, x: 10 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -10 }}
                transition={{ duration: 0.2 }}
              >
                {!quizStarted ? (
                  <div className="space-y-8 py-4">
                    <div className="text-center">
                      <h2 className="text-3xl font-bold text-slate-900">Vyber si obtížnost</h2>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                      {difficultyConfig.map((lvl) => (
                        <button 
                          key={lvl.id}
                          onClick={() => startQuiz(lvl.id)}
                          className="group bg-white border-2 border-slate-100 p-6 rounded-3xl hover:border-indigo-400 hover:shadow-xl transition-all text-center flex flex-col items-center gap-3"
                        >
                          <span className="text-5xl mb-2">{lvl.icon}</span>
                          <h3 className="text-xl font-bold">{lvl.label}</h3>
                          <p className="text-sm text-slate-500">{lvl.desc}</p>
                        </button>
                      ))}
                    </div>
                  </div>
                ) : !quizFinished ? (
                  <div className="space-y-6">
                    <div className="flex justify-between items-center mb-4">
                      <span className="text-sm font-bold text-slate-400">
                        {currentQuestionIdx + 1} / {selectedQuestions.length}
                      </span>
                      <span className="bg-indigo-100 text-indigo-700 px-3 py-1 rounded-full text-sm font-bold">
                        Skóre: {score}
                      </span>
                    </div>

                    <div className="bg-slate-100 p-8 rounded-3xl text-center mb-8">
                      <h3 className="text-slate-500 text-xs mb-3 uppercase tracking-widest font-bold">
                        {selectedQuestions[currentQuestionIdx].type === 'placement' ? 'Doplň příslovce:' : 'Přelož:'}
                      </h3>
                      
                      {difficulty === 'hard' && selectedQuestions[currentQuestionIdx].type === 'placement' ? (
                        <div className="flex flex-wrap justify-center items-center gap-2 mt-6">
                          {selectedQuestions[currentQuestionIdx].sentence.replace(/[.,!]/g, "").split(' ').map((word, wIdx, arr) => (
                            <React.Fragment key={wIdx}>
                              <button
                                disabled={feedback !== null}
                                onClick={() => handleHardPlacement(wIdx)}
                                className={`w-8 h-8 rounded-full flex items-center justify-center transition-all 
                                  ${feedback === null ? 'bg-indigo-100 text-indigo-500 hover:bg-indigo-600 hover:text-white' : 
                                    (wIdx === selectedQuestions[currentQuestionIdx].correctSlot ? 'bg-emerald-500 text-white' : 
                                     hardSelectedIdx === wIdx ? 'bg-rose-500 text-white' : 'bg-slate-200 text-slate-400')}
                                `}
                              >
                                <PlusCircle size={20} />
                              </button>
                              <span className="text-2xl font-bold text-slate-800">{word}</span>
                              {wIdx === arr.length - 1 && (
                                <button
                                  disabled={feedback !== null}
                                  onClick={() => handleHardPlacement(wIdx + 1)}
                                  className={`w-8 h-8 rounded-full flex items-center justify-center transition-all 
                                    ${feedback === null ? 'bg-indigo-100 text-indigo-500 hover:bg-indigo-600 hover:text-white' : 
                                      (wIdx + 1 === selectedQuestions[currentQuestionIdx].correctSlot ? 'bg-emerald-500 text-white' : 
                                       hardSelectedIdx === wIdx + 1 ? 'bg-rose-500 text-white' : 'bg-slate-200 text-slate-400')}
                                  `}
                                >
                                  <PlusCircle size={20} />
                                </button>
                              )}
                            </React.Fragment>
                          ))}
                        </div>
                      ) : (
                        <p className="text-2xl font-bold text-slate-800">
                          {selectedQuestions[currentQuestionIdx].sentence}
                        </p>
                      )}

                      {selectedQuestions[currentQuestionIdx].adverb && (
                        <div className="mt-8">
                          <span className="bg-indigo-600 text-white px-6 py-2 rounded-full font-bold shadow-md">
                            {selectedQuestions[currentQuestionIdx].adverb}
                          </span>
                        </div>
                      )}
                    </div>

                    {(difficulty !== 'hard' || selectedQuestions[currentQuestionIdx].type === 'translation') && (
                      <div className="grid grid-cols-1 gap-3">
                        {selectedQuestions[currentQuestionIdx].options.map((option, i) => (
                          <button
                            key={i}
                            disabled={feedback !== null}
                            onClick={() => handleAnswer(i)}
                            className={`w-full text-left p-5 rounded-xl border-2 transition-all flex justify-between items-center
                              ${feedback === null ? 'border-slate-100 hover:border-indigo-400 hover:bg-indigo-50 bg-white' : 
                                (i === selectedQuestions[currentQuestionIdx].correct ? 'border-emerald-500 bg-emerald-50' : 
                                 feedback === 'wrong' && i === hardSelectedIdx ? 'border-rose-500 bg-rose-50' : 'border-slate-100')}
                            `}
                          >
                            <span className="text-lg font-medium">{option}</span>
                            {feedback !== null && i === selectedQuestions[currentQuestionIdx].correct && <CheckCircle2 className="text-emerald-600" />}
                          </button>
                        ))}
                      </div>
                    )}

                    {feedback && (
                      <motion.div 
                        initial={{ opacity: 0, scale: 0.9 }}
                        animate={{ opacity: 1, scale: 1 }}
                        className={`p-6 rounded-2xl flex flex-col md:flex-row items-center gap-4 border-2
                        ${feedback === 'correct' ? 'bg-emerald-50 text-emerald-800 border-emerald-100' : 'bg-rose-50 text-rose-800 border-rose-100'}`}>
                        <div className={`w-12 h-12 rounded-full flex items-center justify-center shrink-0 ${feedback === 'correct' ? 'bg-emerald-200 text-emerald-700' : 'bg-rose-200 text-rose-700'}`}>
                          {feedback === 'correct' ? <CheckCircle2 size={28} /> : <XCircle size={28} />}
                        </div>
                        <div className="flex-1 text-center md:text-left">
                          <p className="font-bold text-xl mb-1">{feedback === 'correct' ? 'Výborně!' : 'To není správně...'}</p>
                          <div className="text-sm space-y-1">
                            {selectedQuestions[currentQuestionIdx].rule ? (
                              <p className="font-medium italic">"{selectedQuestions[currentQuestionIdx].rule}"</p>
                            ) : (
                              <>
                                {selectedQuestions[currentQuestionIdx].type === 'placement' && (
                                  <p>
                                    {selectedQuestions[currentQuestionIdx].sentence.match(/\b(is|am|are)\b/i) 
                                      ? "U slovesa 'to be' (am/is/are) stojí příslovce vždy ZA ním." 
                                      : "U běžných významových sloves stojí příslovce PŘED nimi."}
                                  </p>
                                )}
                                {selectedQuestions[currentQuestionIdx].type === 'translation' && (
                                  <p>Zkontroluj si slovosled: příslovce četnosti patří obvykle před hlavní sloveso (nebo za 'to be').</p>
                                )}
                              </>
                            )}
                            {feedback === 'wrong' && (
                              <p className="mt-2 text-xs opacity-80">
                                Správná odpověď: <span className="font-bold">{selectedQuestions[currentQuestionIdx].options[selectedQuestions[currentQuestionIdx].correct]}</span>
                              </p>
                            )}
                          </div>
                        </div>
                        <button 
                          onClick={nextQuestion}
                          className="w-full md:w-auto bg-indigo-600 text-white px-8 py-4 rounded-xl font-bold shadow-lg flex items-center justify-center gap-2 hover:bg-indigo-700 transition-all active:scale-95"
                        >
                          Další otázka <ArrowRight size={20} />
                        </button>
                      </motion.div>
                    )}
                  </div>
                ) : (
                  <div className="text-center py-6 space-y-6">
                    <div className="w-24 h-24 bg-indigo-100 text-indigo-600 rounded-full flex items-center justify-center mx-auto mb-4">
                      <Trophy size={48} />
                    </div>
                    
                    <h2 className="text-4xl font-bold text-slate-900">Konec testu!</h2>

                    <div className="bg-slate-50 inline-block px-10 py-5 rounded-3xl border border-slate-200">
                      <p className="text-slate-500 mb-1">Tvoje skóre:</p>
                      <p className="text-6xl font-black text-indigo-600">
                        {score} <span className="text-2xl text-slate-300">/ {selectedQuestions.length}</span>
                      </p>
                      <p className="text-xl font-bold text-slate-400 mt-2">
                        {Math.round((score / selectedQuestions.length) * 100)} %
                      </p>
                    </div>

                    <div className="flex flex-col sm:flex-row gap-3 justify-center pt-4">
                      <button 
                        onClick={() => setQuizStarted(false)}
                        className="bg-white text-indigo-600 border-2 border-indigo-600 px-8 py-4 rounded-2xl font-bold hover:bg-indigo-50 transition-all"
                      >
                        Změnit obtížnost
                      </button>
                      <button 
                        onClick={() => startQuiz(difficulty!)}
                        className="bg-indigo-600 text-white px-8 py-4 rounded-2xl font-bold shadow-xl flex items-center justify-center gap-2 hover:bg-indigo-700 transition-all"
                      >
                        <RefreshCcw size={20} /> Zkusit znovu
                      </button>
                    </div>
                  </div>
                )}
              </motion.div>
            )}
          </AnimatePresence>
        </main>

        <footer className="bg-slate-50 p-4 text-center text-slate-400 text-[10px] border-t border-slate-100 flex justify-between items-center px-8">
          <span>Elementary Solutions Unit 1</span>
          <button 
            onClick={() => setShowShareModal(true)}
            className="flex items-center gap-1 hover:text-indigo-600 transition-colors"
          >
            <QrCode size={12} /> Sdílet aplikaci
          </button>
        </footer>
      </div>

      {/* Share Modal */}
      <AnimatePresence>
        {showShareModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowShareModal(false)}
              className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm"
            />
            <motion.div 
              initial={{ opacity: 0, scale: 0.95, y: 10 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 10 }}
              transition={{ type: "spring", damping: 25, stiffness: 300 }}
              className="relative bg-white rounded-3xl shadow-2xl p-8 max-w-sm w-full text-center"
            >
              <button 
                onClick={() => setShowShareModal(false)}
                className="absolute top-4 right-4 p-2 text-slate-400 hover:text-slate-600 transition-colors"
              >
                <X size={20} />
              </button>
              
              <div className="mb-6">
                <div className="w-16 h-16 bg-indigo-100 text-indigo-600 rounded-full flex items-center justify-center mx-auto mb-4">
                  <QrCode size={32} />
                </div>
                <h3 className="text-2xl font-bold text-slate-900">Sdílej aplikaci</h3>
                <p className="text-slate-500 text-sm mt-2">Naskenuj QR kód a procvičuj kdekoli!</p>
              </div>

              <div className="bg-white p-4 rounded-2xl border-2 border-slate-100 inline-block mb-6 shadow-sm">
                <QRCodeSVG value={appUrl} size={200} level="H" includeMargin={true} />
              </div>

              <div className="space-y-3">
                <button 
                  onClick={() => {
                    navigator.clipboard.writeText(appUrl);
                    alert('Odkaz zkopírován do schránky!');
                  }}
                  className="w-full py-3 bg-indigo-600 text-white rounded-xl font-bold hover:bg-indigo-700 transition-all flex items-center justify-center gap-2"
                >
                  Kopírovat odkaz
                </button>
                <p className="text-[10px] text-slate-400 break-all">{appUrl}</p>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default App;
