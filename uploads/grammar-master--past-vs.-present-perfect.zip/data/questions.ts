
import { Question, QuestionType } from '../types';

export const questions: Question[] = [
  // PART 1: Completion
  { id: 1, type: QuestionType.INPUT, category: 'Doplňování', text: 'I _____ (see) a great film yesterday.', answer: 'saw' },
  { id: 2, type: QuestionType.INPUT, category: 'Doplňování', text: '_____ (you / ever / be) to London?', answer: 'Have you ever been' },
  { id: 3, type: QuestionType.INPUT, category: 'Doplňování', text: 'She _____ (live) in this town since 2015.', answer: 'has lived' },
  { id: 4, type: QuestionType.INPUT, category: 'Doplňování', text: 'We _____ (visit) our grandparents last weekend.', answer: 'visited' },
  { id: 5, type: QuestionType.INPUT, category: 'Doplňování', text: 'I _____ (not / finish) my project yet.', answer: "haven't finished" },
  { id: 6, type: QuestionType.INPUT, category: 'Doplňování', text: 'Look! Someone _____ (break) that window.', answer: 'has broken' },
  { id: 7, type: QuestionType.INPUT, category: 'Doplňování', text: 'Shakespeare _____ (write) Hamlet.', answer: 'wrote' },
  { id: 8, type: QuestionType.INPUT, category: 'Doplňování', text: 'He _____ (lose) his phone. He can\'t call anyone now.', answer: 'has lost' },
  { id: 9, type: QuestionType.INPUT, category: 'Doplňování', text: 'They _____ (go) to Spain two years ago.', answer: 'went' },
  { id: 10, type: QuestionType.INPUT, category: 'Doplňování', text: '_____ (you / see) Tom this morning? (It is now evening).', answer: 'Did you see' },

  // PART 2: Choices
  { id: 11, type: QuestionType.CHOICE, category: 'Výběr z možností', text: 'I _____ the homework yet.', options: ["didn't do", "haven't done"], answer: "haven't done" },
  { id: 12, type: QuestionType.CHOICE, category: 'Výběr z možností', text: 'When _____ your best friend?', options: ["did you meet", "have you met"], answer: "did you meet" },
  { id: 13, type: QuestionType.CHOICE, category: 'Výběr z možností', text: 'My parents _____ this house in 2010.', options: ["bought", "have bought"], answer: "bought" },
  { id: 14, type: QuestionType.CHOICE, category: 'Výběr z možností', text: 'She loves this book. She _____ it three times.', options: ["read", "has read"], answer: "has read" },
  { id: 15, type: QuestionType.CHOICE, category: 'Výběr z možností', text: 'Where is Paul? He _____ out.', options: ["just went", "has just gone"], answer: "has just gone" },
  { id: 16, type: QuestionType.CHOICE, category: 'Výběr z možností', text: 'I _____ hungry yesterday evening.', options: ["was", "have been"], answer: "was" },
  { id: 17, type: QuestionType.CHOICE, category: 'Výběr z možností', text: 'We _____ Mary recently.', options: ["didn't see", "haven't seen"], answer: "haven't seen" },
  { id: 18, type: QuestionType.CHOICE, category: 'Výběr z možností', text: '_____ sushi?', options: ["Did you ever eat", "Have you ever eaten"], answer: "Have you ever eaten" },
  { id: 19, type: QuestionType.CHOICE, category: 'Výběr z možností', text: 'My uncle _____ in a bank for 40 years. Now he is retired.', options: ["worked", "has worked"], answer: "worked" },
  { id: 20, type: QuestionType.CHOICE, category: 'Výběr z možností', text: 'Ouch! I _____ my finger.', options: ["cut", "have cut"], answer: "have cut" },

  // PART 3: Translation
  { id: 21, type: QuestionType.INPUT, category: 'Překlad', text: 'Včera jsem ztratil klíče.', answer: 'I lost my keys yesterday' },
  { id: 22, type: QuestionType.INPUT, category: 'Překlad', text: 'Ztratil jsem klíče. (Nemůžu se dostat domů).', answer: 'I have lost my keys' },
  { id: 23, type: QuestionType.INPUT, category: 'Překlad', text: 'Už jsi někdy viděl žraloka?', answer: 'Have you ever seen a shark' },
  { id: 24, type: QuestionType.INPUT, category: 'Překlad', text: 'Nikdy jsem nebyl v Americe.', answer: 'I have never been to America', alts: ['i have never been to the usa', 'i\'ve never been to america'] },
  { id: 25, type: QuestionType.INPUT, category: 'Překlad', text: 'Byli v kině minulou sobotu.', answer: 'They went to the cinema last Saturday' },
  { id: 26, type: QuestionType.INPUT, category: 'Překlad', text: 'Bydlím tu deset let.', answer: 'I have lived here for ten years' },
  { id: 27, type: QuestionType.INPUT, category: 'Překlad', text: 'Právě přijeli.', answer: 'They have just arrived' },
  { id: 28, type: QuestionType.INPUT, category: 'Překlad', text: 'Kdy jsi vstával?', answer: 'When did you get up' },
  { id: 29, type: QuestionType.INPUT, category: 'Překlad', text: 'Ještě mi nenapsala.', answer: 'She hasn\'t written to me yet', alts: ['she hasn\'t texted me yet'] },
  { id: 30, type: QuestionType.INPUT, category: 'Překlad', text: 'Ten film jsem viděl třikrát.', answer: 'I have seen the film three times' }
];
