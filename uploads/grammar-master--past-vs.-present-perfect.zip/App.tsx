
import React, { useState, useEffect, useRef } from 'react';
import { questions as originalQuestions } from './data/questions';
import { QuestionType, Question } from './types';

const App: React.FC = () => {
  const [currentScreen, setCurrentScreen] = useState<'start' | 'quiz' | 'end'>('start');
  const [shuffledQuestions, setShuffledQuestions] = useState<Question[]>([]);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [score, setScore] = useState(0);
  const [userAnswer, setUserAnswer] = useState('');
  const [showFeedback, setShowFeedback] = useState(false);
  const [isCorrect, setIsCorrect] = useState(false);
  const [showQR, setShowQR] = useState(false);

  const inputRef = useRef<HTMLInputElement>(null);

  const currentQuestion = shuffledQuestions[currentQuestionIndex];

  // Shuffles an array using Fisher-Yates algorithm
  const shuffleArray = (array: any[]) => {
    const shuffled = [...array];
    for (let i = shuffled.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
    }
    return shuffled;
  };

  useEffect(() => {
    if (currentScreen === 'quiz' && !showFeedback && currentQuestion?.type === QuestionType.INPUT) {
      setTimeout(() => inputRef.current?.focus(), 100);
    }
  }, [currentQuestionIndex, currentScreen, showFeedback, currentQuestion?.type]);

  const handleStart = () => {
    const newShuffled = shuffleArray(originalQuestions);
    setShuffledQuestions(newShuffled);
    setScore(0);
    setCurrentQuestionIndex(0);
    setCurrentScreen('quiz');
    setShowFeedback(false);
    setUserAnswer('');
  };

  const handleCheck = () => {
    if (!userAnswer.trim() && currentQuestion.type === QuestionType.INPUT) return;
    if (!userAnswer && currentQuestion.type === QuestionType.CHOICE) return;

    const normalizedUser = userAnswer.toLowerCase().trim().replace(/\.$/, '');
    const normalizedKey = currentQuestion.answer.toLowerCase().trim().replace(/\.$/, '');
    
    let correct = normalizedUser === normalizedKey;
    if (!correct && currentQuestion.alts) {
      correct = currentQuestion.alts.some(alt => alt.toLowerCase().trim().replace(/\.$/, '') === normalizedUser);
    }

    setIsCorrect(correct);
    if (correct) setScore(s => s + 1);
    setShowFeedback(true);
  };

  const handleNext = () => {
    if (currentQuestionIndex < shuffledQuestions.length - 1) {
      setCurrentQuestionIndex(i => i + 1);
      setShowFeedback(false);
      setUserAnswer('');
      setIsCorrect(false);
    } else {
      setCurrentScreen('end');
    }
  };

  const progress = shuffledQuestions.length > 0 ? ((currentQuestionIndex) / shuffledQuestions.length) * 100 : 0;

  return (
    <div className="min-h-screen flex items-center justify-center p-4">
      
      {/* QR Code Modal */}
      {showQR && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center fade-in p-4">
          <div className="bg-white p-8 rounded-2xl shadow-2xl max-w-sm w-full text-center border-4 border-sky-500 relative">
            <button onClick={() => setShowQR(false)} className="absolute top-2 right-3 text-gray-400 hover:text-gray-600 text-2xl">
              &times;
            </button>
            <h3 className="text-2xl font-bold text-gray-800 mb-2">Připoj se k testu!</h3>
            <p className="text-sm text-gray-500 mb-6">Naskenuj kód mobilem a začni hrát.</p>
            <div className="bg-white p-2 rounded-xl border border-gray-200 shadow-inner inline-block mb-4">
              <img 
                src={`https://api.qrserver.com/v1/create-qr-code/?size=250x250&data=${encodeURIComponent(window.location.href)}`} 
                alt="QR Kód" 
                className="w-48 h-48 object-contain"
              />
            </div>
            <p className="text-xs text-gray-400 mb-6">Funguje skvěle v učebně!</p>
            <button onClick={() => setShowQR(false)} className="w-full bg-sky-500 hover:bg-sky-600 text-white font-bold py-3 rounded-xl transition">
              Zavřít
            </button>
          </div>
        </div>
      )}

      {/* Main Container */}
      <div className="bg-white w-full max-w-2xl rounded-2xl shadow-2xl overflow-hidden border-4 border-sky-200 z-10">
        
        {/* Header */}
        <div className="bg-sky-500 p-6 text-white text-center relative">
          <h1 className="text-3xl font-bold mb-1">🇬🇧 English Tense Master</h1>
          <p className="opacity-90 text-sm">Past Simple vs. Present Perfect</p>
          <div className="absolute top-4 right-4 bg-white/20 px-3 py-1 rounded-full text-sm font-bold flex items-center gap-1">
            <i className="fas fa-star text-yellow-300"></i>
            <span>{score}</span>
          </div>
        </div>

        {/* Progress Bar */}
        <div className="w-full bg-gray-200 h-2">
          <div 
            className="bg-green-500 h-2 transition-all duration-500" 
            style={{ width: `${progress}%` }}
          ></div>
        </div>

        {/* Content Area */}
        <div className="p-6 sm:p-10 min-h-[400px]">
          
          {currentScreen === 'start' && (
            <div className="text-center fade-in">
              <div className="bg-sky-50 w-24 h-24 rounded-full flex items-center justify-center mx-auto mb-6 border-2 border-sky-100">
                <i className="fas fa-graduation-cap text-sky-500 text-4xl"></i>
              </div>
              <h2 className="text-2xl font-bold text-gray-800 mb-4">Jsi připraven(a) na výzvu?</h2>
              <p className="text-gray-600 mb-8 max-w-md mx-auto">
                Čeká tě {originalQuestions.length} vět k procvičení rozdílu mezi časy. <br/>
                Pořadí otázek se při každém spuštění náhodně mění!
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <button 
                  onClick={handleStart} 
                  className="bg-sky-500 hover:bg-sky-600 text-white text-xl font-bold py-3 px-8 rounded-full shadow-lg transform transition hover:scale-105 active:scale-95"
                >
                  Spustit test 🚀
                </button>
                <button 
                  onClick={() => setShowQR(true)} 
                  className="bg-indigo-100 hover:bg-indigo-200 text-indigo-700 text-lg font-bold py-3 px-6 rounded-full shadow-md transition flex items-center justify-center gap-2"
                >
                  <i className="fas fa-qrcode"></i> QR kód
                </button>
              </div>
            </div>
          )}

          {currentScreen === 'quiz' && currentQuestion && (
            <div className="fade-in">
              <div className="flex justify-between items-center mb-6">
                <span className="bg-indigo-100 text-indigo-700 px-3 py-1 rounded-lg text-sm font-bold uppercase tracking-wide">
                  {currentQuestion.category}
                </span>
                <span className="text-gray-400 text-sm font-semibold">
                  Otázka {currentQuestionIndex + 1}/{shuffledQuestions.length}
                </span>
              </div>

              <div className="mb-8">
                <h3 className="text-xl sm:text-2xl text-gray-800 font-bold leading-relaxed mb-6">
                  {currentQuestion.text}
                </h3>
                
                {currentQuestion.type === QuestionType.INPUT ? (
                  <input
                    ref={inputRef}
                    type="text"
                    value={userAnswer}
                    onChange={(e) => setUserAnswer(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') showFeedback ? handleNext() : handleCheck();
                    }}
                    placeholder="Napiš odpověď..."
                    disabled={showFeedback}
                    className={`w-full p-4 border-2 rounded-xl text-lg transition outline-none ${
                      showFeedback 
                        ? (isCorrect ? 'border-green-500 bg-green-50' : 'border-red-500 bg-red-50')
                        : 'border-gray-200 focus:border-sky-500'
                    }`}
                  />
                ) : (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    {currentQuestion.options?.map((opt, idx) => (
                      <button
                        key={idx}
                        onClick={() => !showFeedback && setUserAnswer(opt)}
                        disabled={showFeedback}
                        className={`p-4 rounded-xl text-lg font-semibold transition border-2 text-left flex justify-between items-center ${
                          userAnswer === opt 
                            ? 'border-sky-500 bg-sky-50 text-sky-700' 
                            : 'border-gray-100 hover:border-sky-200 text-gray-700'
                        } ${
                          showFeedback && opt === currentQuestion.answer ? 'border-green-500 bg-green-50 text-green-700' : ''
                        } ${
                          showFeedback && userAnswer === opt && !isCorrect ? 'border-red-500 bg-red-50 text-red-700' : ''
                        }`}
                      >
                        {opt}
                        {showFeedback && opt === currentQuestion.answer && <i className="fas fa-check-circle text-green-500"></i>}
                        {showFeedback && userAnswer === opt && !isCorrect && <i className="fas fa-times-circle text-red-500"></i>}
                      </button>
                    ))}
                  </div>
                )}
              </div>

              {showFeedback && (
                <div className={`p-4 rounded-xl mb-6 border fade-in ${isCorrect ? 'bg-green-100 border-green-300' : 'bg-red-100 border-red-300'}`}>
                  <div className="flex items-start gap-3">
                    <i className={`fas ${isCorrect ? 'fa-check-circle text-green-600' : 'fa-times-circle text-red-600'} text-2xl mt-1`}></i>
                    <div className="flex-1">
                      <p className={`font-bold ${isCorrect ? 'text-green-800' : 'text-red-800'}`}>
                        {isCorrect ? 'Skvělá práce!' : 'Chybička se vloudila.'}
                      </p>
                      {!isCorrect && (
                        <p className="text-red-700 text-sm">
                          Správná odpověď: <strong>{currentQuestion.answer}</strong>
                        </p>
                      )}
                    </div>
                  </div>
                </div>
              )}

              <div className="mt-6 flex gap-3">
                {!showFeedback ? (
                  <button 
                    onClick={handleCheck}
                    disabled={currentQuestion.type === QuestionType.INPUT ? !userAnswer.trim() : !userAnswer}
                    className="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-4 rounded-xl shadow-md transition text-lg active:scale-95 disabled:opacity-50"
                  >
                    Zkontrolovat
                  </button>
                ) : (
                  <button 
                    onClick={handleNext}
                    className="w-full bg-green-500 hover:bg-green-600 text-white font-bold py-4 rounded-xl shadow-md transition text-lg flex items-center justify-center gap-2 active:scale-95"
                  >
                    {currentQuestionIndex < shuffledQuestions.length - 1 ? 'Další otázka' : 'Zobrazit výsledky'}
                    <i className="fas fa-arrow-right"></i>
                  </button>
                )}
              </div>
            </div>
          )}

          {currentScreen === 'end' && (
            <div className="text-center fade-in py-6">
              <div className="relative inline-block mb-8">
                <i className="fas fa-trophy text-7xl text-yellow-400"></i>
                <div className="absolute -top-2 -right-2 bg-sky-500 text-white w-8 h-8 rounded-full flex items-center justify-center border-2 border-white font-bold">
                  !
                </div>
              </div>
              
              <h2 className="text-3xl font-bold text-gray-800 mb-2">Máš hotovo!</h2>
              <div className="bg-gray-50 p-8 rounded-2xl mb-8 border-2 border-dashed border-gray-200">
                <p className="text-gray-500 uppercase tracking-widest text-xs font-bold mb-2">Tvé výsledné skóre</p>
                <p className="text-6xl font-bold text-sky-600 mb-4">{score} <span className="text-2xl text-gray-300">/ {shuffledQuestions.length}</span></p>
                
                <p className="text-lg font-semibold text-gray-700">
                  {score === shuffledQuestions.length ? "Naprosto geniální! Jsi mistr časů! 🏆" :
                   score >= 25 ? "Skvělá práce! Skoro bez chyby. 😎" :
                   score >= 15 ? "Dobrá práce, ale chce to ještě potrénovat. 👍" :
                   "Žádný učený z nebe nespadl. Zkus to znovu! 💪"}
                </p>
              </div>

              <button 
                onClick={() => setCurrentScreen('start')} 
                className="bg-gray-800 hover:bg-gray-900 text-white font-bold py-4 px-10 rounded-full shadow-xl transition transform hover:scale-105 active:scale-95 flex items-center gap-2 mx-auto"
              >
                Zkusit znovu 🔄
              </button>
            </div>
          )}
        </div>
        
        {/* Footer */}
        <div className="bg-gray-50 p-4 text-center text-gray-400 text-xs border-t flex flex-col items-center gap-1">
          <div className="flex items-center gap-2">
            <span>Vytvořeno týmem Pančák AI 🤖</span>
            <span className="h-1 w-1 bg-gray-300 rounded-full"></span>
            <span>Výuka angličtiny</span>
          </div>
          <p className="opacity-70">© {new Date().getFullYear()} Grammar Master Learning Tools</p>
        </div>
      </div>
    </div>
  );
};

export default App;
