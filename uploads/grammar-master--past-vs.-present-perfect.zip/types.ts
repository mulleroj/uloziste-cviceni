
export enum QuestionType {
  INPUT = 'input',
  CHOICE = 'choice'
}

export interface Question {
  id: number;
  type: QuestionType;
  category: string;
  text: string;
  answer: string;
  options?: string[];
  alts?: string[];
}

export interface QuizState {
  currentQuestionIndex: number;
  score: number;
  isFinished: boolean;
  userAnswer: string;
  showFeedback: boolean;
  isCorrect: boolean;
}
