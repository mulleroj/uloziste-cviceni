import express from "express";
import { createServer as createViteServer } from "vite";
import Database from "better-sqlite3";
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const db = new Database("leaderboard.db");

// Initialize database
db.exec(`
  CREATE TABLE IF NOT EXISTS scores (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    score INTEGER NOT NULL,
    total INTEGER NOT NULL,
    difficulty TEXT NOT NULL,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
  )
`);

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // API Routes
  app.get("/api/leaderboard/:difficulty", (req, res) => {
    const { difficulty } = req.params;
    const stmt = db.prepare(`
      SELECT name, score, total, difficulty, timestamp 
      FROM scores 
      WHERE difficulty = ? 
      ORDER BY score DESC, timestamp ASC 
      LIMIT 10
    `);
    const scores = stmt.all(difficulty);
    res.json(scores);
  });

  app.post("/api/leaderboard", (req, res) => {
    const { name, score, total, difficulty } = req.body;
    if (!name || score === undefined || !total || !difficulty) {
      return res.status(400).json({ error: "Missing required fields" });
    }
    const stmt = db.prepare(`
      INSERT INTO scores (name, score, total, difficulty) 
      VALUES (?, ?, ?, ?)
    `);
    stmt.run(name, score, total, difficulty);
    res.json({ success: true });
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.join(__dirname, "dist")));
    app.get("*", (req, res) => {
      res.sendFile(path.join(__dirname, "dist", "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
