import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { MessageSquare, CheckCircle, XCircle, RefreshCw, QrCode, ArrowRight, Zap, Layers, ShieldAlert, Trophy, User, Clock, Volume2, VolumeX } from 'lucide-react';
import { ALL_QUESTIONS } from './constants';
import { Question, Screen, UserAnswer, Difficulty } from './types';
import { soundService } from './services/soundService';

interface LeaderboardEntry {
  name: string;
  score: number;
  total: number;
  difficulty: string;
  timestamp: string;
}

export default function App() {
  const [screen, setScreen] = useState<Screen>('start');
  const [difficulty, setDifficulty] = useState<Difficulty>('easy');
  const [selectedQuestions, setSelectedQuestions] = useState<Question[]>([]);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [userAnswers, setUserAnswers] = useState<string[]>([]);
  const [results, setResults] = useState<UserAnswer[]>([]);
  const [qrUrl, setQrUrl] = useState('');
  const [isLoaded, setIsLoaded] = useState(false);
  const [showLeaderboard, setShowLeaderboard] = useState(false);
  const [leaderboardData, setLeaderboardData] = useState<LeaderboardEntry[]>([]);
  const [userName, setUserName] = useState('');
  const [hasSubmitted, setHasSubmitted] = useState(false);
  const [soundEnabled, setSoundEnabled] = useState(true);
  const [direction, setDirection] = useState(0);
  const [sessions, setSessions] = useState<Record<Difficulty, any>>({
    easy: null,
    medium: null,
    hard: null
  });

  const STORAGE_KEY = 'reported_speech_v3';
  const LEADERBOARD_KEY = 'reported_speech_leaderboard';

  // Load state from localStorage on mount
  useEffect(() => {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (parsed.screen) setScreen(parsed.screen);
        if (parsed.difficulty) setDifficulty(parsed.difficulty);
        if (parsed.selectedQuestions) setSelectedQuestions(parsed.selectedQuestions);
        if (parsed.currentQuestionIndex !== undefined) setCurrentQuestionIndex(parsed.currentQuestionIndex);
        if (parsed.userAnswers) setUserAnswers(parsed.userAnswers);
        if (parsed.results) setResults(parsed.results);
        if (parsed.sessions) setSessions(parsed.sessions);
      } catch (e) {
        console.error("Failed to load progress", e);
      }
    }
    
    // Initial leaderboard load
    const savedLeaderboard = localStorage.getItem(LEADERBOARD_KEY);
    if (savedLeaderboard) {
      try {
        setLeaderboardData(JSON.parse(savedLeaderboard));
      } catch (e) {
        console.error("Failed to load leaderboard", e);
      }
    }

    setIsLoaded(true);
  }, []);

  // Save state to localStorage whenever it changes
  useEffect(() => {
    if (!isLoaded) return;
    const state = {
      screen,
      difficulty,
      selectedQuestions,
      currentQuestionIndex,
      userAnswers,
      results,
      sessions
    };
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  }, [screen, difficulty, selectedQuestions, currentQuestionIndex, userAnswers, results, sessions, isLoaded]);

  useEffect(() => {
    const url = window.location.href;
    setQrUrl(`https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=${encodeURIComponent(url)}`);
  }, []);

  const shuffle = (array: Question[]) => {
    return [...array].sort(() => Math.random() - 0.5);
  };

  const fetchLeaderboard = (diff: Difficulty) => {
    const savedLeaderboard = localStorage.getItem(LEADERBOARD_KEY);
    if (savedLeaderboard) {
      try {
        const allScores: LeaderboardEntry[] = JSON.parse(savedLeaderboard);
        const filtered = allScores
          .filter(s => s.difficulty === diff)
          .sort((a, b) => b.score - a.score || new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime())
          .slice(0, 10);
        setLeaderboardData(filtered);
      } catch (e) {
        console.error("Failed to fetch leaderboard", e);
      }
    } else {
      setLeaderboardData([]);
    }
  };

  const submitScore = () => {
    if (!userName.trim()) return;
    
    const newEntry: LeaderboardEntry = {
      name: userName,
      score: getScore(),
      total: selectedQuestions.length,
      difficulty,
      timestamp: new Date().toISOString()
    };

    const savedLeaderboard = localStorage.getItem(LEADERBOARD_KEY);
    let allScores: LeaderboardEntry[] = [];
    if (savedLeaderboard) {
      try {
        allScores = JSON.parse(savedLeaderboard);
      } catch (e) {}
    }
    
    allScores.push(newEntry);
    localStorage.setItem(LEADERBOARD_KEY, JSON.stringify(allScores));
    
    setHasSubmitted(true);
    if (soundEnabled) soundService.playCorrect();
    fetchLeaderboard(difficulty);
  };

  const startTest = (selectedDifficulty: Difficulty, resume: boolean = false) => {
    const session = sessions[selectedDifficulty];
    setHasSubmitted(false);
    setUserName('');
    if (soundEnabled) soundService.playTransition();
    
    if (resume && session) {
      setSelectedQuestions(session.questions);
      setUserAnswers(session.answers);
      setCurrentQuestionIndex(session.index);
      setDifficulty(selectedDifficulty);
      setScreen('quiz');
    } else {
      const filtered = ALL_QUESTIONS.filter(q => q.difficulty === selectedDifficulty);
      const shuffled = shuffle(filtered).slice(0, 15);
      setSelectedQuestions(shuffled);
      setUserAnswers(new Array(shuffled.length).fill(''));
      setCurrentQuestionIndex(0);
      setDifficulty(selectedDifficulty);
      
      // Update sessions map
      setSessions(prev => ({
        ...prev,
        [selectedDifficulty]: {
          questions: shuffled,
          answers: new Array(shuffled.length).fill(''),
          index: 0
        }
      }));
      
      setScreen('quiz');
    }
    window.scrollTo(0, 0);
  };

  const updateSession = (index: number, answers: string[]) => {
    setSessions(prev => ({
      ...prev,
      [difficulty]: {
        ...prev[difficulty],
        index,
        answers
      }
    }));
  };

  const resetProgress = () => {
    localStorage.removeItem(STORAGE_KEY);
    setScreen('start');
    setSelectedQuestions([]);
    setUserAnswers([]);
    setResults([]);
    setCurrentQuestionIndex(0);
    setSessions({
      easy: null,
      medium: null,
      hard: null
    });
  };

  const normalize = (text: string) => {
    return text.toLowerCase().trim().replace(/[.,!?]$/, "").replace(/\s+/g, " ");
  };

  const evaluateTest = () => {
    const newResults: UserAnswer[] = selectedQuestions.map((q, index) => {
      const answer = userAnswers[index];
      const isCorrect = normalize(answer) === normalize(q.correct);
      return { index, answer, isCorrect };
    });
    setResults(newResults);
    
    const score = newResults.filter(r => r.isCorrect).length;
    if (soundEnabled) {
      if (score >= selectedQuestions.length * 0.7) {
        soundService.playSuccess();
      } else {
        soundService.playFailure();
      }
    }

    // Clear session for this difficulty
    setSessions(prev => ({
      ...prev,
      [difficulty]: null
    }));
    
    setScreen('result');
    window.scrollTo(0, 0);
  };

  const handleAnswerChange = (index: number, value: string) => {
    const newAnswers = [...userAnswers];
    newAnswers[index] = value;
    setUserAnswers(newAnswers);
    updateSession(currentQuestionIndex, newAnswers);
  };

  const nextQuestion = () => {
    if (currentQuestionIndex < selectedQuestions.length - 1) {
      setDirection(1);
      const nextIdx = currentQuestionIndex + 1;
      setCurrentQuestionIndex(nextIdx);
      updateSession(nextIdx, userAnswers);
      if (soundEnabled) soundService.playTransition();
    } else {
      evaluateTest();
    }
  };

  const prevQuestion = () => {
    if (currentQuestionIndex > 0) {
      setDirection(-1);
      const prevIdx = currentQuestionIndex - 1;
      setCurrentQuestionIndex(prevIdx);
      updateSession(prevIdx, userAnswers);
      if (soundEnabled) soundService.playTransition();
    }
  };

  const getScore = () => results.filter(r => r.isCorrect).length;

  const getFeedback = (score: number, total: number) => {
    if (score === total) return "Perfektní! Ovládáte nepřímou řeč na jedničku.";
    if (score >= total * 0.7) return "Skvělá práce, jen pár drobností k doladění.";
    if (score >= total * 0.3) return "Dobrý základ, ale projděte si vysvětlení u chyb.";
    return "Téma je potřeba ještě procvičit. Podívejte se na vysvětlení níže.";
  };

  return (
    <div className="min-h-screen bg-slate-50 font-sans text-slate-900 selection:bg-blue-100">
      <div className="max-w-4xl mx-auto p-4 md:p-8">
        {/* Header */}
        <header className="flex justify-between items-start mb-12">
          <div className="w-10" /> {/* Spacer */}
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="text-center"
          >
            <h1 className="text-4xl font-bold text-slate-800 mb-3 tracking-tight">
              Reported Speech Practice
            </h1>
            <p className="text-lg text-slate-500 font-medium">
              Procvičování nepřímé řeči pro studenty angličtiny
            </p>
          </motion.div>
          <button
            onClick={() => setSoundEnabled(!soundEnabled)}
            className={`p-3 rounded-xl border transition-all ${
              soundEnabled ? 'bg-white border-slate-200 text-blue-600' : 'bg-slate-100 border-slate-200 text-slate-400'
            }`}
            title={soundEnabled ? "Vypnout zvuky" : "Zapnout zvuky"}
          >
            {soundEnabled ? <Volume2 className="w-5 h-5" /> : <VolumeX className="w-5 h-5" />}
          </button>
        </header>

        <AnimatePresence mode="wait">
          {screen === 'start' && (
            <motion.div
              key="start"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-white rounded-3xl shadow-xl shadow-slate-200/50 p-8 md:p-12 text-center border border-slate-200"
            >
              <div className="mb-8">
                <div className="bg-blue-50 text-blue-600 w-20 h-20 rounded-2xl flex items-center justify-center mx-auto mb-6 rotate-3">
                  <MessageSquare className="w-10 h-10" />
                </div>
                <h2 className="text-2xl font-bold mb-3 text-slate-800">Vyberte obtížnost</h2>
                <p className="text-slate-500 mb-8 max-w-md mx-auto leading-relaxed">
                  Každá úroveň se zaměřuje na jiné aspekty nepřímé řeči.
                </p>
                
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-10">
                  <button
                    onClick={() => setDifficulty('easy')}
                    className={`p-6 rounded-2xl border-2 transition-all text-left flex flex-col gap-3 ${
                      difficulty === 'easy' 
                        ? 'border-emerald-500 bg-emerald-50/50 shadow-lg shadow-emerald-100' 
                        : 'border-slate-100 hover:border-slate-200 bg-white'
                    }`}
                  >
                    <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${difficulty === 'easy' ? 'bg-emerald-500 text-white' : 'bg-slate-100 text-slate-400'}`}>
                      <Zap className="w-5 h-5" />
                    </div>
                    <div>
                      <h3 className="font-bold text-slate-800">Easy</h3>
                      <p className="text-xs text-slate-500 mt-1">Zaměřeno na posuny časů.</p>
                    </div>
                  </button>

                  <button
                    onClick={() => setDifficulty('medium')}
                    className={`p-6 rounded-2xl border-2 transition-all text-left flex flex-col gap-3 ${
                      difficulty === 'medium' 
                        ? 'border-amber-500 bg-amber-50/50 shadow-lg shadow-amber-100' 
                        : 'border-slate-100 hover:border-slate-200 bg-white'
                    }`}
                  >
                    <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${difficulty === 'medium' ? 'bg-amber-500 text-white' : 'bg-slate-100 text-slate-400'}`}>
                      <Layers className="w-5 h-5" />
                    </div>
                    <div>
                      <h3 className="font-bold text-slate-800">Medium</h3>
                      <p className="text-xs text-slate-500 mt-1">Zájmena a příslovce času/místa.</p>
                    </div>
                  </button>

                  <button
                    onClick={() => setDifficulty('hard')}
                    className={`p-6 rounded-2xl border-2 transition-all text-left flex flex-col gap-3 ${
                      difficulty === 'hard' 
                        ? 'border-rose-500 bg-rose-50/50 shadow-lg shadow-rose-100' 
                        : 'border-slate-100 hover:border-slate-200 bg-white'
                    }`}
                  >
                    <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${difficulty === 'hard' ? 'bg-rose-500 text-white' : 'bg-slate-100 text-slate-400'}`}>
                      <ShieldAlert className="w-5 h-5" />
                    </div>
                    <div>
                      <h3 className="font-bold text-slate-800">Hard</h3>
                      <p className="text-xs text-slate-500 mt-1">Mix všeho: otázky, rozkazy, modály.</p>
                    </div>
                  </button>
                </div>

                <div className="flex flex-col md:flex-row gap-4 justify-center">
                  <button
                    onClick={() => startTest(difficulty)}
                    className="group relative bg-blue-600 hover:bg-blue-700 text-white font-bold py-4 px-10 rounded-2xl transition-all shadow-lg shadow-blue-200 flex items-center justify-center gap-2 overflow-hidden"
                  >
                    <span className="relative z-10">Nový test</span>
                    <ArrowRight className="w-5 h-5 relative z-10 group-hover:translate-x-1 transition-transform" />
                    <div className="absolute inset-0 bg-gradient-to-r from-blue-500 to-blue-700 opacity-0 group-hover:opacity-100 transition-opacity" />
                  </button>

                  {sessions[difficulty] && (
                    <button
                      onClick={() => startTest(difficulty, true)}
                      className="bg-white hover:bg-slate-50 text-blue-600 border-2 border-blue-100 font-bold py-4 px-10 rounded-2xl transition-all flex items-center justify-center gap-2"
                    >
                      <RefreshCw className="w-5 h-5" />
                      <span>Pokračovat ({sessions[difficulty].answers.filter((a: string) => a !== '').length} / {sessions[difficulty].questions.length})</span>
                    </button>
                  )}
                </div>

                <div className="mt-8">
                  <button
                    onClick={() => {
                      fetchLeaderboard(difficulty);
                      setShowLeaderboard(true);
                    }}
                    className="inline-flex items-center gap-2 text-slate-500 hover:text-blue-600 font-semibold transition-colors"
                  >
                    <Trophy className="w-5 h-5" />
                    <span>Zobrazit žebříček ({difficulty})</span>
                  </button>
                </div>
              </div>

              <div className="pt-10 border-t border-slate-100">
                <div className="flex flex-col items-center gap-4">
                  <div className="flex items-center gap-2 text-sm font-semibold text-slate-400 uppercase tracking-wider">
                    <QrCode className="w-4 h-4" />
                    <span>Sdílejte se studenty</span>
                  </div>
                  <div className="p-4 bg-white rounded-2xl border border-slate-100 shadow-sm">
                    {qrUrl ? (
                      <img
                        src={qrUrl}
                        alt="QR kód pro sdílení"
                        className="w-32 h-32"
                        referrerPolicy="no-referrer"
                      />
                    ) : (
                      <div className="w-32 h-32 bg-slate-50 animate-pulse rounded-lg" />
                    )}
                  </div>
                  <p className="text-slate-400 text-xs font-medium">Aplikace funguje offline. Váš postup i žebříček jsou uloženy v tomto prohlížeči.</p>
                </div>
              </div>
            </motion.div>
          )}

          {screen === 'quiz' && (
            <motion.div
              key="quiz"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="space-y-8"
            >
              <div className="space-y-4">
                <div className="flex justify-between items-end px-2">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-bold text-slate-400 uppercase tracking-widest">Obtížnost:</span>
                      <span className={`text-sm font-bold px-3 py-1 rounded-full uppercase ${
                        difficulty === 'easy' ? 'bg-emerald-100 text-emerald-700' :
                        difficulty === 'medium' ? 'bg-amber-100 text-amber-700' :
                        'bg-rose-100 text-rose-700'
                      }`}>
                        {difficulty}
                      </span>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-sm font-bold text-slate-400 uppercase tracking-widest mb-1">
                      Otázka {currentQuestionIndex + 1} z {selectedQuestions.length}
                    </div>
                    <div className="w-32 h-2 bg-slate-200 rounded-full overflow-hidden">
                      <motion.div 
                        className="h-full bg-blue-600"
                        initial={{ width: 0 }}
                        animate={{ width: `${((currentQuestionIndex + 1) / selectedQuestions.length) * 100}%` }}
                      />
                    </div>
                  </div>
                </div>

                <div className="relative min-h-[400px] md:min-h-[320px]">
                  <AnimatePresence mode="popLayout" custom={direction}>
                    <motion.div
                      key={currentQuestionIndex}
                      custom={direction}
                      variants={{
                        enter: (direction: number) => ({
                          x: direction > 0 ? 100 : -100,
                          opacity: 0,
                          scale: 0.9,
                          filter: "blur(4px)"
                        }),
                        center: {
                          zIndex: 1,
                          x: 0,
                          opacity: 1,
                          scale: 1,
                          filter: "blur(0px)"
                        },
                        exit: (direction: number) => ({
                          zIndex: 0,
                          x: direction < 0 ? 100 : -100,
                          opacity: 0,
                          scale: 0.9,
                          filter: "blur(4px)"
                        })
                      }}
                      initial="enter"
                      animate="center"
                      exit="exit"
                      transition={{
                        x: { type: "spring", stiffness: 260, damping: 26 },
                        opacity: { duration: 0.25 },
                        filter: { duration: 0.2 }
                      }}
                      className="w-full"
                    >
                      <div className="bg-white p-8 md:p-12 rounded-3xl border border-slate-200 shadow-xl shadow-slate-200/50 flex flex-col justify-center">
                        <div className="flex items-start gap-6">
                          <motion.span 
                            initial={{ scale: 0.5, opacity: 0 }}
                            animate={{ scale: 1, opacity: 1 }}
                            transition={{ delay: 0.1 }}
                            className="bg-blue-50 text-blue-600 font-bold w-12 h-12 rounded-2xl flex items-center justify-center shrink-0 text-lg shadow-sm"
                          >
                            {currentQuestionIndex + 1}
                          </motion.span>
                          <div className="w-full">
                            <motion.p 
                              initial={{ y: 10, opacity: 0 }}
                              animate={{ y: 0, opacity: 1 }}
                              transition={{ delay: 0.15 }}
                              className="text-2xl md:text-3xl font-bold text-slate-800 mb-8 leading-tight"
                            >
                              {selectedQuestions[currentQuestionIndex].direct}
                            </motion.p>
                            <motion.div 
                              initial={{ y: 10, opacity: 0 }}
                              animate={{ y: 0, opacity: 1 }}
                              transition={{ delay: 0.2 }}
                              className="relative"
                            >
                              <input
                                autoFocus
                                type="text"
                                value={userAnswers[currentQuestionIndex]}
                                onChange={(e) => handleAnswerChange(currentQuestionIndex, e.target.value)}
                                onKeyDown={(e) => e.key === 'Enter' && nextQuestion()}
                                placeholder="Napište větu v nepřímé řeči..."
                                className="w-full p-5 bg-slate-50 border-2 border-slate-100 rounded-2xl focus:ring-4 focus:ring-blue-500/10 focus:border-blue-500 outline-none transition-all text-xl font-medium"
                              />
                              <div className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-300 text-sm hidden md:block">
                                Stiskněte Enter ↵
                              </div>
                            </motion.div>
                          </div>
                        </div>
                      </div>
                    </motion.div>
                  </AnimatePresence>
                </div>
              </div>

              <div className="flex justify-between items-center px-2 pt-4">
                <button
                  onClick={prevQuestion}
                  disabled={currentQuestionIndex === 0}
                  className={`px-6 py-3 rounded-xl font-bold transition-all ${
                    currentQuestionIndex === 0 
                      ? 'text-slate-300 cursor-not-allowed' 
                      : 'text-slate-600 hover:bg-slate-100'
                  }`}
                >
                  Předchozí
                </button>
                
                <button
                  onClick={nextQuestion}
                  className="bg-blue-600 hover:bg-blue-700 text-white font-bold py-4 px-10 rounded-2xl transition-all shadow-lg shadow-blue-200 flex items-center gap-2"
                >
                  <span>
                    {currentQuestionIndex === selectedQuestions.length - 1 ? 'Dokončit' : 'Další otázka'}
                  </span>
                  <ArrowRight className="w-5 h-5" />
                </button>
              </div>
            </motion.div>
          )}

          {screen === 'result' && (
            <motion.div
              key="result"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="space-y-10 pb-20"
            >
              <div className="bg-white rounded-3xl shadow-xl shadow-slate-200/50 p-10 border border-slate-200 text-center relative overflow-hidden">
                <div className="absolute top-0 left-0 w-full h-2 bg-blue-600" />
                <h2 className="text-3xl font-bold mb-4 text-slate-800">Výsledky testu</h2>
                <div className="text-7xl font-black text-blue-600 my-6 tracking-tighter">
                  {getScore()} <span className="text-slate-300 text-4xl font-light mx-1">/</span> {selectedQuestions.length}
                </div>
                <p className="text-xl text-slate-600 mb-8 font-medium">
                  {getFeedback(getScore(), selectedQuestions.length)}
                </p>

                {!hasSubmitted ? (
                  <div className="mb-10 p-6 bg-blue-50 rounded-2xl border border-blue-100 max-w-md mx-auto">
                    <h3 className="text-lg font-bold text-blue-800 mb-3 flex items-center gap-2 justify-center">
                      <Trophy className="w-5 h-5" />
                      Zapište se do žebříčku!
                    </h3>
                    <div className="flex gap-2">
                      <input
                        type="text"
                        value={userName}
                        onChange={(e) => setUserName(e.target.value)}
                        placeholder="Vaše jméno..."
                        className="flex-1 p-3 rounded-xl border border-blue-200 outline-none focus:ring-2 focus:ring-blue-500"
                        maxLength={20}
                      />
                      <button
                        onClick={submitScore}
                        disabled={!userName.trim()}
                        className="bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white font-bold px-6 rounded-xl transition-all"
                      >
                        Uložit
                      </button>
                    </div>
                  </div>
                ) : (
                  <div className="mb-10 text-emerald-600 font-bold flex items-center justify-center gap-2">
                    <CheckCircle className="w-5 h-5" />
                    Skóre uloženo do žebříčku!
                  </div>
                )}

                <div className="flex flex-wrap justify-center gap-4">
                  <button
                    onClick={() => {
                      if (soundEnabled) soundService.playTransition();
                      resetProgress();
                      setScreen('start');
                    }}
                    className="inline-flex items-center gap-2 bg-slate-800 hover:bg-slate-900 text-white font-bold py-3 px-8 rounded-xl transition-all"
                  >
                    <RefreshCw className="w-5 h-5" />
                    <span>Změnit obtížnost</span>
                  </button>
                  <button
                    onClick={() => startTest(difficulty)}
                    className="inline-flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-8 rounded-xl transition-all"
                  >
                    <RefreshCw className="w-5 h-5" />
                    <span>Nové věty ({difficulty})</span>
                  </button>
                </div>
              </div>

              <div className="space-y-6">
                <h3 className="text-2xl font-bold text-slate-800 px-2 flex items-center gap-3">
                  <span>Přehled chyb a vysvětlení</span>
                  <div className="h-px flex-1 bg-slate-200" />
                </h3>
                
                {results.map((res, idx) => {
                  const q = selectedQuestions[res.index];
                  return (
                    <motion.div
                      key={idx}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: idx * 0.05 }}
                      className={`p-6 md:p-8 rounded-2xl border-l-8 shadow-sm bg-white ${
                        res.isCorrect ? 'border-emerald-500' : 'border-red-500'
                      }`}
                    >
                      <div className="flex justify-between items-center mb-6">
                        <div className="flex items-center gap-3">
                          <span className="font-bold text-slate-400 text-sm uppercase tracking-widest">Příklad {idx + 1}</span>
                          {res.isCorrect ? (
                            <div className="flex items-center gap-1.5 text-emerald-600 bg-emerald-50 px-3 py-1 rounded-full text-sm font-bold">
                              <CheckCircle className="w-4 h-4" />
                              <span>Správně</span>
                            </div>
                          ) : (
                            <div className="flex items-center gap-1.5 text-red-600 bg-red-50 px-3 py-1 rounded-full text-sm font-bold">
                              <XCircle className="w-4 h-4" />
                              <span>Chyba</span>
                            </div>
                          )}
                        </div>
                      </div>

                      <div className="space-y-4">
                        <div>
                          <p className="text-sm font-bold text-slate-400 uppercase mb-1">Zadání</p>
                          <p className="text-lg font-semibold text-slate-800 italic">"{q.direct.replace(/"/g, '')}"</p>
                        </div>

                        <div className="grid md:grid-cols-2 gap-6">
                          <div>
                            <p className="text-sm font-bold text-slate-400 uppercase mb-1">Vaše odpověď</p>
                            <p className={`text-lg font-medium ${res.isCorrect ? 'text-emerald-700' : 'text-red-700'}`}>
                              {res.answer || <span className="italic opacity-50">(prázdné)</span>}
                            </p>
                          </div>
                          {!res.isCorrect && (
                            <div>
                              <p className="text-sm font-bold text-slate-400 uppercase mb-1">Správně má být</p>
                              <p className="text-lg font-bold text-emerald-700">
                                {q.correct}
                              </p>
                            </div>
                          )}
                        </div>

                        <div className="mt-6 p-5 bg-slate-50 rounded-2xl border border-slate-100">
                          <p className="text-sm font-bold text-slate-500 mb-2 flex items-center gap-2">
                            <span className="w-1.5 h-1.5 rounded-full bg-blue-500" />
                            Vysvětlení
                          </p>
                          <p className="text-slate-700 leading-relaxed">
                            {q.explanation}
                          </p>
                        </div>
                      </div>
                    </motion.div>
                  );
                })}
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Leaderboard Modal */}
        <AnimatePresence>
          {showLeaderboard && (
            <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
              <motion.div
                initial={{ opacity: 0, scale: 0.9, y: 20 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.9, y: 20 }}
                className="bg-white w-full max-w-lg rounded-3xl shadow-2xl overflow-hidden border border-slate-200"
              >
                <div className="p-6 border-b border-slate-100 flex justify-between items-center bg-slate-50">
                  <div className="flex items-center gap-3">
                    <div className="bg-amber-100 text-amber-600 p-2 rounded-lg">
                      <Trophy className="w-6 h-6" />
                    </div>
                    <div>
                      <h2 className="text-xl font-bold text-slate-800">Žebříček</h2>
                      <p className="text-xs font-bold text-slate-400 uppercase tracking-widest">Obtížnost: {difficulty}</p>
                    </div>
                  </div>
                  <button
                    onClick={() => setShowLeaderboard(false)}
                    className="text-slate-400 hover:text-slate-600 p-2 hover:bg-slate-100 rounded-full transition-colors"
                  >
                    <XCircle className="w-6 h-6" />
                  </button>
                </div>

                <div className="p-6 max-h-[60vh] overflow-y-auto">
                  {leaderboardData.length > 0 ? (
                    <div className="space-y-3">
                      {leaderboardData.map((entry, idx) => (
                        <div 
                          key={idx} 
                          className={`flex items-center justify-between p-4 rounded-2xl border ${
                            idx === 0 ? 'bg-amber-50 border-amber-100' : 
                            idx === 1 ? 'bg-slate-50 border-slate-100' :
                            idx === 2 ? 'bg-orange-50 border-orange-100' :
                            'bg-white border-slate-100'
                          }`}
                        >
                          <div className="flex items-center gap-4">
                            <span className={`w-8 h-8 rounded-full flex items-center justify-center font-bold text-sm ${
                              idx === 0 ? 'bg-amber-500 text-white' :
                              idx === 1 ? 'bg-slate-400 text-white' :
                              idx === 2 ? 'bg-orange-400 text-white' :
                              'bg-slate-100 text-slate-500'
                            }`}>
                              {idx + 1}
                            </span>
                            <div>
                              <p className="font-bold text-slate-800">{entry.name}</p>
                              <p className="text-xs text-slate-400 flex items-center gap-1">
                                <Clock className="w-3 h-3" />
                                {new Date(entry.timestamp).toLocaleDateString('cs-CZ')}
                              </p>
                            </div>
                          </div>
                          <div className="text-right">
                            <p className="text-lg font-black text-blue-600">{entry.score} / {entry.total}</p>
                            <p className="text-[10px] font-bold text-slate-400 uppercase tracking-tighter">
                              {Math.round((entry.score / entry.total) * 100)}%
                            </p>
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-12">
                      <User className="w-12 h-12 text-slate-200 mx-auto mb-4" />
                      <p className="text-slate-500 font-medium">Zatím žádné záznamy. Buďte první!</p>
                    </div>
                  )}
                </div>

                <div className="p-6 bg-slate-50 border-t border-slate-100">
                  <button
                    onClick={() => setShowLeaderboard(false)}
                    className="w-full py-3 bg-slate-800 hover:bg-slate-900 text-white font-bold rounded-xl transition-all"
                  >
                    Zavřít
                  </button>
                </div>
              </motion.div>
            </div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
