export type Difficulty = 'easy' | 'medium' | 'hard';

export interface Question {
  direct: string;
  correct: string;
  explanation: string;
  difficulty: Difficulty;
}

export type Screen = 'start' | 'quiz' | 'result';

export interface UserAnswer {
  index: number;
  answer: string;
  isCorrect: boolean;
}
