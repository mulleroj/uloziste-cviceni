class SoundService {
  private ctx: AudioContext | null = null;

  private init() {
    if (!this.ctx) {
      this.ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
    }
    if (this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
  }

  private createOscillator(freq: number, type: OscillatorType = 'sine', duration: number = 0.1, volume: number = 0.1) {
    this.init();
    if (!this.ctx) return;

    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = type;
    osc.frequency.setValueAtTime(freq, this.ctx.currentTime);

    gain.gain.setValueAtTime(volume, this.ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.01, this.ctx.currentTime + duration);

    osc.connect(gain);
    gain.connect(this.ctx.destination);

    osc.start();
    osc.stop(this.ctx.currentTime + duration);
  }

  playTransition() {
    this.createOscillator(800, 'sine', 0.05, 0.05);
  }

  playCorrect() {
    this.createOscillator(1000, 'sine', 0.2, 0.1);
    setTimeout(() => this.createOscillator(1300, 'sine', 0.3, 0.1), 100);
  }

  playIncorrect() {
    this.createOscillator(300, 'triangle', 0.4, 0.1);
  }

  playSuccess() {
    const now = this.ctx?.currentTime || 0;
    this.createOscillator(523.25, 'sine', 0.2, 0.1); // C5
    setTimeout(() => this.createOscillator(659.25, 'sine', 0.2, 0.1), 150); // E5
    setTimeout(() => this.createOscillator(783.99, 'sine', 0.2, 0.1), 300); // G5
    setTimeout(() => this.createOscillator(1046.50, 'sine', 0.4, 0.1), 450); // C6
  }

  playFailure() {
    this.createOscillator(200, 'sawtooth', 0.5, 0.05);
  }
}

export const soundService = new SoundService();
