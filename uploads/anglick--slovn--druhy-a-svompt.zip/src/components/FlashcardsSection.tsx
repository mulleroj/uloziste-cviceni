import React, { useState } from 'react';
import { FLASHCARDS_DATA } from '../data/flashcardsData';
import { PARTS_OF_SPEECH } from '../data/grammarData';
import { PartOfSpeechType, Flashcard } from '../types';
import { Layers, Volume2, RotateCw, ChevronLeft, ChevronRight, Filter } from 'lucide-react';
import { speakEnglishSentence } from '../utils/audio';

interface FlashcardsSectionProps {
  soundEnabled: boolean;
}

export const FlashcardsSection: React.FC<FlashcardsSectionProps> = ({ soundEnabled }) => {
  const [filterPos, setFilterPos] = useState<PartOfSpeechType | 'all'>('all');
  const [currentIndex, setCurrentIndex] = useState<number>(0);
  const [isFlipped, setIsFlipped] = useState<boolean>(false);

  const filteredCards = filterPos === 'all'
    ? FLASHCARDS_DATA
    : FLASHCARDS_DATA.filter(fc => fc.pos === filterPos);

  const currentCard: Flashcard = filteredCards[currentIndex] || FLASHCARDS_DATA[0];

  const handleNext = () => {
    setIsFlipped(false);
    setCurrentIndex(prev => (prev + 1) % filteredCards.length);
  };

  const handlePrev = () => {
    setIsFlipped(false);
    setCurrentIndex(prev => (prev - 1 + filteredCards.length) % filteredCards.length);
  };

  const handleSpeak = (e: React.MouseEvent, text: string) => {
    e.stopPropagation();
    if (soundEnabled) {
      speakEnglishSentence(text);
    }
  };

  const posData = PARTS_OF_SPEECH.find(p => p.id === currentCard.pos) || PARTS_OF_SPEECH[0];

  return (
    <div className="space-y-6 animate-in fade-in duration-300 max-w-3xl mx-auto">
      
      {/* Top Card */}
      <div className="bg-white rounded-2xl p-6 shadow-sm border border-slate-200 text-center">
        <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-indigo-50 text-indigo-700 border border-indigo-200 mb-2">
          <Layers className="w-3.5 h-3.5" /> Slovníček & Kartičky
        </span>
        <h2 className="text-2xl font-bold text-slate-900 mb-1">
          Procvičování Slovní Zásoby
        </h2>
        <p className="text-sm text-slate-600 mb-4">
          Klikněte na kartičku pro její otočení a ověření českého překladu a příkladové věty.
        </p>

        {/* Filter bar */}
        <div className="flex items-center justify-center gap-1.5 flex-wrap pt-2 border-t border-slate-100">
          <button
            onClick={() => { setFilterPos('all'); setCurrentIndex(0); setIsFlipped(false); }}
            className={`px-3 py-1.5 rounded-lg text-xs font-medium transition ${
              filterPos === 'all' ? 'bg-slate-900 text-white shadow-xs' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            Vše (12)
          </button>
          {PARTS_OF_SPEECH.map(p => (
            <button
              key={p.id}
              onClick={() => { setFilterPos(p.id); setCurrentIndex(0); setIsFlipped(false); }}
              className={`px-2.5 py-1.5 rounded-lg text-xs font-medium border transition ${
                filterPos === p.id ? `${p.badgeClass} font-bold shadow-xs border-transparent` : 'bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100'
              }`}
            >
              {p.nameEn}
            </button>
          ))}
        </div>
      </div>

      {/* Main Flashcard Flip Box */}
      <div className="perspective-1000 my-8">
        <div
          onClick={() => setIsFlipped(!isFlipped)}
          className={`relative w-full min-h-[300px] bg-white rounded-3xl p-8 border-2 border-slate-200 shadow-xl cursor-pointer transition-all duration-300 flex flex-col justify-between items-center text-center group hover:border-indigo-400 ${
            isFlipped ? 'bg-indigo-900 text-white border-indigo-700' : 'bg-white text-slate-900'
          }`}
        >
          {/* Card Top Row */}
          <div className="w-full flex items-center justify-between">
            <span className={`px-3 py-1 rounded-full text-xs font-bold border ${
              isFlipped ? 'bg-indigo-800 text-indigo-200 border-indigo-700' : posData.badgeClass
            }`}>
              {posData.nameEn} ({posData.nameCz})
            </span>

            <span className="text-xs font-medium opacity-60 flex items-center gap-1">
              <RotateCw className="w-3.5 h-3.5" /> Klikněte pro otočení
            </span>
          </div>

          {/* Card Center Content */}
          <div className="my-6">
            {!isFlipped ? (
              <div className="space-y-3">
                <h3 className="text-4xl font-black tracking-tight text-slate-900">
                  {currentCard.wordEn}
                </h3>
                <button
                  onClick={(e) => handleSpeak(e, currentCard.wordEn)}
                  className="px-3 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-full text-xs font-semibold inline-flex items-center gap-1 transition"
                >
                  <Volume2 className="w-4 h-4 text-indigo-600" /> Přehrát výslovnost
                </button>
              </div>
            ) : (
              <div className="space-y-4 animate-in fade-in duration-200">
                <span className="text-xs font-bold uppercase tracking-widest text-indigo-300">
                  Český význam:
                </span>
                <h3 className="text-3xl font-bold text-amber-300">
                  {currentCard.wordCz}
                </h3>
                <div className="pt-2 border-t border-indigo-800/80 max-w-md mx-auto">
                  <p className="text-sm italic text-indigo-100">
                    "{currentCard.exampleEn}"
                  </p>
                  <p className="text-xs text-indigo-300 mt-0.5">
                    ({currentCard.exampleCz})
                  </p>
                </div>
              </div>
            )}
          </div>

          {/* Card Footer Counter */}
          <div className="text-xs opacity-50 font-mono">
            Kartička {currentIndex + 1} z {filteredCards.length}
          </div>
        </div>
      </div>

      {/* Navigation Controls */}
      <div className="flex items-center justify-between">
        <button
          onClick={handlePrev}
          className="px-5 py-2.5 bg-white border border-slate-300 rounded-xl hover:bg-slate-50 font-bold text-slate-700 text-sm shadow-xs transition flex items-center gap-2"
        >
          <ChevronLeft className="w-4 h-4" /> Předchozí
        </button>

        <button
          onClick={handleNext}
          className="px-6 py-2.5 bg-indigo-600 text-white rounded-xl hover:bg-indigo-700 font-bold text-sm shadow-md transition flex items-center gap-2"
        >
          Další kartička <ChevronRight className="w-4 h-4" />
        </button>
      </div>

    </div>
  );
};
