import React, { useState } from 'react';
import confetti from 'canvas-confetti';
import { SVOMPT_PUZZLES } from '../data/sentencesBank';
import { SvomptPuzzle, UserStats } from '../types';
import { Puzzle, CheckCircle, Volume2, RefreshCw, Sparkles, HelpCircle, ArrowRight } from 'lucide-react';
import { speakEnglishSentence } from '../utils/audio';

interface SvomptBuilderSectionProps {
  stats: UserStats;
  setStats: React.Dispatch<React.SetStateAction<UserStats>>;
  soundEnabled: boolean;
}

export const SvomptBuilderSection: React.FC<SvomptBuilderSectionProps> = ({ stats, setStats, soundEnabled }) => {
  const [currentPuzzleIdx, setCurrentPuzzleIdx] = useState<number>(0);
  const [activeSlots, setActiveSlots] = useState<Record<string, string>>({
    s: '',
    v: '',
    o: '',
    m: '',
    p: '',
    t: ''
  });
  const [availableBlocks, setAvailableBlocks] = useState<string[]>([]);
  const [isSolved, setIsSolved] = useState<boolean>(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const puzzle: SvomptPuzzle = SVOMPT_PUZZLES[currentPuzzleIdx] || SVOMPT_PUZZLES[0];

  // Initialize blocks when puzzle changes
  const initPuzzle = (puzzleItem: SvomptPuzzle) => {
    const blocks = Object.values(puzzleItem.slots).filter(Boolean);
    if (puzzleItem.distractors) {
      blocks.push(...puzzleItem.distractors);
    }
    // Shuffle blocks
    const shuffled = [...blocks].sort(() => Math.random() - 0.5);

    setAvailableBlocks(shuffled);
    setActiveSlots({ s: '', v: '', o: '', m: '', p: '', t: '' });
    setIsSolved(false);
    setErrorMessage(null);
  };

  React.useEffect(() => {
    initPuzzle(puzzle);
  }, [currentPuzzleIdx]);

  const handleNextPuzzle = () => {
    const nextIdx = (currentPuzzleIdx + 1) % SVOMPT_PUZZLES.length;
    setCurrentPuzzleIdx(nextIdx);
  };

  const handlePlaceBlock = (slotKey: string, blockText: string) => {
    if (isSolved) return;

    // If slot already has a block, move previous block back to pool
    const previousInSlot = activeSlots[slotKey];

    setActiveSlots(prev => ({
      ...prev,
      [slotKey]: blockText
    }));

    setAvailableBlocks(prev => {
      const filtered = prev.filter(b => b !== blockText);
      if (previousInSlot) {
        filtered.push(previousInSlot);
      }
      return filtered;
    });

    setErrorMessage(null);
  };

  const handleRemoveFromSlot = (slotKey: string) => {
    if (isSolved) return;
    const currentText = activeSlots[slotKey];
    if (!currentText) return;

    setActiveSlots(prev => ({
      ...prev,
      [slotKey]: ''
    }));

    setAvailableBlocks(prev => [...prev, currentText]);
    setErrorMessage(null);
  };

  const handleCheckSolution = () => {
    const expected = puzzle.slots;
    const current = activeSlots;

    let isCorrect = true;

    // Verify each slot matches
    if (expected.s && current.s.trim().toLowerCase() !== expected.s.trim().toLowerCase()) isCorrect = false;
    if (expected.v && current.v.trim().toLowerCase() !== expected.v.trim().toLowerCase()) isCorrect = false;
    if (expected.o && current.o.trim().toLowerCase() !== expected.o.trim().toLowerCase()) isCorrect = false;
    if (expected.m && current.m.trim().toLowerCase() !== expected.m.trim().toLowerCase()) isCorrect = false;
    if (expected.p && current.p.trim().toLowerCase() !== expected.p.trim().toLowerCase()) isCorrect = false;
    if (expected.t && current.t.trim().toLowerCase() !== expected.t.trim().toLowerCase()) isCorrect = false;

    if (isCorrect) {
      setIsSolved(true);
      setErrorMessage(null);

      setStats(prev => ({
        ...prev,
        puzzlesSolved: prev.puzzlesSolved + 1,
        currentStreak: prev.currentStreak + 1
      }));

      if (soundEnabled) {
        speakEnglishSentence(puzzle.englishFull);
      }

      try {
        confetti({
          particleCount: 70,
          spread: 60,
          origin: { y: 0.6 }
        });
      } catch (e) {}
    } else {
      setErrorMessage('Pořadí slov ještě není zcela správné. Zkontrolujte pravidlo S - V - O - M - P - T!');
    }
  };

  const slotDefinitions = [
    { key: 's', label: '[S] Subject', nameCz: 'Podmět (Kdo/Co?)', bg: 'border-indigo-300 bg-indigo-50/50', badge: 'bg-indigo-600 text-white' },
    { key: 'v', label: '[V] Verb', nameCz: 'Přísudek (Co dělá?)', bg: 'border-rose-300 bg-rose-50/50', badge: 'bg-rose-600 text-white' },
    { key: 'o', label: '[O] Object', nameCz: 'Předmět (Koho/Co?)', bg: 'border-blue-300 bg-blue-50/50', badge: 'bg-blue-600 text-white' },
    { key: 'm', label: '[M] Manner', nameCz: 'Způsob (Jak?)', bg: 'border-emerald-300 bg-emerald-50/50', badge: 'bg-emerald-600 text-white' },
    { key: 'p', label: '[P] Place', nameCz: 'Místo (Kde?)', bg: 'border-orange-300 bg-orange-50/50', badge: 'bg-orange-600 text-white' },
    { key: 't', label: '[T] Time', nameCz: 'Čas (Kdy?)', bg: 'border-purple-300 bg-purple-50/50', badge: 'bg-purple-600 text-white' }
  ];

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      
      {/* Top Card */}
      <div className="bg-white rounded-2xl p-6 shadow-sm border border-slate-200">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-4">
          <div>
            <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-indigo-50 text-indigo-700 border border-indigo-200 mb-2">
              <Puzzle className="w-3.5 h-3.5" /> Interaktivní puzzle
            </span>
            <h2 className="text-2xl font-bold text-slate-900">
              Tvořič Vět: Sestavte Větu v Pořadí SVOMPT
            </h2>
            <p className="text-sm text-slate-600 mt-1">
              Klikněte na nabízená slovní spojení a zařaďte je do správných políček podle pravidla SVOMPT.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-xs font-bold text-slate-500">
              Skládačka {currentPuzzleIdx + 1} z {SVOMPT_PUZZLES.length}
            </span>
            <button
              onClick={handleNextPuzzle}
              className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-xs font-semibold flex items-center gap-1 transition"
            >
              Další <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Translation Target */}
        <div className="p-4 bg-indigo-50/80 rounded-xl border border-indigo-100 text-indigo-950 flex items-start gap-3">
          <HelpCircle className="w-5 h-5 text-indigo-600 shrink-0 mt-0.5" />
          <div>
            <span className="text-xs font-bold uppercase tracking-wider text-indigo-700 block">Cílový český význam:</span>
            <p className="text-base font-semibold italic mt-0.5">"{puzzle.czechTranslation}"</p>
          </div>
        </div>
      </div>

      {/* SVOMPT Target Slots Grid */}
      <div className="bg-white rounded-2xl p-6 shadow-sm border border-slate-200">
        <h3 className="text-sm font-bold uppercase tracking-wider text-slate-500 mb-4 flex items-center gap-2">
          <Sparkles className="w-4 h-4 text-indigo-600" /> Vložte do políček podle SVOMPT:
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
          {slotDefinitions.map(slot => {
            const placedText = activeSlots[slot.key];

            return (
              <div
                key={slot.key}
                className={`p-4 rounded-xl border-2 border-dashed ${slot.bg} min-h-[100px] flex flex-col justify-between transition-all`}
              >
                <div className="flex items-center justify-between mb-2">
                  <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${slot.badge}`}>
                    {slot.label}
                  </span>
                  <span className="text-[11px] font-medium text-slate-500">
                    {slot.nameCz}
                  </span>
                </div>

                {placedText ? (
                  <div
                    onClick={() => handleRemoveFromSlot(slot.key)}
                    className="p-2.5 bg-white rounded-lg border border-slate-300 text-slate-900 font-bold text-sm shadow-xs flex items-center justify-between cursor-pointer hover:border-rose-400 hover:bg-rose-50/50 group transition"
                    title="Klikněte pro odebrání zpět"
                  >
                    <span>{placedText}</span>
                    <span className="text-[10px] text-rose-500 font-normal group-hover:underline">Odebrat</span>
                  </div>
                ) : (
                  <div className="p-2 text-center text-xs text-slate-400 italic">
                    — Prázdné pole —
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* Available Word Blocks Pool */}
      <div className="bg-slate-900 text-white rounded-2xl p-6 shadow-xl border border-slate-800">
        <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-3">
          Dostupná slovní spojení (klikněte pro zařazení):
        </h3>

        {availableBlocks.length > 0 ? (
          <div className="flex flex-wrap gap-2">
            {availableBlocks.map((block, idx) => (
              <div
                key={idx + block}
                className="group relative"
              >
                <button
                  onClick={() => {
                    // Automatically place into first empty slot
                    const emptySlot = slotDefinitions.find(s => !activeSlots[s.key]);
                    if (emptySlot) {
                      handlePlaceBlock(emptySlot.key, block);
                    }
                  }}
                  className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl font-bold text-sm shadow-md transition transform hover:-translate-y-0.5 active:translate-y-0 flex items-center gap-2"
                >
                  <span>{block}</span>
                </button>
              </div>
            ))}
          </div>
        ) : (
          <p className="text-xs text-slate-400 italic">
            Všechna slova byla umístěna do políček výše!
          </p>
        )}

        {errorMessage && (
          <p className="mt-4 text-xs font-bold text-rose-400 bg-rose-950/60 p-3 rounded-xl border border-rose-800">
            ⚠️ {errorMessage}
          </p>
        )}

        {/* Action buttons */}
        <div className="mt-6 flex flex-wrap items-center justify-between gap-4 border-t border-slate-800 pt-4">
          <button
            onClick={() => initPuzzle(puzzle)}
            className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-xs font-medium flex items-center gap-1.5 transition"
          >
            <RefreshCw className="w-3.5 h-3.5" /> Obnovit skládačku
          </button>

          {isSolved ? (
            <div className="flex items-center gap-3">
              <span className="text-emerald-400 text-sm font-bold flex items-center gap-1">
                <CheckCircle className="w-5 h-5" /> Výborně! Věta je v perfektním SVOMPT pořadí.
              </span>
              <button
                onClick={handleNextPuzzle}
                className="px-6 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl font-bold text-sm shadow-lg transition"
              >
                Další věta
              </button>
            </div>
          ) : (
            <button
              onClick={handleCheckSolution}
              className="px-8 py-3 bg-indigo-500 hover:bg-indigo-400 text-white rounded-xl font-bold text-sm shadow-lg shadow-indigo-500/20 transition"
            >
              Zkontrolovat pořadí slov
            </button>
          )}
        </div>
      </div>

    </div>
  );
};
