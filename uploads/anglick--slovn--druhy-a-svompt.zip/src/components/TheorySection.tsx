import React, { useState } from 'react';
import { PARTS_OF_SPEECH, SVOMPT_ELEMENTS } from '../data/grammarData';
import { PartOfSpeechType } from '../types';
import { BookOpen, HelpCircle, Info, Volume2, Sparkles, CheckCircle2 } from 'lucide-react';
import { speakEnglishSentence } from '../utils/audio';

interface TheorySectionProps {
  soundEnabled: boolean;
}

export const TheorySection: React.FC<TheorySectionProps> = ({ soundEnabled }) => {
  const [selectedPos, setSelectedPos] = useState<PartOfSpeechType | 'all'>('all');
  const [hoveredWord, setHoveredWord] = useState<PartOfSpeechType | null>(null);

  const filteredPos = selectedPos === 'all' 
    ? PARTS_OF_SPEECH 
    : PARTS_OF_SPEECH.filter(p => p.id === selectedPos);

  const sampleInteractiveSentence = [
    { word: 'The', pos: 'article', posName: 'Člen' },
    { word: 'clever', pos: 'adj', posName: 'Přídavné jméno' },
    { word: 'dog', pos: 'noun', posName: 'Podstatné jméno' },
    { word: 'ate', pos: 'verb', posName: 'Sloveso' },
    { word: 'its', pos: 'pron', posName: 'Zájmeno' },
    { word: 'food', pos: 'noun', posName: 'Podstatné jméno' },
    { word: 'eagerly', pos: 'adv', posName: 'Příslovce' },
    { word: 'in', pos: 'prep', posName: 'Předložka' },
    { word: 'the', pos: 'article', posName: 'Člen' },
    { word: 'garden', pos: 'noun', posName: 'Podstatné jméno' },
    { word: 'yesterday.', pos: 'adv', posName: 'Příslovce' }
  ];

  const handleSpeak = (text: string) => {
    if (soundEnabled) {
      speakEnglishSentence(text);
    }
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-300">
      
      {/* Intro Banner */}
      <div className="bg-gradient-to-r from-indigo-900 via-indigo-800 to-slate-900 rounded-3xl p-6 sm:p-8 text-white shadow-xl relative overflow-hidden">
        <div className="absolute right-0 top-0 bottom-0 opacity-10 pointer-events-none flex items-center pr-10">
          <BookOpen className="w-64 h-64 text-white" />
        </div>
        <div className="relative z-10 max-w-2xl">
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-indigo-500/30 text-indigo-200 border border-indigo-400/30 mb-3">
            <Sparkles className="w-3.5 h-3.5" /> Výuka anglické gramatiky
          </span>
          <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight mb-2">
            Anglické Slovní Druhy & Pravidlo SVOMPT
          </h2>
          <p className="text-sm sm:text-base text-indigo-100/90 leading-relaxed">
            Pochopení slovních druhů (Parts of Speech) a pevného pořadí slov ve větě (SVOMPT) je základem pro správné mluvení i psaní v angličtině.
          </p>
        </div>
      </div>

      {/* Interactive Sentence Hover Demo */}
      <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-6 sm:p-8">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-4 border-b border-slate-100 pb-3">
          <div>
            <h3 className="text-lg font-bold text-slate-900 flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-indigo-600" /> Najeďte myší na slovo ve větě:
            </h3>
            <p className="text-xs text-slate-500">
              Vyzkoušejte si, jak jednotlivá slova spadají do různých slovních druhů.
            </p>
          </div>
          <button
            onClick={() => handleSpeak('The clever dog ate its food eagerly in the garden yesterday')}
            className="self-start sm:self-auto px-3 py-1.5 rounded-lg bg-indigo-50 hover:bg-indigo-100 text-indigo-700 text-xs font-medium flex items-center gap-1.5 transition"
          >
            <Volume2 className="w-4 h-4" /> Přehrát celou větu
          </button>
        </div>

        <div className="p-4 sm:p-6 bg-slate-50 rounded-xl border border-slate-200 text-slate-800 text-lg sm:text-xl font-medium leading-loose flex flex-wrap gap-2 items-center">
          {sampleInteractiveSentence.map((item, idx) => {
            const isHovered = hoveredWord === item.pos;
            const posData = PARTS_OF_SPEECH.find(p => p.id === item.pos) || PARTS_OF_SPEECH[0];

            return (
              <span
                key={idx}
                onMouseEnter={() => setHoveredWord(item.pos as PartOfSpeechType)}
                onMouseLeave={() => setHoveredWord(null)}
                className={`px-2 py-0.5 rounded-md cursor-pointer transition-all duration-200 border ${
                  isHovered 
                    ? `${posData.badgeBg} text-white font-bold shadow-md scale-105 border-transparent` 
                    : 'bg-white border-slate-200 text-slate-800 hover:border-indigo-400'
                }`}
              >
                {item.word}
                <sub className="text-[10px] ml-1 opacity-70 font-sans font-normal">
                  ({item.posName})
                </sub>
              </span>
            );
          })}
        </div>

        {hoveredWord && (
          <div className="mt-4 p-4 rounded-xl bg-indigo-50 border border-indigo-200 text-indigo-900 text-xs sm:text-sm animate-in fade-in duration-150 flex items-start gap-3">
            <Info className="w-5 h-5 text-indigo-600 shrink-0 mt-0.5" />
            <div>
              <p className="font-bold text-sm">
                Slovní druh: {PARTS_OF_SPEECH.find(p => p.id === hoveredWord)?.nameEn} ({PARTS_OF_SPEECH.find(p => p.id === hoveredWord)?.nameCz})
              </p>
              <p className="mt-0.5 text-indigo-800">
                {PARTS_OF_SPEECH.find(p => p.id === hoveredWord)?.descriptionCz}
              </p>
            </div>
          </div>
        )}
      </div>

      {/* Parts of Speech Cards */}
      <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-6 sm:p-8">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6 border-b border-slate-100 pb-4">
          <div>
            <h3 className="text-xl font-bold text-slate-900">1. Základní slovní druhy (Parts of Speech)</h3>
            <p className="text-xs sm:text-sm text-slate-500 mt-1">
              Filtrujte nebo si projděte přehled 8 hlavních kategorií.
            </p>
          </div>

          {/* Filters */}
          <div className="flex flex-wrap gap-1.5">
            <button
              onClick={() => setSelectedPos('all')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition ${
                selectedPos === 'all'
                  ? 'bg-slate-900 text-white shadow-xs'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              Všechny (8)
            </button>
            {PARTS_OF_SPEECH.map((pos) => (
              <button
                key={pos.id}
                onClick={() => setSelectedPos(pos.id)}
                className={`px-2.5 py-1.5 rounded-lg text-xs font-medium border transition ${
                  selectedPos === pos.id
                    ? `${pos.badgeClass} font-bold shadow-xs border-transparent`
                    : 'bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100'
                }`}
              >
                {pos.nameEn}
              </button>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          {filteredPos.map((pos) => (
            <div
              key={pos.id}
              className="p-5 rounded-xl border border-slate-200 bg-slate-50/50 hover:bg-white hover:shadow-md transition-all duration-200 flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between mb-3">
                  <span className={`px-3 py-1 rounded-full text-xs font-bold border ${pos.badgeClass}`}>
                    {pos.nameEn}
                  </span>
                  <span className="text-xs font-semibold text-slate-500">
                    Otázka: {pos.questionCz}
                  </span>
                </div>

                <h4 className="text-lg font-bold text-slate-900 mb-1">
                  {pos.nameCz}
                </h4>

                <p className="text-xs sm:text-sm text-slate-600 mb-3 leading-relaxed">
                  {pos.descriptionCz}
                </p>

                <div className="mb-3">
                  <span className="text-xs font-bold text-slate-700 block mb-1">Příklady slov:</span>
                  <div className="flex flex-wrap gap-1">
                    {pos.examplesEn.map((ex, i) => (
                      <span
                        key={i}
                        onClick={() => handleSpeak(ex)}
                        className="px-2 py-0.5 rounded bg-white border border-slate-200 text-slate-700 text-xs hover:border-indigo-400 hover:text-indigo-600 cursor-pointer transition"
                        title="Klikněte pro výslovnost"
                      >
                        {ex}
                      </span>
                    ))}
                  </div>
                </div>
              </div>

              <div className="pt-3 border-t border-slate-200/80 text-xs text-slate-500 flex items-start gap-1.5">
                <Info className="w-4 h-4 text-slate-400 shrink-0 mt-0.5" />
                <span><strong>Tip:</strong> {pos.tipsCz}</span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* SVOMPT Rules Explanation */}
      <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-6 sm:p-8">
        <div className="mb-6 border-b border-slate-100 pb-4">
          <h3 className="text-xl font-bold text-slate-900">2. Pořadí slov v anglické větě (SVOMPT)</h3>
          <p className="text-xs sm:text-sm text-slate-600 mt-1">
            Na rozdíl od češtiny je v anglické oznamovací větě slovosled velmi přísný. Zkratka <strong>SVOMPT</strong> udává přesné pořadí větných členů.
          </p>
        </div>

        {/* SVOMPT Table */}
        <div className="overflow-x-auto rounded-xl border border-slate-200 mb-6">
          <table className="w-full text-left border-collapse min-w-[600px]">
            <thead>
              <tr className="bg-slate-900 text-white text-xs sm:text-sm">
                <th className="p-3.5 font-bold">Písmeno</th>
                <th className="p-3.5 font-bold">Větný člen (EN)</th>
                <th className="p-3.5 font-bold">Český význam</th>
                <th className="p-3.5 font-bold">Otázka</th>
                <th className="p-3.5 font-bold">Typický slovní druh</th>
                <th className="p-3.5 font-bold">Příklad v příkladu</th>
              </tr>
            </thead>
            <tbody className="text-xs sm:text-sm divide-y divide-slate-200">
              {SVOMPT_ELEMENTS.map((elem) => (
                <tr key={elem.code} className="hover:bg-slate-50 transition-colors">
                  <td className="p-3.5 font-extrabold text-base">
                    <span className={`inline-block w-8 h-8 rounded-lg flex items-center justify-center text-white ${elem.bgClass}`}>
                      {elem.code}
                    </span>
                  </td>
                  <td className="p-3.5 font-bold text-slate-900">{elem.nameEn}</td>
                  <td className="p-3.5 text-slate-700">{elem.nameCz}</td>
                  <td className="p-3.5 text-slate-600 font-medium">{elem.questionCz}</td>
                  <td className="p-3.5 text-slate-500 italic">{elem.typicalPos}</td>
                  <td className={`p-3.5 font-bold ${elem.textClass}`}>{elem.exampleText}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Full Sentence Example Box */}
        <div className="p-5 rounded-2xl bg-indigo-50 border border-indigo-200 text-slate-800">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-bold uppercase tracking-wider text-indigo-700 flex items-center gap-1">
              <CheckCircle2 className="w-4 h-4 text-indigo-600" /> Vzorová věta v pořadí SVOMPT:
            </span>
            <button
              onClick={() => handleSpeak('The dog ate its dinner quickly in the garden yesterday.')}
              className="text-xs text-indigo-700 hover:text-indigo-900 font-medium flex items-center gap-1"
            >
              <Volume2 className="w-4 h-4" /> Poslechnout
            </button>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-2 text-center text-xs">
            <div className="p-2.5 rounded-xl bg-indigo-100/80 border border-indigo-200">
              <span className="block font-bold text-indigo-900 text-sm">The dog</span>
              <span className="text-[10px] text-indigo-700 font-semibold">[S] Subject</span>
            </div>
            <div className="p-2.5 rounded-xl bg-rose-100/80 border border-rose-200">
              <span className="block font-bold text-rose-900 text-sm">ate</span>
              <span className="text-[10px] text-rose-700 font-semibold">[V] Verb</span>
            </div>
            <div className="p-2.5 rounded-xl bg-blue-100/80 border border-blue-200">
              <span className="block font-bold text-blue-900 text-sm">its dinner</span>
              <span className="text-[10px] text-blue-700 font-semibold">[O] Object</span>
            </div>
            <div className="p-2.5 rounded-xl bg-emerald-100/80 border border-emerald-200">
              <span className="block font-bold text-emerald-900 text-sm">quickly</span>
              <span className="text-[10px] text-emerald-700 font-semibold">[M] Manner</span>
            </div>
            <div className="p-2.5 rounded-xl bg-orange-100/80 border border-orange-200">
              <span className="block font-bold text-orange-900 text-sm">in the garden</span>
              <span className="text-[10px] text-orange-700 font-semibold">[P] Place</span>
            </div>
            <div className="p-2.5 rounded-xl bg-purple-100/80 border border-purple-200">
              <span className="block font-bold text-purple-900 text-sm">yesterday.</span>
              <span className="text-[10px] text-purple-700 font-semibold">[T] Time</span>
            </div>
          </div>

          <p className="mt-3 text-xs text-slate-600 text-center italic">
            Český překlad: "Pes včera na zahradě rychle snědl svou večeři." (V češtině můžeme slova libovolně přehazovat, v angličtině VŽDY platí S - V - O - M - P - T).
          </p>
        </div>

      </div>

    </div>
  );
};
