import React from 'react';
import { BookOpen, HelpCircle, Puzzle, Layers, QrCode, Flame, Award, Volume2, VolumeX, WifiOff } from 'lucide-react';
import { UserStats } from '../types';

export type TabType = 'theory' | 'quiz' | 'builder' | 'flashcards';

interface HeaderProps {
  activeTab: TabType;
  setActiveTab: (tab: TabType) => void;
  stats: UserStats;
  onOpenQr: () => void;
  soundEnabled: boolean;
  setSoundEnabled: (val: boolean) => void;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  setActiveTab,
  stats,
  onOpenQr,
  soundEnabled,
  setSoundEnabled
}) => {
  const tabs = [
    { id: 'theory', label: 'Teorie & SVOMPT', icon: BookOpen },
    { id: 'quiz', label: 'Cvičení & Test', icon: HelpCircle },
    { id: 'builder', label: 'Tvořič vět', icon: Puzzle },
    { id: 'flashcards', label: 'Slovníček', icon: Layers }
  ];

  return (
    <header className="bg-slate-900 text-white shadow-xl sticky top-0 z-40 border-b border-slate-800">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row justify-between items-center py-4 gap-4">
          
          {/* Logo / Title */}
          <div className="flex items-center justify-between w-full md:w-auto">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-indigo-500 to-indigo-600 flex items-center justify-center font-bold text-white shadow-lg shadow-indigo-500/20">
                EN
              </div>
              <div>
                <h1 className="text-xl font-bold tracking-tight text-slate-100 flex flex-wrap items-center gap-2">
                  Anglické Slovní Druhy 
                  <span className="text-indigo-400 font-extrabold text-xs uppercase px-2 py-0.5 rounded-full bg-indigo-950/80 border border-indigo-800">SVOMPT</span>
                  <span className="text-emerald-400 font-semibold text-[11px] px-2 py-0.5 rounded-full bg-emerald-950/80 border border-emerald-800/80 flex items-center gap-1" title="Aplikace funguje 100% offline, odpojena od API">
                    <WifiOff className="w-3 h-3 text-emerald-400" /> Offline režim
                  </span>
                </h1>
                <p className="text-xs text-slate-400">Interaktivní gramatická učebna & tvořič vět (100% bez připojení k síti)</p>
              </div>
            </div>

            {/* Mobile Controls */}
            <div className="flex items-center gap-2 md:hidden">
              <button
                onClick={() => setSoundEnabled(!soundEnabled)}
                className={`p-2 rounded-lg text-xs flex items-center gap-1 transition-colors ${
                  soundEnabled ? 'bg-indigo-900/60 text-indigo-300 border border-indigo-700' : 'bg-slate-800 text-slate-400'
                }`}
                title={soundEnabled ? 'Zvuk zapnut' : 'Zvuk vypnut'}
              >
                {soundEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
              </button>
              <button
                onClick={onOpenQr}
                className="p-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-indigo-400 transition-colors"
                title="Sdílet QR kód"
              >
                <QrCode className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Desktop Stats & Quick Controls */}
          <div className="hidden md:flex items-center gap-4">
            <div className="flex items-center gap-3 bg-slate-800/80 px-3 py-1.5 rounded-xl border border-slate-700/60 text-xs">
              <div className="flex items-center gap-1 text-amber-400 font-medium" title="Série dní / splněno">
                <Flame className="w-4 h-4 fill-amber-400/20 text-amber-400" />
                <span>{stats.currentStreak} d.</span>
              </div>
              <div className="w-px h-3 bg-slate-700" />
              <div className="flex items-center gap-1 text-emerald-400 font-medium" title="Správné odpovědi">
                <Award className="w-4 h-4" />
                <span>{stats.correctAnswers} bodů</span>
              </div>
            </div>

            <button
              onClick={() => setSoundEnabled(!soundEnabled)}
              className={`p-2 rounded-xl text-xs flex items-center gap-1.5 font-medium transition-all ${
                soundEnabled 
                  ? 'bg-indigo-600/30 text-indigo-300 border border-indigo-500/40 hover:bg-indigo-600/40' 
                  : 'bg-slate-800 text-slate-400 border border-slate-700 hover:bg-slate-700'
              }`}
              title={soundEnabled ? 'Výslovnost zapnuta' : 'Výslovnost vypnuta'}
            >
              {soundEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
              <span>{soundEnabled ? 'Zvuk ZAP' : 'Zvuk VYP'}</span>
            </button>

            <button
              onClick={onOpenQr}
              className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-indigo-400 border border-slate-700 transition-colors flex items-center gap-1.5 text-xs font-medium"
              title="Mobilní verze / QR kód"
            >
              <QrCode className="w-4 h-4" />
              <span>QR kód</span>
            </button>
          </div>

        </div>

        {/* Tab Navigation */}
        <nav className="flex space-x-1 overflow-x-auto pb-3 pt-1 scrollbar-none border-t border-slate-800/60">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as TabType)}
                className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs sm:text-sm font-medium whitespace-nowrap transition-all duration-150 ${
                  isActive
                    ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30 font-semibold'
                    : 'text-slate-300 hover:bg-slate-800 hover:text-white'
                }`}
              >
                <Icon className={`w-4 h-4 ${isActive ? 'text-white' : 'text-slate-400'}`} />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </nav>
      </div>
    </header>
  );
};
