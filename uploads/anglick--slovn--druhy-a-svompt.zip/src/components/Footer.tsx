import React from 'react';
import { BookOpen, Sparkles, CheckCircle2 } from 'lucide-react';

export const Footer: React.FC = () => {
  return (
    <footer className="bg-slate-900 text-slate-400 text-xs py-8 border-t border-slate-800 mt-12">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col md:flex-row justify-between items-center gap-4">
        
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-lg bg-indigo-600 text-white flex items-center justify-center font-bold text-xs">
            EN
          </div>
          <div>
            <p className="font-bold text-slate-200 text-sm">
              Anglické Slovní Druhy & Pravidlo SVOMPT
            </p>
            <p className="text-slate-500">
              Aplikace pro výuku a procvičování anglické gramatiky pro české studenty.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-4 text-slate-500">
          <span className="flex items-center gap-1">
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" /> Web Speech API Výslovnost
          </span>
          <span className="flex items-center gap-1">
            <Sparkles className="w-3.5 h-3.5 text-indigo-400" /> Interaktivní Cvičení & Tvořič
          </span>
        </div>

      </div>
    </footer>
  );
};
