import React, { useState, useEffect } from 'react';
import confetti from 'canvas-confetti';
import { SENTENCES_QUIZ_BANK } from '../data/sentencesBank';
import { PARTS_OF_SPEECH } from '../data/grammarData';
import { QuizQuestion, PartOfSpeechType, UserStats } from '../types';
import { Volume2, RefreshCw, CheckCircle, XCircle, Award, Sparkles, Filter, HelpCircle } from 'lucide-react';
import { speakEnglishSentence } from '../utils/audio';

interface QuizSectionProps {
  stats: UserStats;
  setStats: React.Dispatch<React.SetStateAction<UserStats>>;
  soundEnabled: boolean;
}

export const QuizSection: React.FC<QuizSectionProps> = ({ stats, setStats, soundEnabled }) => {
  const [filterType, setFilterType] = useState<PartOfSpeechType | 'all'>('all');
  const [questions, setQuestions] = useState<QuizQuestion[]>([]);
  const [userAnswers, setUserAnswers] = useState<Record<number, string>>({});
  const [isSubmitted, setIsSubmitted] = useState<boolean>(false);
  const [score, setScore] = useState<number>(0);

  const NUM_QUESTIONS = 10;

  // Initialize or reset quiz
  const startNewQuiz = (typeFilter: PartOfSpeechType | 'all' = filterType) => {
    let pool = SENTENCES_QUIZ_BANK;
    if (typeFilter !== 'all') {
      pool = pool.filter(q => q.type === typeFilter);
    }

    if (pool.length === 0) {
      pool = SENTENCES_QUIZ_BANK; // fallback
    }

    // Shuffle
    const shuffled = [...pool].sort(() => Math.random() - 0.5);
    const selected = shuffled.slice(0, Math.min(NUM_QUESTIONS, shuffled.length));

    setQuestions(selected);
    setUserAnswers({});
    setIsSubmitted(false);
    setScore(0);
  };

  useEffect(() => {
    startNewQuiz('all');
  }, []);

  const handleFilterChange = (newFilter: PartOfSpeechType | 'all') => {
    setFilterType(newFilter);
    startNewQuiz(newFilter);
  };

  const handleSelectWord = (qIndex: number, wordClean: string) => {
    if (isSubmitted) return;
    setUserAnswers(prev => ({
      ...prev,
      [qIndex]: wordClean
    }));
  };

  const handleSpeak = (text: string) => {
    if (soundEnabled) {
      speakEnglishSentence(text);
    }
  };

  const handleSubmit = () => {
    if (isSubmitted) return;

    let totalCorrect = 0;
    questions.forEach((q, idx) => {
      const ans = userAnswers[idx];
      if (ans && ans.toLowerCase() === q.targetWord.toLowerCase()) {
        totalCorrect++;
      }
    });

    setScore(totalCorrect);
    setIsSubmitted(true);

    // Update stats
    setStats(prev => ({
      ...prev,
      quizzesCompleted: prev.quizzesCompleted + 1,
      totalQuestionsAnswered: prev.totalQuestionsAnswered + questions.length,
      correctAnswers: prev.correctAnswers + totalCorrect,
      currentStreak: prev.currentStreak + 1,
      lastActiveDate: new Date().toISOString()
    }));

    // Trigger celebratory confetti if score is >= 7
    if (totalCorrect >= 7) {
      try {
        confetti({
          particleCount: 80,
          spread: 70,
          origin: { y: 0.6 }
        });
      } catch (e) {
        // Fallback
      }
    }
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      
      {/* Quiz Header & Filters */}
      <div className="bg-white rounded-2xl p-6 shadow-sm border border-slate-200">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">
          <div>
            <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-indigo-50 text-indigo-700 border border-indigo-200 mb-2">
              <HelpCircle className="w-3.5 h-3.5" /> Interaktivní testování
            </span>
            <h2 className="text-2xl font-bold text-slate-900">
              Cvičení: Poznej Slovní Druh ve Větě
            </h2>
            <p className="text-sm text-slate-600 mt-1">
              V každé z 10 vět klikněte na slovo, které odpovídá zadání (např. Podstatné jméno, Sloveso, Příslovce).
            </p>
          </div>

          <button
            onClick={() => startNewQuiz()}
            className="self-start md:self-auto px-4 py-2.5 bg-indigo-600 text-white rounded-xl hover:bg-indigo-700 transition font-medium flex items-center gap-2 text-sm shadow-sm"
          >
            <RefreshCw className="w-4 h-4" /> Nový náhodný test
          </button>
        </div>

        {/* Filter Toolbar */}
        <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none border-t border-slate-100 pt-4">
          <span className="text-xs font-bold text-slate-500 uppercase flex items-center gap-1 shrink-0 mr-1">
            <Filter className="w-3.5 h-3.5" /> Zaměření:
          </span>
          <button
            onClick={() => handleFilterChange('all')}
            className={`px-3 py-1.5 rounded-lg text-xs font-medium shrink-0 transition ${
              filterType === 'all'
                ? 'bg-slate-900 text-white shadow-xs'
                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            Všechny druhy (Směs)
          </button>
          {PARTS_OF_SPEECH.slice(0, 6).map((pos) => (
            <button
              key={pos.id}
              onClick={() => handleFilterChange(pos.id)}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium shrink-0 transition border ${
                filterType === pos.id
                  ? `${pos.badgeClass} font-bold shadow-xs border-transparent`
                  : 'bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100'
              }`}
            >
              {pos.nameEn} ({pos.nameCz})
            </button>
          ))}
        </div>
      </div>

      {/* Questions List */}
      <div className="space-y-4">
        {questions.map((q, qIndex) => {
          const selectedWord = userAnswers[qIndex];
          const isCorrect = isSubmitted && selectedWord && selectedWord.toLowerCase() === q.targetWord.toLowerCase();
          const isWrong = isSubmitted && (!selectedWord || selectedWord.toLowerCase() !== q.targetWord.toLowerCase());

          // Split words
          const wordsWithIndex = q.text.match(/([a-zA-Z0-9'-]+)|([^a-zA-Z0-9'\s]+)/g) || [];

          return (
            <div
              key={q.id + qIndex}
              className={`p-5 rounded-2xl border transition-all ${
                isSubmitted
                  ? isCorrect
                    ? 'bg-emerald-50/80 border-emerald-300'
                    : 'bg-rose-50/80 border-rose-300'
                  : 'bg-white border-slate-200 hover:border-slate-300 shadow-xs'
              }`}
            >
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-3">
                <div className="flex items-center gap-2">
                  <span className="w-6 h-6 rounded-full bg-indigo-100 text-indigo-800 text-xs font-bold flex items-center justify-center shrink-0">
                    {qIndex + 1}
                  </span>
                  <span className="text-sm font-semibold text-slate-700">
                    Najděte ve větě:
                  </span>
                  <span className="px-3 py-1 rounded-full text-xs font-bold bg-indigo-600 text-white shadow-xs">
                    {q.labelCz}
                  </span>
                </div>

                <button
                  onClick={() => handleSpeak(q.text)}
                  className="self-start sm:self-auto text-xs text-slate-500 hover:text-indigo-600 flex items-center gap-1 font-medium transition"
                  title="Poslechnout větu"
                >
                  <Volume2 className="w-4 h-4 text-indigo-500" /> Výslovnost
                </button>
              </div>

              {/* Sentence Tokens */}
              <div className="p-4 bg-slate-50 rounded-xl border border-slate-200/80 text-base sm:text-lg leading-relaxed flex flex-wrap gap-1.5 items-center">
                {wordsWithIndex.map((token, tokenIdx) => {
                  const isWord = /^[a-zA-Z0-9'-]+$/.test(token);
                  if (!isWord) {
                    return <span key={tokenIdx} className="text-slate-600 font-normal">{token}</span>;
                  }

                  const isSelected = selectedWord === token;
                  const isTargetAndSubmitted = isSubmitted && token.toLowerCase() === q.targetWord.toLowerCase();

                  let wordStyle = 'bg-white text-slate-800 border-slate-200 hover:bg-indigo-50 hover:border-indigo-300 cursor-pointer';

                  if (isSubmitted) {
                    if (isTargetAndSubmitted) {
                      wordStyle = 'bg-emerald-600 text-white border-transparent font-bold shadow-xs';
                    } else if (isSelected && !isCorrect) {
                      wordStyle = 'bg-rose-600 text-white border-transparent font-bold line-through';
                    } else {
                      wordStyle = 'bg-slate-100 text-slate-400 border-slate-200 cursor-default';
                    }
                  } else if (isSelected) {
                    wordStyle = 'bg-indigo-600 text-white border-transparent font-bold shadow-md scale-105';
                  }

                  return (
                    <span
                      key={tokenIdx}
                      onClick={() => isWord && handleSelectWord(qIndex, token)}
                      className={`px-2 py-1 rounded-lg text-sm sm:text-base border transition-all duration-150 ${wordStyle}`}
                    >
                      {token}
                    </span>
                  );
                })}
              </div>

              {/* Post-submission Feedback */}
              {isSubmitted && (
                <div className={`mt-3 p-3 rounded-xl text-xs sm:text-sm flex items-start gap-2 ${
                  isCorrect 
                    ? 'bg-emerald-100/70 text-emerald-900 border border-emerald-200' 
                    : 'bg-rose-100/70 text-rose-900 border border-rose-200'
                }`}>
                  {isCorrect ? (
                    <CheckCircle className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
                  ) : (
                    <XCircle className="w-5 h-5 text-rose-600 shrink-0 mt-0.5" />
                  )}
                  <div>
                    <span className="font-bold">
                      {isCorrect ? 'Správně!' : `Špatně. Správné slovo bylo "${q.targetWord}".`}
                    </span>
                    <p className="mt-0.5 opacity-90">{q.explanationCz}</p>
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Results Box or Submit Button */}
      {isSubmitted ? (
        <div className="bg-gradient-to-r from-slate-900 to-indigo-950 text-white p-6 sm:p-8 rounded-2xl shadow-xl border border-slate-800 text-center animate-in zoom-in-95 duration-200">
          <Award className="w-16 h-16 text-amber-400 mx-auto mb-3" />
          <h3 className="text-2xl font-extrabold mb-1">Výsledky testu</h3>
          <p className="text-lg text-slate-300 mb-4">
            Vaše skóre: <span className="text-3xl font-black text-amber-400">{score} / {questions.length}</span>
          </p>

          <p className="text-sm text-slate-400 max-w-md mx-auto mb-6">
            {score === 10
              ? 'Perfektní výkon! Máte skvělé znalosti anglických slovních druhů.'
              : score >= 7
              ? 'Skvělá práce! Jen tak dál.'
              : 'Dobrá snaha. Zkuste si projít teorii a dát si ještě jeden test!'}
          </p>

          <button
            onClick={() => startNewQuiz()}
            className="px-8 py-3 bg-indigo-600 text-white rounded-xl hover:bg-indigo-700 font-bold transition text-base shadow-lg hover:shadow-indigo-500/20"
          >
            Zkusit nový test s jinými větami
          </button>
        </div>
      ) : (
        <div className="text-center pt-2">
          <button
            onClick={handleSubmit}
            className="w-full sm:w-auto px-10 py-4 bg-emerald-600 text-white rounded-2xl hover:bg-emerald-700 font-bold text-lg shadow-xl shadow-emerald-600/20 transition-all transform hover:-translate-y-0.5"
          >
            Vyhodnotit test
          </button>
        </div>
      )}

    </div>
  );
};
