import React, { useEffect, useRef } from 'react';
import { X, QrCode, Smartphone, Copy, Check, WifiOff } from 'lucide-react';
import QRCode from 'qrcode';

interface QrCodeModalProps {
  isOpen: boolean;
  onClose: () => void;
  appUrl: string;
}

export const QrCodeModal: React.FC<QrCodeModalProps> = ({ isOpen, onClose, appUrl }) => {
  const [copied, setCopied] = React.useState(false);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    if (isOpen && canvasRef.current) {
      QRCode.toCanvas(
        canvasRef.current,
        appUrl || window.location.href,
        {
          width: 180,
          margin: 1,
          color: {
            dark: '#312e81',
            light: '#ffffff',
          },
        },
        (error) => {
          if (error) console.error('Error generating QR code', error);
        }
      );
    }
  }, [isOpen, appUrl]);

  if (!isOpen) return null;

  const handleCopy = () => {
    navigator.clipboard.writeText(appUrl || window.location.href);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl border border-slate-100 relative animate-in fade-in zoom-in-95 duration-200">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-slate-400 hover:text-slate-600 p-1 rounded-full hover:bg-slate-100 transition-colors"
          title="Zavřít"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="text-center mb-6">
          <div className="w-12 h-12 bg-indigo-100 text-indigo-700 rounded-2xl flex items-center justify-center mx-auto mb-3">
            <QrCode className="w-6 h-6" />
          </div>
          <h3 className="text-xl font-bold text-slate-900">Sdílet nebo otevřít na mobilu</h3>
          <p className="text-sm text-slate-600 mt-1">
            Aplikace funguje 100% offline! Naskenujte QR kód a procvičujte angličtinu kdekoli bez připojení k internetu.
          </p>
        </div>

        <div className="bg-slate-50 p-6 rounded-2xl border border-slate-200 flex flex-col items-center justify-center mb-6">
          <div className="p-2 bg-white rounded-xl shadow-xs">
            <canvas ref={canvasRef} />
          </div>
          <span className="inline-flex items-center gap-1.5 mt-3 text-xs text-emerald-700 font-medium bg-emerald-50 border border-emerald-200 px-2.5 py-1 rounded-full">
            <WifiOff className="w-3.5 h-3.5 text-emerald-600" /> 100% Offline režim (bez serveru / API)
          </span>
        </div>

        <div className="space-y-3">
          <div className="flex items-center gap-2 p-2 bg-slate-100 rounded-lg text-xs font-mono text-slate-700 truncate">
            <Smartphone className="w-4 h-4 text-slate-500 shrink-0" />
            <span className="truncate">{appUrl || window.location.href}</span>
          </div>

          <button
            onClick={handleCopy}
            className="w-full py-2.5 px-4 bg-indigo-600 text-white rounded-xl hover:bg-indigo-700 transition font-medium flex items-center justify-center gap-2 text-sm shadow-sm cursor-pointer"
          >
            {copied ? (
              <>
                <Check className="w-4 h-4" /> Odkaz zkopírován!
              </>
            ) : (
              <>
                <Copy className="w-4 h-4" /> Zkopírovat odkaz aplikace
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};

