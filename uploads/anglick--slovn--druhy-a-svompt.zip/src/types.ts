export type PartOfSpeechType = 
  | 'noun' 
  | 'verb' 
  | 'adj' 
  | 'adv' 
  | 'pron' 
  | 'prep' 
  | 'conj' 
  | 'article' 
  | 'interj';

export interface PartOfSpeechInfo {
  id: PartOfSpeechType;
  nameEn: string;
  nameCz: string;
  badgeClass: string;
  badgeBg: string;
  textColor: string;
  borderColor: string;
  descriptionCz: string;
  questionCz: string;
  examplesEn: string[];
  tipsCz: string;
  iconName: string;
}

export interface SvomptElement {
  code: 'S' | 'V' | 'O' | 'M' | 'P' | 'T';
  nameEn: string;
  nameCz: string;
  questionCz: string;
  colorClass: string;
  bgClass: string;
  textClass: string;
  typicalPos: string;
  exampleText: string;
}

export interface QuizQuestion {
  id: string;
  text: string;
  targetWord: string;
  type: PartOfSpeechType;
  labelCz: string;
  explanationCz: string;
  svomptBreakdown?: {
    s?: string;
    v?: string;
    o?: string;
    m?: string;
    p?: string;
    t?: string;
  };
}

export interface SvomptPuzzle {
  id: string;
  englishFull: string;
  czechTranslation: string;
  slots: {
    s: string;
    v: string;
    o?: string;
    m?: string;
    p?: string;
    t?: string;
  };
  distractors?: string[];
}

export interface Flashcard {
  id: string;
  wordEn: string;
  wordCz: string;
  pos: PartOfSpeechType;
  exampleEn: string;
  exampleCz: string;
}

export interface UserStats {
  quizzesCompleted: number;
  totalQuestionsAnswered: number;
  correctAnswers: number;
  puzzlesSolved: number;
  currentStreak: number;
  lastActiveDate: string;
}
