import { QuizQuestion, SvomptPuzzle } from '../types';

export const SENTENCES_QUIZ_BANK: QuizQuestion[] = [
  // NOUNS (Podstatná jména)
  {
    id: 'n1',
    text: 'The quick brown fox jumps over the lazy dog.',
    targetWord: 'fox',
    type: 'noun',
    labelCz: 'Podstatné jméno (Noun)',
    explanationCz: '"fox" (liška) je podstatné jméno - pojmenovává zvíře.'
  },
  {
    id: 'n2',
    text: 'My sister bought a new car yesterday.',
    targetWord: 'sister',
    type: 'noun',
    labelCz: 'Podstatné jméno (Noun)',
    explanationCz: '"sister" (sestra) je podstatné jméno - označuje osobu.'
  },
  {
    id: 'n3',
    text: 'Prague is a very historic city in Central Europe.',
    targetWord: 'city',
    type: 'noun',
    labelCz: 'Podstatné jméno (Noun)',
    explanationCz: '"city" (město) je podstatné jméno - označuje místo.'
  },
  {
    id: 'n4',
    text: 'The teacher answered all our difficult questions.',
    targetWord: 'teacher',
    type: 'noun',
    labelCz: 'Podstatné jméno (Noun)',
    explanationCz: '"teacher" (učitel/ka) je podstatné jméno.'
  },
  {
    id: 'n5',
    text: 'Happiness is the key to a good life.',
    targetWord: 'Happiness',
    type: 'noun',
    labelCz: 'Podstatné jméno (Noun)',
    explanationCz: '"Happiness" (štěstí) je abstraktní podstatné jméno.'
  },
  {
    id: 'n6',
    text: 'The children played soccer in the local park.',
    targetWord: 'children',
    type: 'noun',
    labelCz: 'Podstatné jméno (Noun)',
    explanationCz: '"children" (děti) je podstatné jméno v množném čísle.'
  },
  {
    id: 'n7',
    text: 'Fresh water is essential for human health.',
    targetWord: 'water',
    type: 'noun',
    labelCz: 'Podstatné jméno (Noun)',
    explanationCz: '"water" (voda) je nepočitatelné podstatné jméno.'
  },
  {
    id: 'n8',
    text: 'He collected rare coins during his summer journey.',
    targetWord: 'coins',
    type: 'noun',
    labelCz: 'Podstatné jméno (Noun)',
    explanationCz: '"coins" (mince) je podstatné jméno v množném čísle.'
  },
  {
    id: 'n9',
    text: 'The heavy rain flooded the quiet streets.',
    targetWord: 'rain',
    type: 'noun',
    labelCz: 'Podstatné jméno (Noun)',
    explanationCz: '"rain" (déšť) je podstatné jméno.'
  },
  {
    id: 'n10',
    text: 'Our team won the championship trophy.',
    targetWord: 'trophy',
    type: 'noun',
    labelCz: 'Podstatné jméno (Noun)',
    explanationCz: '"trophy" (trofej/pohár) je podstatné jméno.'
  },

  // VERBS (Slovesa)
  {
    id: 'v1',
    text: 'She walks to school every morning with her friend.',
    targetWord: 'walks',
    type: 'verb',
    labelCz: 'Sloveso (Verb)',
    explanationCz: '"walks" (chodí/jde) vyjadřuje pravidelný děj a činnost.'
  },
  {
    id: 'v2',
    text: 'They built a wooden bridge across the river.',
    targetWord: 'built',
    type: 'verb',
    labelCz: 'Sloveso (Verb)',
    explanationCz: '"built" (postavili) je sloveso v minulém čase (build - built).'
  },
  {
    id: 'v3',
    text: 'I have visited the national museum twice.',
    targetWord: 'visited',
    type: 'verb',
    labelCz: 'Sloveso (Verb)',
    explanationCz: '"visited" (navštívil) je významové sloveso v předpřítomném čase.'
  },
  {
    id: 'v4',
    text: 'Please listen carefully to the teacher.',
    targetWord: 'listen',
    type: 'verb',
    labelCz: 'Sloveso (Verb)',
    explanationCz: '"listen" (poslouchej) je sloveso v rozkazovacím způsobu.'
  },
  {
    id: 'v5',
    text: 'He forgot his smartphone on the kitchen counter.',
    targetWord: 'forgot',
    type: 'verb',
    labelCz: 'Sloveso (Verb)',
    explanationCz: '"forgot" (zapomněl) je nepravidelné sloveso v minulém čase.'
  },
  {
    id: 'v6',
    text: 'The sun rises early during the summer months.',
    targetWord: 'rises',
    type: 'verb',
    labelCz: 'Sloveso (Verb)',
    explanationCz: '"rises" (vychází) vyjadřuje probíhající/přírodní děj.'
  },
  {
    id: 'v7',
    text: 'Do you understand this difficult grammar topic?',
    targetWord: 'understand',
    type: 'verb',
    labelCz: 'Sloveso (Verb)',
    explanationCz: '"understand" (rozumíš) je stavové sloveso.'
  },
  {
    id: 'v8',
    text: 'The dog barked loudly at the passing postman.',
    targetWord: 'barked',
    type: 'verb',
    labelCz: 'Sloveso (Verb)',
    explanationCz: '"barked" (štěkal) vyjadřuje slovesnou činnost.'
  },
  {
    id: 'v9',
    text: 'She can play the acoustic guitar beautifully.',
    targetWord: 'play',
    type: 'verb',
    labelCz: 'Sloveso (Verb)',
    explanationCz: '"play" (hrát) je významové sloveso za způsobovým slovesem "can".'
  },
  {
    id: 'v10',
    text: 'We baked a delicious apple pie for dinner.',
    targetWord: 'baked',
    type: 'verb',
    labelCz: 'Sloveso (Verb)',
    explanationCz: '"baked" (upekli jsme) vyjadřuje dokonaný děj.'
  },

  // ADJECTIVES (Přídavná jména)
  {
    id: 'a1',
    text: 'They live in a beautiful house near the lake.',
    targetWord: 'beautiful',
    type: 'adj',
    labelCz: 'Přídavné jméno (Adjective)',
    explanationCz: '"beautiful" (krásný) popisuje vlastnost podstatného jména "house".'
  },
  {
    id: 'a2',
    text: 'The math exam was unexpectedly difficult today.',
    targetWord: 'difficult',
    type: 'adj',
    labelCz: 'Přídavné jméno (Adjective)',
    explanationCz: '"difficult" (obtížný) popisuje vlastnost zkoušky "exam".'
  },
  {
    id: 'a3',
    text: 'She wore a bright red coat to the gallery.',
    targetWord: 'red',
    type: 'adj',
    labelCz: 'Přídavné jméno (Adjective)',
    explanationCz: '"red" (červený) specifikuje barvu kabátu.'
  },
  {
    id: 'a4',
    text: 'They served traditional Italian pizza at the bistro.',
    targetWord: 'Italian',
    type: 'adj',
    labelCz: 'Přídavné jméno (Adjective)',
    explanationCz: '"Italian" (italská) určuje původ podstatného jména.'
  },
  {
    id: 'a5',
    text: 'We drank hot tea in the cozy mountain cabin.',
    targetWord: 'hot',
    type: 'adj',
    labelCz: 'Přídavné jméno (Adjective)',
    explanationCz: '"hot" (horký) popisuje teplotu čaje.'
  },
  {
    id: 'a6',
    text: 'The old professor explained the theory patiently.',
    targetWord: 'old',
    type: 'adj',
    labelCz: 'Přídavné jméno (Adjective)',
    explanationCz: '"old" (starý) popisuje věk podstatného jména "professor".'
  },
  {
    id: 'a7',
    text: 'We breathed fresh air on top of the mountain.',
    targetWord: 'fresh',
    type: 'adj',
    labelCz: 'Přídavné jméno (Adjective)',
    explanationCz: '"fresh" (čerstvý) popisuje vzduch.'
  },
  {
    id: 'a8',
    text: 'This book offers many interesting facts about space.',
    targetWord: 'interesting',
    type: 'adj',
    labelCz: 'Přídavné jméno (Adjective)',
    explanationCz: '"interesting" (zajímavá) popisuje podstatné jméno "facts".'
  },
  {
    id: 'a9',
    text: 'The sky looks dark before the thunderstorm.',
    targetWord: 'dark',
    type: 'adj',
    labelCz: 'Přídavné jméno (Adjective)',
    explanationCz: '"dark" (tmavá) stojí po sponovém slovesu "looks".'
  },
  {
    id: 'a10',
    text: 'He bought an expensive watch for his anniversary.',
    targetWord: 'expensive',
    type: 'adj',
    labelCz: 'Přídavné jméno (Adjective)',
    explanationCz: '"expensive" (drahé) určuje hodnotu hodinek.'
  },

  // ADVERBS (Příslovce)
  {
    id: 'adv1',
    text: 'She sings beautifully in the school choir.',
    targetWord: 'beautifully',
    type: 'adv',
    labelCz: 'Příslovce (Adverb)',
    explanationCz: '"beautifully" (krásně) je příslovce způsobu určující sloveso "sings".'
  },
  {
    id: 'adv2',
    text: 'He ran quickly to catch the departing train.',
    targetWord: 'quickly',
    type: 'adv',
    labelCz: 'Příslovce (Adverb)',
    explanationCz: '"quickly" (rychle) odpovídá na otázku JAK běžel.'
  },
  {
    id: 'adv3',
    text: 'We almost missed our flight due to heavy traffic.',
    targetWord: 'almost',
    type: 'adv',
    labelCz: 'Příslovce (Adverb)',
    explanationCz: '"almost" (skoro/téměř) vyjadřuje míru.'
  },
  {
    id: 'adv4',
    text: 'The kids are playing outside in the fresh snow.',
    targetWord: 'outside',
    type: 'adv',
    labelCz: 'Příslovce (Adverb)',
    explanationCz: '"outside" (venku) je příslovce místa (KDE).'
  },
  {
    id: 'adv5',
    text: 'Students worked quietly during the examination.',
    targetWord: 'quietly',
    type: 'adv',
    labelCz: 'Příslovce (Adverb)',
    explanationCz: '"quietly" (tichounce/potichu) je příslovce způsobu.'
  },
  {
    id: 'adv6',
    text: 'She rarely drinks coffee late in the evening.',
    targetWord: 'rarely',
    type: 'adv',
    labelCz: 'Příslovce (Adverb)',
    explanationCz: '"rarely" (zřídka) je frekvenční příslovce (JAK ČASTO).'
  },
  {
    id: 'adv7',
    text: 'The weather changed very suddenly after noon.',
    targetWord: 'suddenly',
    type: 'adv',
    labelCz: 'Příslovce (Adverb)',
    explanationCz: '"suddenly" (náhle/znenádání) je příslovce způsobu.'
  },
  {
    id: 'adv8',
    text: 'He always arrives early for his business meetings.',
    targetWord: 'always',
    type: 'adv',
    labelCz: 'Příslovce (Adverb)',
    explanationCz: '"always" (vždy) je příslovce frekvence (stojí před slovesem "arrives").'
  },
  {
    id: 'adv9',
    text: 'She answered the inspector correctly without hesitation.',
    targetWord: 'correctly',
    type: 'adv',
    labelCz: 'Příslovce (Adverb)',
    explanationCz: '"correctly" (správně) popisuje JAK odpovídala.'
  },
  {
    id: 'adv10',
    text: 'We will meet you tomorrow at the main library.',
    targetWord: 'tomorrow',
    type: 'adv',
    labelCz: 'Příslovce (Adverb)',
    explanationCz: '"tomorrow" (zítra) je příslovce času (KDY).'
  },

  // PRONOUNS (Zájmena)
  {
    id: 'p1',
    text: 'They went to the stadium without asking anyone.',
    targetWord: 'They',
    type: 'pron',
    labelCz: 'Zájmeno (Pronoun)',
    explanationCz: '"They" (oni) je osobní zájmeno v podmětu.'
  },
  {
    id: 'p2',
    text: 'Is that blue umbrella yours or mine?',
    targetWord: 'yours',
    type: 'pron',
    labelCz: 'Zájmeno (Pronoun)',
    explanationCz: '"yours" (tvoje) je samostatné přivlastňovací zájmeno.'
  },
  {
    id: 'p3',
    text: 'She cooked the entire feast all by herself.',
    targetWord: 'herself',
    type: 'pron',
    labelCz: 'Zájmeno (Pronoun)',
    explanationCz: '"herself" (sama/sebe) je zvratné zájmeno.'
  },
  {
    id: 'p4',
    text: 'We decided to start our trip early.',
    targetWord: 'We',
    type: 'pron',
    labelCz: 'Zájmeno (Pronoun)',
    explanationCz: '"We" (my) je osobní zájmeno.'
  },
  {
    id: 'p5',
    text: 'Everyone was impressed by her vocal performance.',
    targetWord: 'Everyone',
    type: 'pron',
    labelCz: 'Zájmeno (Pronoun)',
    explanationCz: '"Everyone" (všichni) je neurčité zájmeno.'
  },
  {
    id: 'p6',
    text: 'The police officer asked who saw the accident.',
    targetWord: 'who',
    type: 'pron',
    labelCz: 'Zájmeno (Pronoun)',
    explanationCz: '"who" (kdo) je tázací / vztažné zájmeno.'
  },
  {
    id: 'p7',
    text: 'He built this wooden birdhouse all by himself.',
    targetWord: 'himself',
    type: 'pron',
    labelCz: 'Zájmeno (Pronoun)',
    explanationCz: '"himself" (sám) je zdůrazňovací zvratné zájmeno.'
  },
  {
    id: 'p8',
    text: 'That is the author whose novel became a bestseller.',
    targetWord: 'whose',
    type: 'pron',
    labelCz: 'Zájmeno (Pronoun)',
    explanationCz: '"whose" (jehož/jejíž) je přivlastňovací vztažné zájmeno.'
  },
  {
    id: 'p9',
    text: 'Let us go to the countryside this weekend.',
    targetWord: 'us',
    type: 'pron',
    labelCz: 'Zájmeno (Pronoun)',
    explanationCz: '"us" (nám/nás) je osobní zájmeno v předmětném tvaru.'
  },
  {
    id: 'p10',
    text: 'Neither of the candidates accepted the invitation.',
    targetWord: 'Neither',
    type: 'pron',
    labelCz: 'Zájmeno (Pronoun)',
    explanationCz: '"Neither" (ani jeden) je vymezovací zájmeno.'
  },

  // PREPOSITIONS (Předložky)
  {
    id: 'pr1',
    text: 'The vintage clock hangs directly on the wall.',
    targetWord: 'on',
    type: 'prep',
    labelCz: 'Předložka (Preposition)',
    explanationCz: '"on" (na) vyjadřuje místní polohu.'
  },
  {
    id: 'pr2',
    text: 'She walked safely across the busy street.',
    targetWord: 'across',
    type: 'prep',
    labelCz: 'Předložka (Preposition)',
    explanationCz: '"across" (přes) je předložka směru a místa.'
  },
  {
    id: 'pr3',
    text: 'We sheltered under the balcony during the shower.',
    targetWord: 'under',
    type: 'prep',
    labelCz: 'Předložka (Preposition)',
    explanationCz: '"under" (pod) určuje polohu.'
  },
  {
    id: 'pr4',
    text: 'The ceremony starts strictly at seven o clock.',
    targetWord: 'at',
    type: 'prep',
    labelCz: 'Předložka (Preposition)',
    explanationCz: '"at" (v) je časová předložka určující přesnou hodinu.'
  },
  {
    id: 'pr5',
    text: 'They traveled across Europe by high-speed train.',
    targetWord: 'by',
    type: 'prep',
    labelCz: 'Předložka (Preposition)',
    explanationCz: '"by" (vlakem) vyjadřuje způsob dopravy.'
  },
  {
    id: 'pr6',
    text: 'The frightened cat jumped over the wooden fence.',
    targetWord: 'over',
    type: 'prep',
    labelCz: 'Předložka (Preposition)',
    explanationCz: '"over" (přes) vyjadřuje pohyb přes překážku.'
  },
  {
    id: 'pr7',
    text: 'He carefully poured fresh milk into the cup.',
    targetWord: 'into',
    type: 'prep',
    labelCz: 'Předložka (Preposition)',
    explanationCz: '"into" (do) vyjadřuje směr pohybu dovnitř.'
  },
  {
    id: 'pr8',
    text: 'I have lived in this city since 2018.',
    targetWord: 'since',
    type: 'prep',
    labelCz: 'Předložka (Preposition)',
    explanationCz: '"since" (od) určuje počátek časového úseku.'
  },
  {
    id: 'pr9',
    text: 'She sat comfortably between her two best friends.',
    targetWord: 'between',
    type: 'prep',
    labelCz: 'Předložka (Preposition)',
    explanationCz: '"between" (mezi dvěma) vyjadřuje polohu.'
  },
  {
    id: 'pr10',
    text: 'Keep the golden key safe inside your pocket.',
    targetWord: 'inside',
    type: 'prep',
    labelCz: 'Předložka (Preposition)',
    explanationCz: '"inside" (uvnitř) je předložka místa.'
  },

  // CONJUNCTIONS (Spojky)
  {
    id: 'c1',
    text: 'He wanted to come, but he had to work late.',
    targetWord: 'but',
    type: 'conj',
    labelCz: 'Spojka (Conjunction)',
    explanationCz: '"but" (ale) spojuje věty v odporovacím poměru.'
  },
  {
    id: 'c2',
    text: 'We stayed at home because it rained heavily.',
    targetWord: 'because',
    type: 'conj',
    labelCz: 'Spojka (Conjunction)',
    explanationCz: '"because" (protože) uvádí příčinnou větu.'
  },
  {
    id: 'c3',
    text: 'You can choose tea or fresh orange juice.',
    targetWord: 'or',
    type: 'conj',
    labelCz: 'Spojka (Conjunction)',
    explanationCz: '"or" (nebo) vyjadřuje možnost / volbu.'
  },
  {
    id: 'c4',
    text: 'Although it was freezing, they went for a walk.',
    targetWord: 'Although',
    type: 'conj',
    labelCz: 'Spojka (Conjunction)',
    explanationCz: '"Although" (ačkoli/přestože) uvádí přípustkovou větu.'
  }
];

export const SVOMPT_PUZZLES: SvomptPuzzle[] = [
  {
    id: 'puzzle1',
    englishFull: 'The dog ate its dinner quickly in the garden yesterday.',
    czechTranslation: 'Pes včera na zahradě rychle snědl svou večeři.',
    slots: {
      s: 'The dog',
      v: 'ate',
      o: 'its dinner',
      m: 'quickly',
      p: 'in the garden',
      t: 'yesterday'
    }
  },
  {
    id: 'puzzle2',
    englishFull: 'My sister reads fantasy books quietly in her room every evening.',
    czechTranslation: 'Moje sestra si každý večer ve svém pokoji potichu čte fantasy knížky.',
    slots: {
      s: 'My sister',
      v: 'reads',
      o: 'fantasy books',
      m: 'quietly',
      p: 'in her room',
      t: 'every evening'
    }
  },
  {
    id: 'puzzle3',
    englishFull: 'The students solved the math test easily at school last Friday.',
    czechTranslation: 'Studenti minulý pátek ve škole snadno vyřešili matematický test.',
    slots: {
      s: 'The students',
      v: 'solved',
      o: 'the math test',
      m: 'easily',
      p: 'at school',
      t: 'last Friday'
    }
  },
  {
    id: 'puzzle4',
    englishFull: 'Peter play piano passionately on the stage last night.',
    czechTranslation: 'Petr včera večer na pódiu vášnivě hrál na klavír.',
    slots: {
      s: 'Peter',
      v: 'played',
      o: 'the piano',
      m: 'passionately',
      p: 'on the stage',
      t: 'last night'
    }
  },
  {
    id: 'puzzle5',
    englishFull: 'We drank hot cocoa happily by the fireplace during the winter storm.',
    czechTranslation: 'Během zimní bouřky jsme si u krbu šťastně pili horké kakao.',
    slots: {
      s: 'We',
      v: 'drank',
      o: 'hot cocoa',
      m: 'happily',
      p: 'by the fireplace',
      t: 'during the storm'
    }
  },
  {
    id: 'puzzle6',
    englishFull: 'She drives her electric car slowly through the city center every morning.',
    czechTranslation: 'Ona každé ráno projíždí svým elektromobilem pomalu centrem města.',
    slots: {
      s: 'She',
      v: 'drives',
      o: 'her electric car',
      m: 'slowly',
      p: 'through the city center',
      t: 'every morning'
    }
  },
  {
    id: 'puzzle7',
    englishFull: 'Our team won the championship trophy proudly in London last month.',
    czechTranslation: 'Náš tým minulý měsíc v Londýně hrdě vyhrál mistrovskou trofej.',
    slots: {
      s: 'Our team',
      v: 'won',
      o: 'the trophy',
      m: 'proudly',
      p: 'in London',
      t: 'last month'
    }
  }
];
