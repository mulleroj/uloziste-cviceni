import { Flashcard } from '../types';

export const FLASHCARDS_DATA: Flashcard[] = [
  {
    id: 'fc1',
    wordEn: 'quickly',
    wordCz: 'rychle',
    pos: 'adv',
    exampleEn: 'He ran quickly to catch the bus.',
    exampleCz: 'Rychle běžel, aby stihl autobus.'
  },
  {
    id: 'fc2',
    wordEn: 'beautiful',
    wordCz: 'krásný, nádherný',
    pos: 'adj',
    exampleEn: 'What a beautiful morning!',
    exampleCz: 'To je ale krásné ráno!'
  },
  {
    id: 'fc3',
    wordEn: 'between',
    wordCz: 'mezi (dvěma)',
    pos: 'prep',
    exampleEn: 'Sit between John and Mary.',
    exampleCz: 'Posaď se mezi Johna a Mary.'
  },
  {
    id: 'fc4',
    wordEn: 'happiness',
    wordCz: 'štěstí',
    pos: 'noun',
    exampleEn: 'Money cannot buy true happiness.',
    exampleCz: 'Peníze si skutečné štěstí koupit nemohou.'
  },
  {
    id: 'fc5',
    wordEn: 'although',
    wordCz: 'ačkoli, přestože',
    pos: 'conj',
    exampleEn: 'Although it rained, we went out.',
    exampleCz: 'Ačkoli pršelo, šli jsme ven.'
  },
  {
    id: 'fc6',
    wordEn: 'myself',
    wordCz: 'já sám / sebe',
    pos: 'pron',
    exampleEn: 'I made this tea all by myself.',
    exampleCz: 'Tento čaj jsem udělal úplně sám.'
  },
  {
    id: 'fc7',
    wordEn: 'understand',
    wordCz: 'rozumět, chápat',
    pos: 'verb',
    exampleEn: 'Do you understand English grammar?',
    exampleCz: 'Rozumíš anglické gramatice?'
  },
  {
    id: 'fc8',
    wordEn: 'yesterday',
    wordCz: 'včera',
    pos: 'adv',
    exampleEn: 'I met her at school yesterday.',
    exampleCz: 'Včera jsem ji potkal ve škole.'
  },
  {
    id: 'fc9',
    wordEn: 'expensive',
    wordCz: 'drahý (o ceně)',
    pos: 'adj',
    exampleEn: 'This watch is too expensive.',
    exampleCz: 'Tyhle hodinky jsou příliš drahé.'
  },
  {
    id: 'fc10',
    wordEn: 'behind',
    wordCz: 'za (místně)',
    pos: 'prep',
    exampleEn: 'The cat is hiding behind the sofa.',
    exampleCz: 'Kočka se schovává za pohovkou.'
  },
  {
    id: 'fc11',
    wordEn: 'achievement',
    wordCz: 'úspěch, výsledek',
    pos: 'noun',
    exampleEn: 'Winning the prize was a great achievement.',
    exampleCz: 'Získání ceny byl velký úspěch.'
  },
  {
    id: 'fc12',
    wordEn: 'rarely',
    wordCz: 'zřídka, málokdy',
    pos: 'adv',
    exampleEn: 'She rarely eats fast food.',
    exampleCz: 'Zřídka jí rychlé občerstvení.'
  }
];
