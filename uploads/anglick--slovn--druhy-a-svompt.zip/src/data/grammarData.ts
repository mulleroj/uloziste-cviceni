import { PartOfSpeechInfo, SvomptElement } from '../types';

export const PARTS_OF_SPEECH: PartOfSpeechInfo[] = [
  {
    id: 'noun',
    nameEn: 'Noun',
    nameCz: 'Podstatné jméno',
    badgeClass: 'bg-blue-100 text-blue-800 border-blue-200 hover:bg-blue-200',
    badgeBg: 'bg-blue-500',
    textColor: 'text-blue-700',
    borderColor: 'border-blue-300',
    descriptionCz: 'Pojmenovává osoby, zvířata, místa, věci nebo abstraktní pojmy.',
    questionCz: 'Kdo? Co?',
    examplesEn: ['dog', 'teacher', 'London', 'happiness', 'apple', 'freedom'],
    tipsCz: 'V angličtině před podstatnými jmény často stojí člen (a, an, the). Dělí se na počitatelná (a car, three cars) a nepočitatelná (water, information, money).',
    iconName: 'BookOpen'
  },
  {
    id: 'verb',
    nameEn: 'Verb',
    nameCz: 'Sloveso',
    badgeClass: 'bg-rose-100 text-rose-800 border-rose-200 hover:bg-rose-200',
    badgeBg: 'bg-rose-500',
    textColor: 'text-rose-700',
    borderColor: 'border-rose-300',
    descriptionCz: 'Vyjadřuje děj, činnost, stav nebo proces. Je srdcem každé anglické věty.',
    questionCz: 'Co dělá? Co se s ním děje?',
    examplesEn: ['run', 'speak', 'is/are', 'think', 'have', 'enjoy'],
    tipsCz: 'Každá správná anglická oznamovací věta MUSÍ mít vyjádřené sloveso. Pomocná slovesa (do, be, have, will) pomáhají tvořit časy a otázky.',
    iconName: 'Zap'
  },
  {
    id: 'adj',
    nameEn: 'Adjective',
    nameCz: 'Přídavné jméno',
    badgeClass: 'bg-amber-100 text-amber-800 border-amber-200 hover:bg-amber-200',
    badgeBg: 'bg-amber-500',
    textColor: 'text-amber-700',
    borderColor: 'border-amber-300',
    descriptionCz: 'Popisuje vlastnosti podstatných jmen (jaký, který, čí).',
    questionCz: 'Jaký? Který? Čí?',
    examplesEn: ['big', 'beautiful', 'red', 'expensive', 'smart', 'Czech'],
    tipsCz: 'V angličtině stojí přídavné jméno VŽDY PŘED podstatným jménem (a red car) nebo po sponových slovesech jako "be" či "seem" (the car is red). Nemění svůj tvar v množném čísle!',
    iconName: 'Sparkles'
  },
  {
    id: 'adv',
    nameEn: 'Adverb',
    nameCz: 'Příslovce',
    badgeClass: 'bg-emerald-100 text-emerald-800 border-emerald-200 hover:bg-emerald-200',
    badgeBg: 'bg-emerald-500',
    textColor: 'text-emerald-700',
    borderColor: 'border-emerald-300',
    descriptionCz: 'Bližší určuje sloveso, přídavné jméno nebo jiné příslovce (jak, kdy, kde, jak často).',
    questionCz: 'Jak? Kdy? Kde? Jak často?',
    examplesEn: ['quickly', 'yesterday', 'here', 'always', 'very', 'well'],
    tipsCz: 'Mnoho příslovcí způsobu tvoří příponou -ly (quick -> quickly). Časová a místní příslovce se dávají obvykle na konec věty (pravidlo SVOMPT).',
    iconName: 'TrendingUp'
  },
  {
    id: 'pron',
    nameEn: 'Pronoun',
    nameCz: 'Zájmeno',
    badgeClass: 'bg-indigo-100 text-indigo-800 border-indigo-200 hover:bg-indigo-200',
    badgeBg: 'bg-indigo-500',
    textColor: 'text-indigo-700',
    borderColor: 'border-indigo-300',
    descriptionCz: 'Zastupuje nebo nahrazuje podstatné jméno, aby se neopakoval stejný výraz.',
    questionCz: 'Kdo? Co? Koho? Čí?',
    examplesEn: ['I', 'you', 'he', 'she', 'it', 'we', 'they', 'mine', 'himself', 'this'],
    tipsCz: 'Osobní zájmeno "I" (já) se v angličtině píše VŽDY velkým písmenem, bez ohledu na to, kde ve větě stojí.',
    iconName: 'UserCheck'
  },
  {
    id: 'prep',
    nameEn: 'Preposition',
    nameCz: 'Předložka',
    badgeClass: 'bg-orange-100 text-orange-800 border-orange-200 hover:bg-orange-200',
    badgeBg: 'bg-orange-500',
    textColor: 'text-orange-700',
    borderColor: 'border-orange-300',
    descriptionCz: 'Vyjadřuje prostory, časové a jiné vztahy mezi slovy ve větě.',
    questionCz: 'Kde? Kdy? Kam? S kým?',
    examplesEn: ['in', 'on', 'at', 'under', 'behind', 'between', 'during', 'with'],
    tipsCz: 'Pozor na typické anglické vazby: in the morning, on Monday, at 5 o\'clock. Anglické předložky se neshodují 1:1 s českými pádovými předložkami.',
    iconName: 'MapPin'
  },
  {
    id: 'conj',
    nameEn: 'Conjunction',
    nameCz: 'Spojka',
    badgeClass: 'bg-purple-100 text-purple-800 border-purple-200 hover:bg-purple-200',
    badgeBg: 'bg-purple-500',
    textColor: 'text-purple-700',
    borderColor: 'border-purple-300',
    descriptionCz: 'Spojuje jednotlivá slova, slovní spojení nebo celé věty.',
    questionCz: 'Spojovací výraz',
    examplesEn: ['and', 'but', 'because', 'although', 'or', 'so', 'if', 'while'],
    tipsCz: 'V angličtině se před spojkou "and" nebo "because" čárka většinou NEPÍŠE, na rozdíl od češtiny!',
    iconName: 'Link'
  },
  {
    id: 'article',
    nameEn: 'Article & Interjection',
    nameCz: 'Člen a Citoslovce',
    badgeClass: 'bg-teal-100 text-teal-800 border-teal-200 hover:bg-teal-200',
    badgeBg: 'bg-teal-500',
    textColor: 'text-teal-700',
    borderColor: 'border-teal-300',
    descriptionCz: 'Členy (a, an, the) specifikují podstatná jména. Citoslovce vyjadřují emoce a zvuky (Oh!, Wow!).',
    questionCz: 'Který konkrétně? / Emocionální výraz',
    examplesEn: ['a', 'an', 'the', 'Oh', 'Wow', 'Ouch', 'Hey'],
    tipsCz: 'Člen "a" stojí před souhláskou (a book), člen "an" před výslovností samohlásky (an apple, an hour). "The" je člen určitý.',
    iconName: 'MessageSquare'
  }
];

export const SVOMPT_ELEMENTS: SvomptElement[] = [
  {
    code: 'S',
    nameEn: 'Subject',
    nameCz: 'Podmět',
    questionCz: 'Kdo? Co?',
    colorClass: 'text-indigo-600 border-indigo-300 bg-indigo-50',
    bgClass: 'bg-indigo-600',
    textClass: 'text-indigo-600',
    typicalPos: 'Podstatná jména, Zájmena',
    exampleText: 'The clever dog'
  },
  {
    code: 'V',
    nameEn: 'Verb',
    nameCz: 'Přísudek / Sloveso',
    questionCz: 'Co dělá?',
    colorClass: 'text-rose-600 border-rose-300 bg-rose-50',
    bgClass: 'bg-rose-600',
    textClass: 'text-rose-600',
    typicalPos: 'Slovesa (hlavní i pomocná)',
    exampleText: 'ate'
  },
  {
    code: 'O',
    nameEn: 'Object',
    nameCz: 'Předmět',
    questionCz: 'Koho? Co?',
    colorClass: 'text-blue-600 border-blue-300 bg-blue-50',
    bgClass: 'bg-blue-600',
    textClass: 'text-blue-600',
    typicalPos: 'Podstatná jména, Zájmena',
    exampleText: 'a juicy bone'
  },
  {
    code: 'M',
    nameEn: 'Manner',
    nameCz: 'Příslovečné určení způsobu',
    questionCz: 'Jak?',
    colorClass: 'text-emerald-600 border-emerald-300 bg-emerald-50',
    bgClass: 'bg-emerald-600',
    textClass: 'text-emerald-600',
    typicalPos: 'Příslovce způsobu (-ly)',
    exampleText: 'eagerly'
  },
  {
    code: 'P',
    nameEn: 'Place',
    nameCz: 'Příslovečné určení místa',
    questionCz: 'Kde? Kam?',
    colorClass: 'text-orange-600 border-orange-300 bg-orange-50',
    bgClass: 'bg-orange-600',
    textClass: 'text-orange-600',
    typicalPos: 'Předložkové vazby, Příslovce místa',
    exampleText: 'in the garden'
  },
  {
    code: 'T',
    nameEn: 'Time',
    nameCz: 'Příslovečné určení času',
    questionCz: 'Kdy? Jak dlouho?',
    colorClass: 'text-purple-600 border-purple-300 bg-purple-50',
    bgClass: 'bg-purple-600',
    textClass: 'text-purple-600',
    typicalPos: 'Časové výrazy, Příslovce času',
    exampleText: 'yesterday afternoon.'
  }
];
