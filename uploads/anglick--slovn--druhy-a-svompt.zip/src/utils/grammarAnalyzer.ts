import { PartOfSpeechType } from '../types';

export interface TaggedWord {
  raw: string;
  wordClean: string;
  punctuationAfter: string;
  pos: PartOfSpeechType;
  posNameCz: string;
  badgeClass: string;
  explanationCz: string;
  svomptRole?: 'S' | 'V' | 'O' | 'M' | 'P' | 'T';
}

export interface SentenceAnalysisResult {
  sentence: string;
  words: TaggedWord[];
  svomptFeedback: {
    status: 'good' | 'warning' | 'info';
    messageCz: string;
    detectedOrder: string[];
  };
  posSummaryCounts: Record<PartOfSpeechType, number>;
}

// Word dictionary for instant tagging accuracy
const DICTIONARY: Record<string, { pos: PartOfSpeechType; nameCz: string; badgeClass: string; explanation: string }> = {
  // Articles
  a: { pos: 'article', nameCz: 'Člen neurčitý', badgeClass: 'bg-teal-100 text-teal-800 border-teal-200', explanation: 'Člen neurčitý před souhláskou' },
  an: { pos: 'article', nameCz: 'Člen neurčitý', badgeClass: 'bg-teal-100 text-teal-800 border-teal-200', explanation: 'Člen neurčitý před výslovností samohlásky' },
  the: { pos: 'article', nameCz: 'Člen určitý', badgeClass: 'bg-teal-100 text-teal-800 border-teal-200', explanation: 'Člen určitý pro známou věc' },

  // Pronouns
  i: { pos: 'pron', nameCz: 'Zájmeno osobný', badgeClass: 'bg-indigo-100 text-indigo-800 border-indigo-200', explanation: 'Osobní zájmeno (já)' },
  you: { pos: 'pron', nameCz: 'Zájmeno osobný', badgeClass: 'bg-indigo-100 text-indigo-800 border-indigo-200', explanation: 'Osobní zájmeno (ty/vy)' },
  he: { pos: 'pron', nameCz: 'Zájmeno osobný', badgeClass: 'bg-indigo-100 text-indigo-800 border-indigo-200', explanation: 'Osobní zájmeno (on)' },
  she: { pos: 'pron', nameCz: 'Zájmeno osobný', badgeClass: 'bg-indigo-100 text-indigo-800 border-indigo-200', explanation: 'Osobní zájmeno (ona)' },
  it: { pos: 'pron', nameCz: 'Zájmeno osobný', badgeClass: 'bg-indigo-100 text-indigo-800 border-indigo-200', explanation: 'Osobní zájmeno (to/ono)' },
  we: { pos: 'pron', nameCz: 'Zájmeno osobný', badgeClass: 'bg-indigo-100 text-indigo-800 border-indigo-200', explanation: 'Osobní zájmeno (my)' },
  they: { pos: 'pron', nameCz: 'Zájmeno osobný', badgeClass: 'bg-indigo-100 text-indigo-800 border-indigo-200', explanation: 'Osobní zájmeno (oni/ony)' },
  me: { pos: 'pron', nameCz: 'Zájmeno', badgeClass: 'bg-indigo-100 text-indigo-800 border-indigo-200', explanation: 'Osobní zájmeno v pádovém tvaru (mě/mně)' },
  him: { pos: 'pron', nameCz: 'Zájmeno', badgeClass: 'bg-indigo-100 text-indigo-800 border-indigo-200', explanation: 'Osobní zájmeno (ho/jemu)' },
  her: { pos: 'pron', nameCz: 'Zájmeno', badgeClass: 'bg-indigo-100 text-indigo-800 border-indigo-200', explanation: 'Osobní/přivlastňovací zájmeno (jí/její)' },
  us: { pos: 'pron', nameCz: 'Zájmeno', badgeClass: 'bg-indigo-100 text-indigo-800 border-indigo-200', explanation: 'Osobní zájmeno (nám/nás)' },
  them: { pos: 'pron', nameCz: 'Zájmeno', badgeClass: 'bg-indigo-100 text-indigo-800 border-indigo-200', explanation: 'Osobní zájmeno (jim/je)' },
  my: { pos: 'pron', nameCz: 'Zájmeno přivlastňovací', badgeClass: 'bg-indigo-100 text-indigo-800 border-indigo-200', explanation: 'Přivlastňovací zájmeno (můj)' },
  your: { pos: 'pron', nameCz: 'Zájmeno přivlastňovací', badgeClass: 'bg-indigo-100 text-indigo-800 border-indigo-200', explanation: 'Přivlastňovací zájmeno (tůj/váš)' },
  his: { pos: 'pron', nameCz: 'Zájmeno přivlastňovací', badgeClass: 'bg-indigo-100 text-indigo-800 border-indigo-200', explanation: 'Přivlastňovací zájmeno (jeho)' },
  its: { pos: 'pron', nameCz: 'Zájmeno přivlastňovací', badgeClass: 'bg-indigo-100 text-indigo-800 border-indigo-200', explanation: 'Přivlastňovací zájmeno (jeho/její neosobní)' },
  our: { pos: 'pron', nameCz: 'Zájmeno přivlastňovací', badgeClass: 'bg-indigo-100 text-indigo-800 border-indigo-200', explanation: 'Přivlastňovací zájmeno (náš)' },
  their: { pos: 'pron', nameCz: 'Zájmeno přivlastňovací', badgeClass: 'bg-indigo-100 text-indigo-800 border-indigo-200', explanation: 'Přivlastňovací zájmeno (jejich)' },
  this: { pos: 'pron', nameCz: 'Zájmeno ukazovací', badgeClass: 'bg-indigo-100 text-indigo-800 border-indigo-200', explanation: 'Ukazovací zájmeno (tento)' },
  that: { pos: 'pron', nameCz: 'Zájmeno ukazovací', badgeClass: 'bg-indigo-100 text-indigo-800 border-indigo-200', explanation: 'Ukazovací zájmeno (tamten)' },
  these: { pos: 'pron', nameCz: 'Zájmeno ukazovací', badgeClass: 'bg-indigo-100 text-indigo-800 border-indigo-200', explanation: 'Ukazovací zájmeno (tyto)' },
  those: { pos: 'pron', nameCz: 'Zájmeno ukazovací', badgeClass: 'bg-indigo-100 text-indigo-800 border-indigo-200', explanation: 'Ukazovací zájmeno (tamty)' },
  who: { pos: 'pron', nameCz: 'Zájmeno vztažné', badgeClass: 'bg-indigo-100 text-indigo-800 border-indigo-200', explanation: 'Tázací / vztažné zájmeno (kdo/který)' },
  what: { pos: 'pron', nameCz: 'Zájmeno tázací', badgeClass: 'bg-indigo-100 text-indigo-800 border-indigo-200', explanation: 'Tázací zájmeno (co/jaký)' },
  everyone: { pos: 'pron', nameCz: 'Zájmeno neurčité', badgeClass: 'bg-indigo-100 text-indigo-800 border-indigo-200', explanation: 'Neurčité zájmeno (všichni)' },
  someone: { pos: 'pron', nameCz: 'Zájmeno neurčité', badgeClass: 'bg-indigo-100 text-indigo-800 border-indigo-200', explanation: 'Neurčité zájmeno (někdo)' },
  nobody: { pos: 'pron', nameCz: 'Zájmeno záporné', badgeClass: 'bg-indigo-100 text-indigo-800 border-indigo-200', explanation: 'Záporné zájmeno (nikdo)' },

  // Prepositions
  in: { pos: 'prep', nameCz: 'Předložka', badgeClass: 'bg-orange-100 text-orange-800 border-orange-200', explanation: 'Předložka místa nebo času (v/ve)' },
  on: { pos: 'prep', nameCz: 'Předložka', badgeClass: 'bg-orange-100 text-orange-800 border-orange-200', explanation: 'Předložka na (povrchu) / dny v týdnu' },
  at: { pos: 'prep', nameCz: 'Předložka', badgeClass: 'bg-orange-100 text-orange-800 border-orange-200', explanation: 'Předložka v (přesném bodě / času)' },
  under: { pos: 'prep', nameCz: 'Předložka', badgeClass: 'bg-orange-100 text-orange-800 border-orange-200', explanation: 'Předložka pod' },
  over: { pos: 'prep', nameCz: 'Předložka', badgeClass: 'bg-orange-100 text-orange-800 border-orange-200', explanation: 'Předložka nad/přes' },
  above: { pos: 'prep', nameCz: 'Předložka', badgeClass: 'bg-orange-100 text-orange-800 border-orange-200', explanation: 'Předložka nad (bez dotyku)' },
  below: { pos: 'prep', nameCz: 'Předložka', badgeClass: 'bg-orange-100 text-orange-800 border-orange-200', explanation: 'Předložka pod (nižší úroveň)' },
  behind: { pos: 'prep', nameCz: 'Předložka', badgeClass: 'bg-orange-100 text-orange-800 border-orange-200', explanation: 'Předložka za' },
  between: { pos: 'prep', nameCz: 'Předložka', badgeClass: 'bg-orange-100 text-orange-800 border-orange-200', explanation: 'Předložka mezi dvěma' },
  with: { pos: 'prep', nameCz: 'Předložka', badgeClass: 'bg-orange-100 text-orange-800 border-orange-200', explanation: 'Předložka s/se' },
  without: { pos: 'prep', nameCz: 'Předložka', badgeClass: 'bg-orange-100 text-orange-800 border-orange-200', explanation: 'Předložka bez' },
  by: { pos: 'prep', nameCz: 'Předložka', badgeClass: 'bg-orange-100 text-orange-800 border-orange-200', explanation: 'Předložka kým/čím, vedle, do času' },
  from: { pos: 'prep', nameCz: 'Předložka', badgeClass: 'bg-orange-100 text-orange-800 border-orange-200', explanation: 'Předložka z/od' },
  to: { pos: 'prep', nameCz: 'Předložka', badgeClass: 'bg-orange-100 text-orange-800 border-orange-200', explanation: 'Předložka k/do (směr)' },
  into: { pos: 'prep', nameCz: 'Předložka', badgeClass: 'bg-orange-100 text-orange-800 border-orange-200', explanation: 'Předložka do (dovnitř)' },
  during: { pos: 'prep', nameCz: 'Předložka', badgeClass: 'bg-orange-100 text-orange-800 border-orange-200', explanation: 'Předložka během' },
  since: { pos: 'prep', nameCz: 'Předložka', badgeClass: 'bg-orange-100 text-orange-800 border-orange-200', explanation: 'Předložka od (časový počátek)' },

  // Conjunctions
  and: { pos: 'conj', nameCz: 'Spojka', badgeClass: 'bg-purple-100 text-purple-800 border-purple-200', explanation: 'Spojka slučovací (a)' },
  but: { pos: 'conj', nameCz: 'Spojka', badgeClass: 'bg-purple-100 text-purple-800 border-purple-200', explanation: 'Spojka odporovací (ale)' },
  or: { pos: 'conj', nameCz: 'Spojka', badgeClass: 'bg-purple-100 text-purple-800 border-purple-200', explanation: 'Spojka vylučovací (nebo)' },
  because: { pos: 'conj', nameCz: 'Spojka', badgeClass: 'bg-purple-100 text-purple-800 border-purple-200', explanation: 'Spojka podřadicí (protože)' },
  although: { pos: 'conj', nameCz: 'Spojka', badgeClass: 'bg-purple-100 text-purple-800 border-purple-200', explanation: 'Spojka přípustková (ačkoli)' },
  if: { pos: 'conj', nameCz: 'Spojka', badgeClass: 'bg-purple-100 text-purple-800 border-purple-200', explanation: 'Spojka podmínková (když/jestliže)' },
  so: { pos: 'conj', nameCz: 'Spojka', badgeClass: 'bg-purple-100 text-purple-800 border-purple-200', explanation: 'Spojka důsledková (takže)' },

  // Common Adverbs of Frequency & Time
  always: { pos: 'adv', nameCz: 'Příslovce frekvence', badgeClass: 'bg-emerald-100 text-emerald-800 border-emerald-200', explanation: 'Příslovce frekvence (vždy) - stojí před slovesem' },
  never: { pos: 'adv', nameCz: 'Příslovce frekvence', badgeClass: 'bg-emerald-100 text-emerald-800 border-emerald-200', explanation: 'Záporné příslovce frekvence (nikdy)' },
  often: { pos: 'adv', nameCz: 'Příslovce frekvence', badgeClass: 'bg-emerald-100 text-emerald-800 border-emerald-200', explanation: 'Příslovce frekvence (často)' },
  usually: { pos: 'adv', nameCz: 'Příslovce frekvence', badgeClass: 'bg-emerald-100 text-emerald-800 border-emerald-200', explanation: 'Příslovce frekvence (obvykle)' },
  rarely: { pos: 'adv', nameCz: 'Příslovce frekvence', badgeClass: 'bg-emerald-100 text-emerald-800 border-emerald-200', explanation: 'Příslovce frekvence (zřídka)' },
  yesterday: { pos: 'adv', nameCz: 'Příslovce času', badgeClass: 'bg-emerald-100 text-emerald-800 border-emerald-200', explanation: 'Příslovce času (včera) - patří na konec (Time)' },
  today: { pos: 'adv', nameCz: 'Příslovce času', badgeClass: 'bg-emerald-100 text-emerald-800 border-emerald-200', explanation: 'Příslovce času (dnes)' },
  tomorrow: { pos: 'adv', nameCz: 'Příslovce času', badgeClass: 'bg-emerald-100 text-emerald-800 border-emerald-200', explanation: 'Příslovce času (zítra)' },
  very: { pos: 'adv', nameCz: 'Příslovce míry', badgeClass: 'bg-emerald-100 text-emerald-800 border-emerald-200', explanation: 'Příslovce míry (velmi)' },
  well: { pos: 'adv', nameCz: 'Příslovce způsobu', badgeClass: 'bg-emerald-100 text-emerald-800 border-emerald-200', explanation: 'Příslovce způsobu (dobře)' }
};

export const analyzeSentence = (rawSentence: string): SentenceAnalysisResult => {
  const trimmed = rawSentence.trim();
  const tokens = trimmed.split(/\s+/);

  const words: TaggedWord[] = [];
  const posSummaryCounts: Record<PartOfSpeechType, number> = {
    noun: 0,
    verb: 0,
    adj: 0,
    adv: 0,
    pron: 0,
    prep: 0,
    conj: 0,
    article: 0,
    interj: 0
  };

  tokens.forEach((token) => {
    // Extract word and surrounding punctuation
    const match = token.match(/^([^a-zA-Z0-9]*)([a-zA-Z0-9'-]+)([^a-zA-Z0-9]*)$/);
    if (!match) return;

    const wordClean = match[2];
    const punctuationAfter = match[3] || '';
    const lowerWord = wordClean.toLowerCase();

    let pos: PartOfSpeechType = 'noun';
    let posNameCz = 'Podstatné jméno';
    let badgeClass = 'bg-blue-100 text-blue-800 border-blue-200';
    let explanationCz = 'Pojmenovává osobu, věc, místo nebo pojem.';

    // Check direct dictionary first
    if (DICTIONARY[lowerWord]) {
      const entry = DICTIONARY[lowerWord];
      pos = entry.pos;
      posNameCz = entry.nameCz;
      badgeClass = entry.badgeClass;
      explanationCz = entry.explanation;
    } else {
      // Heuristics for English morphology
      if (lowerWord.endsWith('ly') && lowerWord.length > 3) {
        pos = 'adv';
        posNameCz = 'Příslovce způsobu';
        badgeClass = 'bg-emerald-100 text-emerald-800 border-emerald-200';
        explanationCz = 'Slovo končí na příponu -ly (příslovce způsobu - jak?)';
      } else if (
        lowerWord.endsWith('ed') || 
        lowerWord.endsWith('ing') || 
        ['is', 'are', 'was', 'were', 'be', 'been', 'have', 'has', 'had', 'do', 'does', 'did', 'will', 'can', 'could', 'would', 'should', 'must', 'play', 'walk', 'run', 'eat', 'see', 'make', 'like', 'live', 'work'].includes(lowerWord)
      ) {
        pos = 'verb';
        posNameCz = 'Sloveso';
        badgeClass = 'bg-rose-100 text-rose-800 border-rose-200';
        explanationCz = 'Vyjadřuje děj, činnost nebo stav.';
      } else if (
        lowerWord.endsWith('ful') || 
        lowerWord.endsWith('ous') || 
        lowerWord.endsWith('ive') || 
        lowerWord.endsWith('able') || 
        lowerWord.endsWith('ic') ||
        ['big', 'small', 'red', 'green', 'blue', 'good', 'bad', 'hot', 'cold', 'new', 'old', 'happy', 'sad', 'easy', 'difficult', 'fast', 'slow'].includes(lowerWord)
      ) {
        pos = 'adj';
        posNameCz = 'Přídavné jméno';
        badgeClass = 'bg-amber-100 text-amber-800 border-amber-200';
        explanationCz = 'Popisuje vlastnost podstatného jména (jaký?).';
      }
    }

    posSummaryCounts[pos] = (posSummaryCounts[pos] || 0) + 1;

    words.push({
      raw: token,
      wordClean,
      punctuationAfter,
      pos,
      posNameCz,
      badgeClass,
      explanationCz
    });
  });

  // Basic SVOMPT order inspector heuristic
  const hasVerb = words.some(w => w.pos === 'verb');
  const hasNounOrPronoun = words.some(w => w.pos === 'noun' || w.pos === 'pron');

  let status: 'good' | 'warning' | 'info' = 'good';
  let messageCz = 'Tato věta má pěknou stavbu. Všimněte si pořadí slov.';

  if (!hasVerb && words.length > 2) {
    status = 'warning';
    messageCz = 'Upozornění: Každá anglická větě by měla obsahovat sloveso (Verb)!';
  } else if (hasVerb && hasNounOrPronoun) {
    messageCz = 'Věta obsahuje Podmět (Subject) i Sloveso (Verb). Zkontrolujte pozici příslovcí času na konci věty (Time).';
  }

  return {
    sentence: trimmed,
    words,
    svomptFeedback: {
      status,
      messageCz,
      detectedOrder: ['S', 'V', 'O', 'M', 'P', 'T']
    },
    posSummaryCounts
  };
};
