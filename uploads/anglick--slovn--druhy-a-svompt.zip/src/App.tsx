/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Header, TabType } from './components/Header';
import { TheorySection } from './components/TheorySection';
import { QuizSection } from './components/QuizSection';
import { SvomptBuilderSection } from './components/SvomptBuilderSection';
import { FlashcardsSection } from './components/FlashcardsSection';
import { QrCodeModal } from './components/QrCodeModal';
import { Footer } from './components/Footer';
import { UserStats } from './types';

const STATS_KEY = 'en_grammar_svompt_stats';

export default function App() {
  const [activeTab, setActiveTab] = useState<TabType>('theory');
  const [soundEnabled, setSoundEnabled] = useState<boolean>(true);
  const [isQrOpen, setIsQrOpen] = useState<boolean>(false);
  const [appUrl, setAppUrl] = useState<string>('');

  const [stats, setStats] = useState<UserStats>(() => {
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem(STATS_KEY);
      if (saved) {
        try {
          return JSON.parse(saved);
        } catch (e) {
          // fallback
        }
      }
    }
    return {
      quizzesCompleted: 0,
      totalQuestionsAnswered: 0,
      correctAnswers: 0,
      puzzlesSolved: 0,
      currentStreak: 1,
      lastActiveDate: new Date().toISOString()
    };
  });

  useEffect(() => {
    if (typeof window !== 'undefined') {
      localStorage.setItem(STATS_KEY, JSON.stringify(stats));
      setAppUrl(window.location.href);
    }
  }, [stats]);

  return (
    <div className="min-h-screen bg-slate-100 text-slate-800 flex flex-col font-sans antialiased selection:bg-indigo-500 selection:text-white">
      
      {/* Navigation Header */}
      <Header
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        stats={stats}
        onOpenQr={() => setIsQrOpen(true)}
        soundEnabled={soundEnabled}
        setSoundEnabled={setSoundEnabled}
      />

      {/* Main Tab Content */}
      <main className="flex-grow max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8 w-full">
        {activeTab === 'theory' && (
          <TheorySection soundEnabled={soundEnabled} />
        )}

        {activeTab === 'quiz' && (
          <QuizSection stats={stats} setStats={setStats} soundEnabled={soundEnabled} />
        )}

        {activeTab === 'builder' && (
          <SvomptBuilderSection stats={stats} setStats={setStats} soundEnabled={soundEnabled} />
        )}

        {activeTab === 'flashcards' && (
          <FlashcardsSection soundEnabled={soundEnabled} />
        )}
      </main>

      {/* Footer */}
      <Footer />

      {/* QR Code Modal for Mobile sharing */}
      <QrCodeModal
        isOpen={isQrOpen}
        onClose={() => setIsQrOpen(false)}
        appUrl={appUrl}
      />

    </div>
  );
}
