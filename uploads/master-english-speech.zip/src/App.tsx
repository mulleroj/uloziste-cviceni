import React, { useState, useEffect } from 'react';
import { BookOpen, PenTool, QrCode, CheckCircle, XCircle, RefreshCw, ChevronRight, X, Info, Volume2, Flame, Trophy, Sparkles, Lock, ShieldCheck, HelpCircle } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import confetti from 'canvas-confetti';

// --- TYPY ---
interface Sentence {
  d: string;
  c: string;
  w1: string;
  w2: string;
  explanation?: string;
}

interface QuestionOption {
  text: string;
  isCorrect: boolean;
}

interface Question {
  direct: string;
  options: QuestionOption[];
  correctText: string;
  explanation: string;
}

interface HistoryItem {
  direct: string;
  userAnswer: string;
  isCorrect: boolean;
  correctAnswer: string;
  explanation: string;
}

interface BadgeDef {
  id: string;
  targetStreak: number;
  title: string;
  subtitle: string;
  description: string;
  icon: string;
  badgeBg: string;
  borderColor: string;
  textColor: string;
  accentColor: string;
}

const BADGES_LIST: BadgeDef[] = [
  {
    id: 'streak_5',
    targetStreak: 5,
    title: '5 v řadě bez chyby',
    subtitle: 'Rychlý start',
    description: 'Správně odpovězeno na 5 vět za sebou bez jediného pochybení.',
    icon: '🥉',
    badgeBg: 'bg-gradient-to-br from-amber-950/70 via-slate-900 to-slate-950 border-amber-500/40 text-amber-200',
    borderColor: 'border-amber-500/50 shadow-amber-500/10',
    textColor: 'text-amber-400',
    accentColor: 'bg-amber-500'
  },
  {
    id: 'streak_10',
    targetStreak: 10,
    title: '10 v řadě bez chyby',
    subtitle: 'Gramatický Expert',
    description: 'Správně odpovězeno na 10 vět za sebou bez jediného pochybení.',
    icon: '🥈',
    badgeBg: 'bg-gradient-to-br from-cyan-950/70 via-slate-900 to-slate-950 border-cyan-400/40 text-cyan-200',
    borderColor: 'border-cyan-400/50 shadow-cyan-500/10',
    textColor: 'text-cyan-400',
    accentColor: 'bg-cyan-400'
  },
  {
    id: 'streak_20',
    targetStreak: 20,
    title: '20 v řadě bez chyby',
    subtitle: 'Neporazitelná Legenda',
    description: 'Správně odpovězeno na 20 vět za sebou bez jediného pochybení.',
    icon: '🥇',
    badgeBg: 'bg-gradient-to-br from-yellow-950/70 via-amber-950/40 to-slate-950 border-yellow-400/50 text-yellow-200',
    borderColor: 'border-yellow-400/60 shadow-yellow-500/20',
    textColor: 'text-yellow-400',
    accentColor: 'bg-yellow-400'
  }
];

function getSentenceExplanation(sentence: Sentence): string {
  if (sentence.explanation) {
    return sentence.explanation;
  }
  const d = sentence.d;

  // Všeobecné pravdy a přítomná uvozovací slovesa
  if (d.includes("Earth") || d.includes("Delhi")) {
    return "Všeobecná pravdivá fakta a geografické poučky nemění v nepřímé řeči minulý čas (zůstávají v přítomném čase prostém).";
  }
  if (d.startsWith("Riya says")) {
    return "Pokud je uvozovací sloveso v přítomném čase (says), čas ve vedlejší větě se v nepřímé řeči POSOUVAT NEMĚNÍ.";
  }

  // Rozkazy a žádosti
  if (/Sit down|Do not|don't|Open|Shout|medicine|salt|Stop|forget|Be quiet/i.test(d) && !d.includes("?")) {
    return "Rozkazy a žádosti se v nepřímé řeči tvoří pomocí infinitivu s 'to' (to do / not to do) a uvozovacího slovesa (tell, order, ask, advise, remind).";
  }

  // Zjišťovací otázky (Yes/No questions)
  if (d.includes("?") && /Are|Do|Is|Have|Can|Did|Will|Does|Was/i.test(d)) {
    return "Zjišťovací otázky (Yes/No) připojujeme v nepřímé řeči spojkou 'if' (či 'whether'). Tázací slovosled se mění na oznamovací (podmět před přísudkem).";
  }

  // Doplňovací otázky (Wh- questions)
  if (d.includes("?") && /Where|Why|When|How|What|Who|Which/i.test(d)) {
    return "Doplňovací otázky (Wh-) zachovávají tázací slovo (where, why, what...), ale mění tázací slovosled na oznamovací větu a posouvají gramatický čas o stupeň do minulosti.";
  }

  // Změny času, místa a ukazovacích zájmen
  if (/yesterday|today|tomorrow|here|now|this|these|tonight|ago/i.test(d)) {
    return "V nepřímé řeči dochází k posunu časových údajů a ukazovacích zájmen: yesterday -> the previous day, today -> that day, tomorrow -> the next day, now -> then, here -> there, this -> that.";
  }

  // Modální slovesa
  if (/will|can|may|shall/i.test(d)) {
    return "Modální slovesa podléhají posunu časů: will -> would, can -> could, may -> might. Osobní a přivlastňovací zájmena se upravují podle osoby mluvčího.";
  }

  // Minulý prostý a průběhový -> Předminulý
  if (/bought|went|rained|didn't|sleeping|watching|wrote|broke|drove|played|found|saw|met/i.test(d)) {
    return "Minulý čas prostý (Past Simple) i průběhový se v nepřímé řeči posouvá do předminulého času (Past Perfect: bought -> had bought, saw -> had seen).";
  }

  // Přítomný průběhový a předpřítomný -> Minulý průběhový / Předminulý
  if (/studying|eating|raining|finished|seen|done|won|reading|coming|lost/i.test(d)) {
    return "Přítomný průběhový čas se mění na minulý průběhový (is studying -> was studying) a předpřítomný čas (Present Perfect) na předminulý (have finished -> had finished).";
  }

  // Přítomný prostý -> Minulý prostý (default fallback)
  return "Při převodu z přítomného prostého času (Present Simple) se gramatický čas posouvá o stupeň do minulosti na minulý prostý (Past Simple: am -> was, work -> worked) a dochází k úpravě osobních zájmen.";
}

function BadgesSummaryCard({ maxStreak, unlockedBadges }: { maxStreak: number; unlockedBadges: string[] }) {
  return (
    <div className="bg-slate-900 border border-slate-800 rounded-2xl sm:rounded-3xl p-5 sm:p-7 mb-8 shadow-xl">
      <div className="flex items-center justify-between mb-5 flex-wrap gap-3 border-b border-slate-800/80 pb-4">
        <div>
          <h3 className="font-bold text-white text-lg sm:text-xl flex items-center gap-2">
            <Trophy size={22} className="text-yellow-400" /> Získané odznaky a úspěchy
          </h3>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Odznaky se odemknou za 5, 10 nebo 20 správných odpovědí v řadě bez jediné chyby.
          </p>
        </div>
        <div className="flex items-center gap-2 flex-wrap">
          <div className="flex items-center gap-1.5 px-3 py-1.5 bg-amber-500/10 border border-amber-500/20 rounded-full text-xs font-bold text-amber-300">
            <Flame size={15} className="text-amber-400 animate-pulse" />
            <span>Nejdelší série: {maxStreak}</span>
          </div>
          <div className="flex items-center gap-1.5 px-3 py-1.5 bg-indigo-500/10 border border-indigo-500/20 rounded-full text-xs font-bold text-indigo-300">
            <ShieldCheck size={15} className="text-indigo-400" />
            <span>Odemčeno: {unlockedBadges.length} / 3</span>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        {BADGES_LIST.map((badge) => {
          const isUnlocked = unlockedBadges.includes(badge.id) || maxStreak >= badge.targetStreak;
          const currentProgress = Math.min(maxStreak, badge.targetStreak);
          const progressPercent = Math.min(100, Math.round((currentProgress / badge.targetStreak) * 100));

          return (
            <div
              key={badge.id}
              className={`relative rounded-2xl p-4 sm:p-5 border transition-all duration-300 flex flex-col justify-between overflow-hidden ${
                isUnlocked
                  ? `${badge.badgeBg} ${badge.borderColor} shadow-lg`
                  : 'bg-slate-950/50 border-slate-800/80 text-slate-400'
              }`}
            >
              {isUnlocked ? (
                <div className="absolute top-2.5 right-2.5 flex items-center gap-1 px-2 py-0.5 rounded-full bg-emerald-500/20 border border-emerald-500/40 text-[10px] font-bold text-emerald-300 shadow-sm">
                  <Sparkles size={11} className="animate-spin" /> Odemčeno
                </div>
              ) : (
                <div className="absolute top-2.5 right-2.5 flex items-center gap-1 px-2 py-0.5 rounded-full bg-slate-800/80 border border-slate-700/80 text-[10px] font-medium text-slate-400">
                  <Lock size={11} /> Zamčeno
                </div>
              )}

              <div>
                <div className="flex items-center gap-3 mb-3">
                  <div className={`w-12 h-12 rounded-2xl flex items-center justify-center text-2xl shadow-inner border ${
                    isUnlocked ? 'bg-slate-900/80 border-slate-700/80' : 'bg-slate-900/40 border-slate-800 opacity-60'
                  }`}>
                    {badge.icon}
                  </div>
                  <div>
                    <span className="text-[10px] font-bold tracking-wider uppercase block text-slate-400">
                      {badge.subtitle}
                    </span>
                    <h4 className={`font-bold text-sm sm:text-base leading-tight ${isUnlocked ? badge.textColor : 'text-slate-300'}`}>
                      {badge.title}
                    </h4>
                  </div>
                </div>

                <p className="text-xs text-slate-400 leading-relaxed mb-4">
                  {badge.description}
                </p>
              </div>

              <div>
                <div className="flex justify-between items-center text-[11px] font-medium mb-1.5">
                  <span className="text-slate-400">Pokrok série</span>
                  <span className={`font-mono font-bold ${isUnlocked ? badge.textColor : 'text-slate-400'}`}>
                    {currentProgress} / {badge.targetStreak}
                  </span>
                </div>
                <div className="h-2 w-full bg-slate-950 rounded-full overflow-hidden border border-slate-800/80">
                  <div
                    className={`h-full transition-all duration-500 rounded-full ${
                      isUnlocked ? badge.accentColor : 'bg-slate-700'
                    }`}
                    style={{ width: `${progressPercent}%` }}
                  ></div>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

// --- DATABÁZE 80 VĚT PRO PROCVIČOVÁNÍ ---
// d = direct (přímá), c = correct (správná nepřímá), w1 = wrong 1 (špatná 1), w2 = wrong 2 (špatná 2)
const sentencesDb: Sentence[] = [
  // Přítomný prostý -> Minulý prostý (10)
  { d: 'He said, "I am happy."', c: 'He said that he was happy.', w1: 'He said that he is happy.', w2: 'He said that I was happy.' },
  { d: 'She said, "I work hard."', c: 'She said that she worked hard.', w1: 'She said that she works hard.', w2: 'She said that she had worked hard.' },
  { d: 'They said, "We play football."', c: 'They said that they played football.', w1: 'They said that they play football.', w2: 'They said that we played football.' },
  { d: 'Tom said, "I like apples."', c: 'Tom said that he liked apples.', w1: 'Tom said that he likes apples.', w2: 'Tom said that he had liked apples.' },
  { d: 'Mary said, "I don\'t know."', c: 'Mary said that she didn\'t know.', w1: 'Mary said that she doesn\'t know.', w2: 'Mary said if she didn\'t know.' },
  { d: 'He said, "It is cold."', c: 'He said that it was cold.', w1: 'He said that it is cold.', w2: 'He said that it had been cold.' },
  { d: 'She said, "I need help."', c: 'She said that she needed help.', w1: 'She said that she needs help.', w2: 'She told that she needed help.' },
  { d: 'John said, "I have a dog."', c: 'John said that he had a dog.', w1: 'John said that he has a dog.', w2: 'John said that I had a dog.' },
  { d: 'They said, "We want to go."', c: 'They said that they wanted to go.', w1: 'They said that they want to go.', w2: 'They said that they had wanted to go.' },
  { d: 'Anna said, "I hate spiders."', c: 'Anna said that she hated spiders.', w1: 'Anna said that she hates spiders.', w2: 'Anna said that she had hated spiders.' },

  // Přítomný průběhový / Předpřítomný -> Minulý průběhový / Předminulý (10)
  { d: 'She said, "I am studying."', c: 'She said that she was studying.', w1: 'She said that she is studying.', w2: 'She said that she had been studying.' },
  { d: 'He said, "We are eating."', c: 'He said that they were eating.', w1: 'He said that we were eating.', w2: 'He said that they are eating.' },
  { d: 'They said, "It is raining."', c: 'They said that it was raining.', w1: 'They said that it is raining.', w2: 'They said that it had been raining.' },
  { d: 'Riya said, "I have finished."', c: 'Riya said that she had finished.', w1: 'Riya said that she has finished.', w2: 'Riya said that she finished.' },
  { d: 'He said, "I have seen this film."', c: 'He said that he had seen that film.', w1: 'He said that he saw this film.', w2: 'He said that he has seen that film.' },
  { d: 'She said, "I haven\'t done it."', c: 'She said that she hadn\'t done it.', w1: 'She said that she hasn\'t done it.', w2: 'She said that she didn\'t do it.' },
  { d: 'Tom said, "We have won!"', c: 'Tom said that they had won.', w1: 'Tom said that they have won.', w2: 'Tom said that we had won.' },
  { d: 'Mary said, "I am reading a book."', c: 'Mary said that she was reading a book.', w1: 'Mary said that she is reading a book.', w2: 'Mary said that she reads a book.' },
  { d: 'He said, "They are coming."', c: 'He said that they were coming.', w1: 'He said that they are coming.', w2: 'He said that they had come.' },
  { d: 'She said, "I have lost my keys."', c: 'She said that she had lost her keys.', w1: 'She said that she has lost her keys.', w2: 'She said that she had lost my keys.' },

  // Minulý prostý / průběhový -> Předminulý (10)
  { d: 'She said, "I bought a book."', c: 'She said that she had bought a book.', w1: 'She said that she bought a book.', w2: 'She said that she has bought a book.' },
  { d: 'He said, "We went to Paris."', c: 'He said that they had gone to Paris.', w1: 'He said that they went to Paris.', w2: 'He said that we had gone to Paris.' },
  { d: 'They said, "It rained yesterday."', c: 'They said that it had rained the previous day.', w1: 'They said that it rained the previous day.', w2: 'They said that it had rained yesterday.' },
  { d: 'Anna said, "I didn\'t see him."', c: 'Anna said that she hadn\'t seen him.', w1: 'Anna said that she didn\'t see him.', w2: 'Anna said that she hasn\'t seen him.' },
  { d: 'He said, "I was sleeping."', c: 'He said that he had been sleeping.', w1: 'He said that he was sleeping.', w2: 'He said that he is sleeping.' },
  { d: 'She said, "We were watching TV."', c: 'She said that they had been watching TV.', w1: 'She said that they were watching TV.', w2: 'She said that we had been watching TV.' },
  { d: 'Tom said, "I broke the window."', c: 'Tom said that he had broken the window.', w1: 'Tom said that he broke the window.', w2: 'Tom said that he breaks the window.' },
  { d: 'Mary said, "I drove to work."', c: 'Mary said that she had driven to work.', w1: 'Mary said that she drove to work.', w2: 'Mary said that she has driven to work.' },
  { d: 'He said, "They played well."', c: 'He said that they had played well.', w1: 'He said that they played well.', w2: 'He said that they have played well.' },
  { d: 'She said, "I found a wallet."', c: 'She said that she had found a wallet.', w1: 'She said that she found a wallet.', w2: 'She said that she finds a wallet.' },

  // Modální slovesa (will, can, may) (10)
  { d: 'She said, "I will help you."', c: 'She said that she would help me.', w1: 'She said that she will help me.', w2: 'She said that she would help you.' },
  { d: 'He said, "I can swim."', c: 'He said that he could swim.', w1: 'He said that he can swim.', w2: 'He said that he would swim.' },
  { d: 'They said, "It may rain."', c: 'They said that it might rain.', w1: 'They said that it may rain.', w2: 'They said that it must rain.' },
  { d: 'Tom said, "I will call tomorrow."', c: 'Tom said that he would call the next day.', w1: 'Tom said that he will call tomorrow.', w2: 'Tom said that he would call tomorrow.' },
  { d: 'Mary said, "I can\'t come."', c: 'Mary said that she couldn\'t come.', w1: 'Mary said that she can\'t come.', w2: 'Mary said that she wouldn\'t come.' },
  { d: 'He said, "We will see."', c: 'He said that they would see.', w1: 'He said that we would see.', w2: 'He said that they will see.' },
  { d: 'Anna said, "I may go to the party."', c: 'Anna said that she might go to the party.', w1: 'Anna said that she may go to the party.', w2: 'Anna said that she can go to the party.' },
  { d: 'He said, "I shall do it."', c: 'He said that he would do it.', w1: 'He said that he shall do it.', w2: 'He said that he should do it.' },
  { d: 'She said, "You can stay here."', c: 'She said that I could stay there.', w1: 'She said that I can stay there.', w2: 'She said that I could stay here.' },
  { d: 'They said, "We will buy this car."', c: 'They said that they would buy that car.', w1: 'They said that they will buy this car.', w2: 'They said that they would buy this car.' },

  // Otázky - Zjišťovací (Yes/No) (10)
  { d: 'Riya asked, "Are you ready?"', c: 'Riya asked if I was ready.', w1: 'Riya asked that I was ready.', w2: 'Riya asked was I ready.' },
  { d: 'He asked, "Do you speak English?"', c: 'He asked if I spoke English.', w1: 'He asked if I speak English.', w2: 'He asked do I speak English.' },
  { d: 'She asked, "Is it raining?"', c: 'She asked if it was raining.', w1: 'She asked if it is raining.', w2: 'She asked that it was raining.' },
  { d: 'Tom asked, "Have you seen Mary?"', c: 'Tom asked if I had seen Mary.', w1: 'Tom asked if I saw Mary.', w2: 'Tom asked have I seen Mary.' },
  { d: 'They asked, "Can we leave?"', c: 'They asked if they could leave.', w1: 'They asked if we could leave.', w2: 'They asked that they could leave.' },
  { d: 'Anna asked, "Did you call me?"', c: 'Anna asked if I had called her.', w1: 'Anna asked if I called her.', w2: 'Anna asked if I had called me.' },
  { d: 'He asked, "Will you help us?"', c: 'He asked if I would help them.', w1: 'He asked if I will help them.', w2: 'He asked if I would help us.' },
  { d: 'She asked, "Are they coming?"', c: 'She asked if they were coming.', w1: 'She asked if they are coming.', w2: 'She asked were they coming.' },
  { d: 'John asked, "Does she like coffee?"', c: 'John asked if she liked coffee.', w1: 'John asked if she likes coffee.', w2: 'John asked does she like coffee.' },
  { d: 'Mary asked, "Was he at home?"', c: 'Mary asked if he had been at home.', w1: 'Mary asked if he was at home.', w2: 'Mary asked that he had been at home.' },

  // Otázky - Doplňovací (Wh-) (10)
  { d: 'Riya asked, "Where do you live?"', c: 'Riya asked where I lived.', w1: 'Riya asked where did I live.', w2: 'Riya asked where I live.' },
  { d: 'He asked, "Why are you late?"', c: 'He asked why I was late.', w1: 'He asked why was I late.', w2: 'He asked why am I late.' },
  { d: 'She asked, "When will you return?"', c: 'She asked when I would return.', w1: 'She asked when will I return.', w2: 'She asked when I will return.' },
  { d: 'Tom asked, "How did you do this?"', c: 'Tom asked how I had done that.', w1: 'Tom asked how did I do that.', w2: 'Tom asked how I had done this.' },
  { d: 'They asked, "What is your name?"', c: 'They asked what my name was.', w1: 'They asked what was my name.', w2: 'They asked what is my name.' },
  { d: 'Anna asked, "Who is that man?"', c: 'Anna asked who that man was.', w1: 'Anna asked who was that man.', w2: 'Anna asked who that man is.' },
  { d: 'He asked, "Where are we going?"', c: 'He asked where they were going.', w1: 'He asked where were they going.', w2: 'He asked where we were going.' },
  { d: 'She asked, "What time does it start?"', c: 'She asked what time it started.', w1: 'She asked what time does it start.', w2: 'She asked what time it starts.' },
  { d: 'John asked, "How much does it cost?"', c: 'John asked how much it cost.', w1: 'John asked how much did it cost.', w2: 'John asked how much does it cost.' },
  { d: 'Mary asked, "Which one do you want?"', c: 'Mary asked which one I wanted.', w1: 'Mary asked which one did I want.', w2: 'Mary asked which one I want.' },

  // Rozkazy a žádosti (10)
  { d: 'Teacher said, "Sit down."', c: 'Teacher told the students to sit down.', w1: 'Teacher said to sit down.', w2: 'Teacher told the students sit down.' },
  { d: 'Mother said, "Do not waste time."', c: 'Mother told me not to waste time.', w1: 'Mother told me to not waste time.', w2: 'Mother said not to waste time.' },
  { d: 'Riya said, "Please help me."', c: 'Riya asked me to help her.', w1: 'Riya asked me to help me.', w2: 'Riya said to please help her.' },
  { d: 'He said, "Open the door."', c: 'He ordered me to open the door.', w1: 'He ordered me open the door.', w2: 'He said to opened the door.' },
  { d: 'She said, "Don\'t shout!"', c: 'She told us not to shout.', w1: 'She told us don\'t shout.', w2: 'She said us not to shout.' },
  { d: 'Doctor said, "Take this medicine."', c: 'Doctor advised me to take that medicine.', w1: 'Doctor advised me to take this medicine.', w2: 'Doctor advised me take that medicine.' },
  { d: 'He said, "Please pass the salt."', c: 'He asked me to pass the salt.', w1: 'He asked me pass the salt.', w2: 'He said to passed the salt.' },
  { d: 'The officer said, "Stop the car!"', c: 'The officer ordered him to stop the car.', w1: 'The officer told stop the car.', w2: 'The officer ordered him stop the car.' },
  { d: 'She said, "Don\'t forget your keys."', c: 'She reminded me not to forget my keys.', w1: 'She reminded me don\'t forget my keys.', w2: 'She reminded me to not forget my keys.' },
  { d: 'Tom said, "Be quiet."', c: 'Tom told them to be quiet.', w1: 'Tom told them be quiet.', w2: 'Tom told them to are quiet.' },

  // Čas, Místo a Výjimky (10)
  { d: 'Teacher said, "The Earth moves around the Sun."', c: 'Teacher said that the Earth moves around the Sun.', w1: 'Teacher said that the Earth moved around the Sun.', w2: 'Teacher told that the Earth moves around the Sun.' },
  { d: 'Riya says, "I am busy."', c: 'Riya says that she is busy.', w1: 'Riya says that she was busy.', w2: 'Riya said that she is busy.' },
  { d: 'Aman said, "Delhi is the capital of India."', c: 'Aman said that Delhi is the capital of India.', w1: 'Aman said that Delhi was the capital of India.', w2: 'Aman said if Delhi is the capital.' },
  { d: 'He said, "I will come here tomorrow."', c: 'He said that he would go there the next day.', w1: 'He said that he would come here tomorrow.', w2: 'He said that he will go there the next day.' },
  { d: 'She said, "I saw him yesterday."', c: 'She said that she had seen him the previous day.', w1: 'She said that she saw him yesterday.', w2: 'She said that she had seen him yesterday.' },
  { d: 'Tom said, "I am leaving now."', c: 'Tom said that he was leaving then.', w1: 'Tom said that he was leaving now.', w2: 'Tom said that he is leaving then.' },
  { d: 'They said, "We are arriving today."', c: 'They said that they were arriving that day.', w1: 'They said that they were arriving today.', w2: 'They said that they are arriving that day.' },
  { d: 'He said, "I bought these books last week."', c: 'He said that he had bought those books the previous week.', w1: 'He said that he had bought these books the previous week.', w2: 'He said that he bought those books last week.' },
  { d: 'She said, "I will do it tonight."', c: 'She said that she would do it that night.', w1: 'She said that she will do it tonight.', w2: 'She said that she would do it tonight.' },
  { d: 'Anna said, "I met him a year ago."', c: 'Anna said that she had met him a year before.', w1: 'Anna said that she met him a year ago.', w2: 'Anna said that she had met him a year ago.' }
];

export default function App() {
  const [activeTab, setActiveTab] = useState<'theory' | 'practice'>('theory');
  const [showQR, setShowQR] = useState(false);

  return (
    <div className="min-h-screen bg-slate-950 text-slate-200 font-sans selection:bg-indigo-500 selection:text-white">
      
      {/* HLAVIČKA */}
      <header className="bg-slate-900/80 backdrop-blur-md border-b border-slate-800/80 text-white sticky top-0 z-30 shadow-xl shadow-slate-950/50">
        <div className="max-w-6xl mx-auto px-4 py-3 sm:py-4 flex flex-col sm:flex-row justify-between items-center gap-3 sm:gap-4">
          <div className="flex items-center gap-3 w-full sm:w-auto justify-between sm:justify-start">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-indigo-600 rounded-xl flex items-center justify-center text-white shadow-lg shadow-indigo-500/25 border border-indigo-400/30 shrink-0">
                <BookOpen size={22} />
              </div>
              <div>
                <h1 className="text-lg sm:text-2xl font-bold leading-tight tracking-tight text-white flex items-center gap-2">
                  Master English Speech
                </h1>
                <p className="text-slate-400 text-xs sm:text-sm">Přímá a nepřímá řeč jednoduše</p>
              </div>
            </div>

            <button 
              id="share-qr-mobile-btn"
              onClick={() => setShowQR(true)}
              className="sm:hidden p-2.5 rounded-xl bg-slate-800/80 text-slate-300 hover:text-white border border-slate-700/60 cursor-pointer min-h-[44px] min-w-[44px] flex items-center justify-center"
              title="Sdílet aplikaci"
            >
              <QrCode size={20} />
            </button>
          </div>
          
          <div className="flex items-center gap-1.5 bg-slate-950/70 p-1.5 rounded-2xl border border-slate-800 w-full sm:w-auto">
            <button 
              id="tab-theory-btn"
              onClick={() => setActiveTab('theory')}
              className={`flex items-center justify-center gap-2 px-3.5 sm:px-4 py-2.5 sm:py-2 rounded-xl transition-all text-xs sm:text-sm font-medium cursor-pointer flex-1 sm:flex-initial min-h-[44px] ${
                activeTab === 'theory' 
                  ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/30 border border-indigo-400/30 font-semibold' 
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
              }`}
            >
              <Info size={18} /> Teorie
            </button>
            <button 
              id="tab-practice-btn"
              onClick={() => setActiveTab('practice')}
              className={`flex items-center justify-center gap-2 px-3.5 sm:px-4 py-2.5 sm:py-2 rounded-xl transition-all text-xs sm:text-sm font-medium cursor-pointer flex-1 sm:flex-initial min-h-[44px] ${
                activeTab === 'practice' 
                  ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/30 border border-indigo-400/30 font-semibold' 
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
              }`}
            >
              <PenTool size={18} /> Procvičování
            </button>
            <button 
              id="share-qr-btn"
              onClick={() => setShowQR(true)}
              className="hidden sm:flex items-center gap-2 px-3 py-2 rounded-xl transition-all text-sm font-medium text-slate-400 hover:text-slate-200 hover:bg-slate-800/60 ml-1 border-l border-slate-800/80 cursor-pointer min-h-[44px]"
              title="Sdílet aplikaci"
            >
              <QrCode size={18} /> <span>Sdílet</span>
            </button>
          </div>
        </div>
      </header>

      {/* HLAVNÍ OBSAH */}
      <main className="max-w-6xl mx-auto px-3 sm:px-4 md:px-6 py-6 sm:py-8">
        {activeTab === 'theory' ? <TheorySection /> : <PracticeSection />}
      </main>

      {/* QR MODAL */}
      {showQR && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-md p-4 animate-in fade-in duration-200">
          <div className="bg-slate-900 border border-slate-800 text-slate-200 rounded-3xl p-6 sm:p-8 max-w-sm w-full shadow-2xl relative animate-in zoom-in-95 duration-200">
            <button 
              id="close-qr-btn"
              onClick={() => setShowQR(false)}
              className="absolute top-4 right-4 text-slate-400 hover:text-slate-200 transition-colors cursor-pointer bg-slate-800/60 p-2 rounded-full border border-slate-700/50 min-h-[44px] min-w-[44px] flex items-center justify-center"
            >
              <X size={20} />
            </button>
            
            <div className="text-center mb-6 pt-2">
              <div className="w-16 h-16 bg-indigo-600/20 border border-indigo-500/30 rounded-2xl flex items-center justify-center text-indigo-400 mx-auto mb-4 shadow-lg shadow-indigo-500/10">
                <QrCode size={32} />
              </div>
              <h2 className="text-2xl font-bold text-white tracking-tight">Sdílet aplikaci</h2>
              <p className="text-slate-400 text-xs sm:text-sm mt-2 leading-relaxed">Naskenujte QR kód fotoaparátem vašeho telefonu a otevřete si tuto aplikaci kdekoli.</p>
            </div>
            
            <div className="bg-white p-4 rounded-2xl flex justify-center border border-slate-700 mb-6 shadow-inner">
              <img 
                src={`https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=${encodeURIComponent(window.location.href)}&margin=10`} 
                alt="QR Kód pro sdílení" 
                className="w-44 h-44 sm:w-48 sm:h-48 rounded-lg"
              />
            </div>
            
            <button 
              id="close-qr-modal-btn"
              onClick={() => setShowQR(false)}
              className="w-full bg-indigo-600 hover:bg-indigo-500 text-white font-semibold py-3.5 rounded-xl transition-all cursor-pointer shadow-lg shadow-indigo-500/20 border border-indigo-400/30 min-h-[44px] flex items-center justify-center"
            >
              Zavřít
            </button>
          </div>
        </div>
      )}

    </div>
  );
}

// --- TEORIE KOMPONENTA ---
function TheorySection() {
  const [activeTopic, setActiveTopic] = useState<string>('basics');

  const topics = [
    { id: 'basics', title: 'Základní rozdíly', icon: '📝' },
    { id: 'statements', title: 'Oznamovací věty (Statements)', icon: '💬' },
    { id: 'tenses', title: 'Změna časů (Tense Changes)', icon: '⏳' },
    { id: 'pronouns', title: 'Změna zájmen (Pronouns)', icon: '👥' },
    { id: 'timeplace', title: 'Čas a Místo (Time & Place)', icon: '📍' },
    { id: 'questions', title: 'Otázky (Questions)', icon: '❓' },
    { id: 'commands', title: 'Rozkazy (Commands)', icon: '❗' },
    { id: 'exceptions', title: 'Výjimky (Exceptions)', icon: '✨' },
  ];

  return (
    <div className="flex flex-col md:flex-row gap-6">
      {/* Menu Teorie - Bento Navigation Card */}
      <div className="w-full md:w-1/3 lg:w-1/4 shrink-0">
        <div className="bg-slate-900/90 border border-slate-800 rounded-2xl md:rounded-3xl overflow-hidden sticky top-20 sm:top-24 shadow-2xl z-20">
          <div className="p-3 sm:p-4 bg-slate-950/60 border-b border-slate-800 flex items-center justify-between">
            <h2 className="font-bold text-slate-300 flex items-center gap-2 text-xs uppercase tracking-wider">
              <BookOpen size={16} className="text-indigo-400" /> Témata
            </h2>
            <span className="text-[10px] text-slate-500 md:hidden font-mono">Posuňte ➔</span>
          </div>
          <div className="flex md:flex-col p-2 md:p-2.5 gap-1.5 overflow-x-auto no-scrollbar scroll-smooth">
            {topics.map(topic => (
              <button
                key={topic.id}
                id={`topic-btn-${topic.id}`}
                onClick={() => setActiveTopic(topic.id)}
                className={`flex items-center gap-2.5 px-3.5 sm:px-4 py-2.5 sm:py-3 rounded-xl sm:rounded-2xl text-left transition-all cursor-pointer shrink-0 md:shrink-0 whitespace-nowrap md:whitespace-normal min-h-[44px] ${
                  activeTopic === topic.id 
                    ? 'bg-indigo-600/20 text-indigo-300 font-semibold border border-indigo-500/40 shadow-sm' 
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50 border border-transparent'
                }`}
              >
                <span className="text-lg sm:text-xl">{topic.icon}</span>
                <span className="text-xs sm:text-sm">{topic.title}</span>
                {activeTopic === topic.id && <ChevronRight size={16} className="ml-auto text-indigo-400 hidden md:block" />}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Obsah Teorie - Bento Content Display Card */}
      <div className="w-full md:w-2/3 lg:w-3/4">
        <div className="bg-slate-900/90 border border-slate-800 rounded-2xl sm:rounded-3xl p-4 sm:p-6 md:p-8 min-h-[450px] shadow-2xl relative overflow-hidden">
          {/* Subtle background glow */}
          <div className="absolute -right-20 -top-20 w-80 h-80 bg-indigo-600/10 rounded-full blur-3xl pointer-events-none"></div>

          {activeTopic === 'basics' && (
            <div className="animate-in fade-in duration-300 relative z-10">
              <h2 className="text-xl sm:text-2xl md:text-3xl font-bold text-white mb-4 sm:mb-6 border-b border-slate-800 pb-3 sm:pb-4 tracking-tight">Úvod a základní rozdíly</h2>
              
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 sm:gap-6 mb-8">
                <div className="bg-slate-950/60 border border-blue-500/30 rounded-2xl p-4 sm:p-6 shadow-lg">
                  <h3 className="font-bold text-blue-400 mb-3 text-base sm:text-lg flex items-center gap-2">
                    <span className="w-2.5 h-2.5 rounded-full bg-blue-500 shrink-0"></span> Direct Speech (Přímá řeč)
                  </h3>
                  <p className="text-slate-300 mb-4 text-xs sm:text-sm leading-relaxed">Přesná slova mluvčího zapsaná v uvozovkách.</p>
                  <div className="bg-slate-900 p-3 sm:p-3.5 rounded-xl border border-blue-500/20 shadow-inner">
                    <p className="font-mono text-xs sm:text-sm text-slate-200">Riya said, <span className="text-blue-400 font-bold">"I am tired."</span></p>
                  </div>
                  <ul className="mt-4 space-y-2 text-xs sm:text-sm text-slate-300">
                    <li className="flex gap-2 items-center">
                      <CheckCircle size={16} className="text-blue-400 shrink-0" /> Používá uvozovky
                    </li>
                    <li className="flex gap-2 items-center">
                      <CheckCircle size={16} className="text-blue-400 shrink-0" /> Obsahuje čárku před promluvou
                    </li>
                    <li className="flex gap-2 items-center">
                      <CheckCircle size={16} className="text-blue-400 shrink-0" /> Zachovává původní slovník
                    </li>
                  </ul>
                </div>
                
                <div className="bg-slate-950/60 border border-emerald-500/30 rounded-2xl p-4 sm:p-6 shadow-lg">
                  <h3 className="font-bold text-emerald-400 mb-3 text-base sm:text-lg flex items-center gap-2">
                    <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 shrink-0"></span> Indirect Speech (Nepřímá řeč)
                  </h3>
                  <p className="text-slate-300 mb-4 text-xs sm:text-sm leading-relaxed">Význam je tlumočen bez použití přesných původních slov.</p>
                  <div className="bg-slate-900 p-3 sm:p-3.5 rounded-xl border border-emerald-500/20 shadow-inner">
                    <p className="font-mono text-xs sm:text-sm text-slate-200">Riya said <span className="text-emerald-400 font-bold">that she was tired.</span></p>
                  </div>
                  <ul className="mt-4 space-y-2 text-xs sm:text-sm text-slate-300">
                    <li className="flex gap-2 items-center">
                      <XCircle size={16} className="text-rose-400 shrink-0" /> Nepoužívá uvozovky ani čárky
                    </li>
                    <li className="flex gap-2 items-center">
                      <RefreshCw size={16} className="text-emerald-400 shrink-0" /> Zájmena a časy se mohou měnit
                    </li>
                    <li className="flex gap-2 items-center">
                      <CheckCircle size={16} className="text-emerald-400 shrink-0" /> Používá spojovací slovo (that, if...)
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          )}

          {activeTopic === 'statements' && (
            <div className="animate-in fade-in duration-300 relative z-10">
              <h2 className="text-xl sm:text-2xl md:text-3xl font-bold text-white mb-4 sm:mb-6 border-b border-slate-800 pb-3 sm:pb-4 tracking-tight">Oznamovací věty (Statements)</h2>
              <p className="text-slate-300 text-xs sm:text-sm mb-6 leading-relaxed">Při převodu oznamovací věty běžně přidáváme spojku <strong className="text-indigo-400">that</strong> (kterou lze v hovoru vynechat) a měníme zájmena a časy.</p>
              
              <div className="bg-slate-950/70 p-4 sm:p-6 rounded-2xl border border-slate-800 mb-6 sm:mb-8 shadow-inner">
                <div className="flex flex-col gap-3 sm:gap-4">
                  <div className="flex flex-col xs:flex-row items-start xs:items-center gap-2 xs:gap-4 bg-slate-900 p-3.5 sm:p-4 rounded-xl border-l-4 border-l-blue-500 border border-slate-800 shadow-sm">
                    <div className="font-bold text-blue-400 w-20 sm:w-24 shrink-0 text-[11px] sm:text-xs uppercase tracking-wider">Direct:</div>
                    <div className="text-sm sm:text-base md:text-lg text-slate-100">Riya said, <strong>"I am happy."</strong></div>
                  </div>
                  <div className="flex items-center justify-center">
                    <div className="bg-slate-800 px-3 py-1 rounded-full text-xs text-indigo-300 font-mono border border-slate-700">PŘEVOD</div>
                  </div>
                  <div className="flex flex-col xs:flex-row items-start xs:items-center gap-2 xs:gap-4 bg-slate-900 p-3.5 sm:p-4 rounded-xl border-l-4 border-l-emerald-500 border border-slate-800 shadow-sm">
                    <div className="font-bold text-emerald-400 w-20 sm:w-24 shrink-0 text-[11px] sm:text-xs uppercase tracking-wider">Indirect:</div>
                    <div className="text-sm sm:text-base md:text-lg text-slate-100">Riya said <strong className="text-emerald-400">that she was happy.</strong></div>
                  </div>
                </div>
              </div>

              <h3 className="font-bold text-lg sm:text-xl mb-4 text-white">SAID vs TOLD</h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="border rounded-2xl p-4 sm:p-5 border-amber-800/40 bg-amber-950/20 text-slate-200">
                  <h4 className="font-bold bg-amber-500/20 text-amber-300 border border-amber-500/30 inline-block px-2.5 py-1 rounded-lg text-xs uppercase tracking-wider mb-2">said + bez předmětu</h4>
                  <p className="text-xs sm:text-sm text-slate-300 mb-3">Pokud neříkáme komu to řekl, použijeme <strong>said</strong>.</p>
                  <p className="font-mono text-xs sm:text-sm bg-slate-950 p-2.5 sm:p-3 rounded-xl border border-slate-800 text-amber-200">Riya said that she was ready.</p>
                </div>
                <div className="border rounded-2xl p-4 sm:p-5 border-indigo-800/40 bg-indigo-950/20 text-slate-200">
                  <h4 className="font-bold bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 inline-block px-2.5 py-1 rounded-lg text-xs uppercase tracking-wider mb-2">told + komu (object)</h4>
                  <p className="text-xs sm:text-sm text-slate-300 mb-3">Pokud zmiňujeme osobu (komu to řekl), použijeme <strong>told</strong>.</p>
                  <p className="font-mono text-xs sm:text-sm bg-slate-950 p-2.5 sm:p-3 rounded-xl border border-slate-800 text-indigo-200">Riya told <strong className="text-indigo-400">me</strong> that she was ready.</p>
                </div>
              </div>
            </div>
          )}

          {activeTopic === 'tenses' && (
            <div className="animate-in fade-in duration-300 relative z-10">
              <h2 className="text-xl sm:text-2xl md:text-3xl font-bold text-white mb-4 sm:mb-6 border-b border-slate-800 pb-3 sm:pb-4 tracking-tight">Změna časů (Backshift of Tenses)</h2>
              <p className="text-slate-300 text-xs sm:text-sm mb-6 leading-relaxed">Pokud je uvozovací sloveso v minulosti (např. "He said..."), čas ve věte se posouvá o jeden krok do minulosti.</p>
              
              <div className="overflow-x-auto custom-scrollbar bg-slate-950/60 border border-slate-800 rounded-2xl shadow-inner">
                <table className="w-full text-left border-collapse min-w-[440px]">
                  <thead>
                    <tr className="bg-slate-800/80 text-slate-300 text-xs uppercase tracking-wider border-b border-slate-800">
                      <th className="p-3 sm:p-3.5 font-bold w-1/2">Direct Speech</th>
                      <th className="p-3 sm:p-3.5 font-bold w-1/2">Indirect Speech</th>
                    </tr>
                  </thead>
                  <tbody className="text-slate-300 divide-y divide-slate-800/60">
                    <tr className="hover:bg-slate-800/30 transition-colors">
                      <td className="p-3 sm:p-3.5 font-mono text-xs sm:text-sm">am / is</td>
                      <td className="p-3 sm:p-3.5 font-mono text-xs sm:text-sm text-indigo-400 font-semibold">was</td>
                    </tr>
                    <tr className="hover:bg-slate-800/30 transition-colors">
                      <td className="p-3 sm:p-3.5 font-mono text-xs sm:text-sm">are</td>
                      <td className="p-3 sm:p-3.5 font-mono text-xs sm:text-sm text-indigo-400 font-semibold">were</td>
                    </tr>
                    <tr className="hover:bg-slate-800/30 transition-colors">
                      <td className="p-3 sm:p-3.5 font-mono text-xs sm:text-sm">V1 (play / plays)</td>
                      <td className="p-3 sm:p-3.5 font-mono text-xs sm:text-sm text-indigo-400 font-semibold">V2 (played)</td>
                    </tr>
                    <tr className="hover:bg-slate-800/30 transition-colors">
                      <td className="p-3 sm:p-3.5 font-mono text-xs sm:text-sm">am/is/are + V-ing</td>
                      <td className="p-3 sm:p-3.5 font-mono text-xs sm:text-sm text-indigo-400 font-semibold">was/were + V-ing</td>
                    </tr>
                    <tr className="hover:bg-slate-800/30 transition-colors">
                      <td className="p-3 sm:p-3.5 font-mono text-xs sm:text-sm">has / have + V3</td>
                      <td className="p-3 sm:p-3.5 font-mono text-xs sm:text-sm text-indigo-400 font-semibold">had + V3</td>
                    </tr>
                    <tr className="hover:bg-slate-800/30 transition-colors">
                      <td className="p-3 sm:p-3.5 font-mono text-xs sm:text-sm">V2 (went)</td>
                      <td className="p-3 sm:p-3.5 font-mono text-xs sm:text-sm text-indigo-400 font-semibold">had + V3 (had gone)</td>
                    </tr>
                    <tr className="hover:bg-indigo-950/40 bg-indigo-950/20 transition-colors">
                      <td className="p-3 sm:p-3.5 font-mono text-xs sm:text-sm">will</td>
                      <td className="p-3 sm:p-3.5 font-mono text-xs sm:text-sm text-cyan-400 font-semibold">would</td>
                    </tr>
                    <tr className="hover:bg-indigo-950/40 bg-indigo-950/20 transition-colors">
                      <td className="p-3 sm:p-3.5 font-mono text-xs sm:text-sm">can</td>
                      <td className="p-3 sm:p-3.5 font-mono text-xs sm:text-sm text-cyan-400 font-semibold">could</td>
                    </tr>
                    <tr className="hover:bg-indigo-950/40 bg-indigo-950/20 transition-colors">
                      <td className="p-3 sm:p-3.5 font-mono text-xs sm:text-sm">may</td>
                      <td className="p-3 sm:p-3.5 font-mono text-xs sm:text-sm text-cyan-400 font-semibold">might</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {activeTopic === 'pronouns' && (
            <div className="animate-in fade-in duration-300 relative z-10">
              <h2 className="text-xl sm:text-2xl md:text-3xl font-bold text-white mb-4 sm:mb-6 border-b border-slate-800 pb-3 sm:pb-4 tracking-tight">Změna zájmen (Pronoun Changes)</h2>
              <p className="text-slate-300 text-xs sm:text-sm mb-6 leading-relaxed">Zájmena se mění podle toho, kdo mluví a ke komu mluví.</p>
              
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 sm:gap-6 mb-8">
                <div className="bg-slate-950/60 border border-slate-800 rounded-2xl p-4 sm:p-5 shadow-lg">
                  <h3 className="font-bold text-white mb-3 text-xs sm:text-sm uppercase tracking-wider text-slate-400">Základní převody</h3>
                  <ul className="space-y-2">
                    <li className="flex justify-between items-center p-2 rounded-xl bg-slate-900 border border-slate-800 text-xs sm:text-sm"><span className="font-mono text-slate-300">I</span> ➔ <span className="text-indigo-400 font-semibold">he / she</span></li>
                    <li className="flex justify-between items-center p-2 rounded-xl bg-slate-900 border border-slate-800 text-xs sm:text-sm"><span className="font-mono text-slate-300">we</span> ➔ <span className="text-indigo-400 font-semibold">they</span></li>
                    <li className="flex justify-between items-center p-2 rounded-xl bg-slate-900 border border-slate-800 text-xs sm:text-sm"><span className="font-mono text-slate-300">my</span> ➔ <span className="text-indigo-400 font-semibold">his / her</span></li>
                    <li className="flex justify-between items-center p-2 rounded-xl bg-slate-900 border border-slate-800 text-xs sm:text-sm"><span className="font-mono text-slate-300">our</span> ➔ <span className="text-indigo-400 font-semibold">their</span></li>
                    <li className="flex justify-between items-center p-2 rounded-xl bg-slate-900 border border-slate-800 text-xs sm:text-sm"><span className="font-mono text-slate-300">me</span> ➔ <span className="text-indigo-400 font-semibold">him / her</span></li>
                  </ul>
                </div>

                <div className="space-y-4">
                  <div className="bg-blue-950/20 border border-blue-800/40 p-4 rounded-2xl text-xs sm:text-sm">
                    <p className="text-blue-400 font-bold mb-1 uppercase tracking-wider text-xs">Příklad</p>
                    <p className="font-mono text-slate-300 mb-2">Direct: Riya said, "<strong>I</strong> love <strong>my</strong> school."</p>
                    <div className="my-2 border-t border-blue-900/50"></div>
                    <p className="font-mono text-emerald-400">Indirect: Riya said that <strong>she</strong> loved <strong>her</strong> school.</p>
                  </div>

                  <div className="bg-amber-950/20 border border-amber-800/40 p-4 rounded-2xl text-xs sm:text-sm">
                    <p className="font-bold text-amber-400 mb-1 flex items-center gap-2">Pozor na "You"</p>
                    <p className="text-slate-300 leading-relaxed">Zájmeno <em>you</em> nemá jednu pevnou přeměnu, mění se podle toho, s kým se mluví (listener).</p>
                  </div>
                </div>
              </div>
            </div>
          )}

          {activeTopic === 'timeplace' && (
            <div className="animate-in fade-in duration-300 relative z-10">
              <h2 className="text-xl sm:text-2xl md:text-3xl font-bold text-white mb-4 sm:mb-6 border-b border-slate-800 pb-3 sm:pb-4 tracking-tight">Čas a Místo (Time and Place)</h2>
              <p className="text-slate-300 text-xs sm:text-sm mb-6 leading-relaxed">Protože nepřímou řeč obvykle říkáme na jiném místě a v jiný čas, musí se změnit i tato slova.</p>
              
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 sm:gap-6">
                <div className="bg-slate-950/60 border border-slate-800 rounded-2xl overflow-hidden shadow-lg">
                  <div className="bg-slate-800/80 p-3 font-bold text-center text-xs uppercase tracking-wider text-indigo-300 border-b border-slate-800">Čas (Time)</div>
                  <ul className="divide-y divide-slate-800/60 text-xs sm:text-sm">
                    <li className="p-2.5 sm:p-3 flex justify-between hover:bg-slate-800/30"><span className="font-mono text-slate-300">now</span><span className="text-indigo-400 font-semibold">then</span></li>
                    <li className="p-2.5 sm:p-3 flex justify-between hover:bg-slate-800/30"><span className="font-mono text-slate-300">today</span><span className="text-indigo-400 font-semibold">that day</span></li>
                    <li className="p-2.5 sm:p-3 flex justify-between hover:bg-slate-800/30"><span className="font-mono text-slate-300">tonight</span><span className="text-indigo-400 font-semibold">that night</span></li>
                    <li className="p-2.5 sm:p-3 flex justify-between hover:bg-slate-800/30"><span className="font-mono text-slate-300">yesterday</span><span className="text-indigo-400 font-semibold">the previous day</span></li>
                    <li className="p-2.5 sm:p-3 flex justify-between hover:bg-slate-800/30"><span className="font-mono text-slate-300">tomorrow</span><span className="text-indigo-400 font-semibold">the next day</span></li>
                    <li className="p-2.5 sm:p-3 flex justify-between hover:bg-slate-800/30"><span className="font-mono text-slate-300">last week</span><span className="text-indigo-400 font-semibold">the previous week</span></li>
                    <li className="p-2.5 sm:p-3 flex justify-between hover:bg-slate-800/30"><span className="font-mono text-slate-300">next week</span><span className="text-indigo-400 font-semibold">the following week</span></li>
                    <li className="p-2.5 sm:p-3 flex justify-between hover:bg-slate-800/30"><span className="font-mono text-slate-300">ago</span><span className="text-indigo-400 font-semibold">before</span></li>
                  </ul>
                </div>
                
                <div className="space-y-4">
                  <div className="bg-slate-950/60 border border-slate-800 rounded-2xl overflow-hidden shadow-lg">
                    <div className="bg-slate-800/80 p-3 font-bold text-center text-xs uppercase tracking-wider text-cyan-300 border-b border-slate-800">Místo a ukazovací zájmena</div>
                    <ul className="divide-y divide-slate-800/60 text-xs sm:text-sm">
                      <li className="p-2.5 sm:p-3 flex justify-between hover:bg-slate-800/30"><span className="font-mono text-slate-300">here</span><span className="text-cyan-400 font-semibold">there</span></li>
                      <li className="p-2.5 sm:p-3 flex justify-between hover:bg-slate-800/30"><span className="font-mono text-slate-300">this</span><span className="text-cyan-400 font-semibold">that</span></li>
                      <li className="p-2.5 sm:p-3 flex justify-between hover:bg-slate-800/30"><span className="font-mono text-slate-300">these</span><span className="text-cyan-400 font-semibold">those</span></li>
                      <li className="p-2.5 sm:p-3 flex justify-between hover:bg-slate-800/30"><span className="font-mono text-slate-300">come</span><span className="text-cyan-400 font-semibold">go</span></li>
                      <li className="p-2.5 sm:p-3 flex justify-between hover:bg-slate-800/30"><span className="font-mono text-slate-300">bring</span><span className="text-cyan-400 font-semibold">take</span></li>
                    </ul>
                  </div>
                  
                  <div className="p-4 bg-indigo-950/30 border border-indigo-800/40 rounded-2xl">
                    <p className="text-xs font-bold text-indigo-400 uppercase tracking-wider mb-2">PŘÍKLAD</p>
                    <p className="text-xs sm:text-sm font-mono text-slate-300">"I will come <span className="font-bold text-white">here tomorrow</span>."</p>
                    <p className="text-xs sm:text-sm font-mono text-indigo-300 mt-1">...she would go <span className="font-bold text-indigo-400">there the next day</span>.</p>
                  </div>
                </div>
              </div>
            </div>
          )}

          {activeTopic === 'questions' && (
            <div className="animate-in fade-in duration-300 relative z-10">
              <h2 className="text-xl sm:text-2xl md:text-3xl font-bold text-white mb-4 sm:mb-6 border-b border-slate-800 pb-3 sm:pb-4 tracking-tight">Otázky v nepřímé řeči (Questions)</h2>
              
              <div className="bg-rose-950/30 border border-rose-800/50 p-3.5 sm:p-4 rounded-2xl mb-6 flex items-start gap-3">
                <span className="text-xl sm:text-2xl shrink-0">⚠️</span>
                <div>
                  <h3 className="font-bold text-rose-300 text-sm sm:text-base">Důležité pravidlo:</h3>
                  <p className="text-slate-300 text-xs sm:text-sm mt-1 leading-relaxed">V nepřímé otázce se <strong>nepoužívá tázací pořádek slov</strong> a na konci <strong>není otazník</strong>. Pořádek slov je jako v běžné věte (Podmět + Sloveso).</p>
                </div>
              </div>

              <div className="space-y-4 sm:space-y-6">
                <div className="bg-slate-950/60 border border-slate-800 rounded-2xl p-4 sm:p-5 shadow-lg">
                  <h3 className="font-bold text-base sm:text-lg text-indigo-400 mb-2">1. Yes / No Questions (Zjišťovací)</h3>
                  <p className="text-xs sm:text-sm text-slate-300 mb-3 sm:mb-4">Použijeme <strong>asked + if / whether</strong>.</p>
                  
                  <div className="bg-slate-900 p-3 sm:p-3.5 rounded-xl border border-slate-800 text-xs sm:text-sm font-mono leading-relaxed">
                    <p className="text-slate-400 mb-1">Direct: Riya asked, "Are you ready?"</p>
                    <p className="text-emerald-400 font-bold">Indirect: Riya asked <span className="text-emerald-300 bg-emerald-950 px-1.5 py-0.5 rounded border border-emerald-800/60">if</span> I was ready.</p>
                  </div>
                </div>

                <div className="bg-slate-950/60 border border-slate-800 rounded-2xl p-4 sm:p-5 shadow-lg">
                  <h3 className="font-bold text-base sm:text-lg text-cyan-400 mb-2">2. Wh- Questions (Doplňovací)</h3>
                  <p className="text-xs sm:text-sm text-slate-300 mb-3 sm:mb-4">Zanecháme původní tázací slovo (where, when, why, how...).</p>
                  
                  <div className="bg-slate-900 p-3 sm:p-3.5 rounded-xl border border-slate-800 text-xs sm:text-sm font-mono leading-relaxed">
                    <p className="text-slate-400 mb-1">Direct: Riya asked, "Where do you live?"</p>
                    <p className="text-cyan-400 font-bold">Indirect: Riya asked <span className="text-cyan-300 bg-cyan-950 px-1.5 py-0.5 rounded border border-cyan-800/60">where</span> I lived.</p>
                  </div>
                </div>
              </div>
            </div>
          )}

          {activeTopic === 'commands' && (
            <div className="animate-in fade-in duration-300 relative z-10">
              <h2 className="text-xl sm:text-2xl md:text-3xl font-bold text-white mb-4 sm:mb-6 border-b border-slate-800 pb-3 sm:pb-4 tracking-tight">Rozkazy a žádosti (Commands & Requests)</h2>
              <p className="text-slate-300 text-xs sm:text-sm mb-6 leading-relaxed">Při převodu rozkazů používáme infinitiv (to + sloveso).</p>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 sm:gap-6">
                <div className="bg-emerald-950/20 border border-emerald-800/40 p-4 sm:p-5 rounded-2xl shadow-lg">
                  <h3 className="font-bold text-emerald-400 text-sm sm:text-base mb-2">Kladný rozkaz</h3>
                  <p className="text-[11px] sm:text-xs bg-slate-900 px-2.5 py-1 rounded-lg inline-block text-emerald-300 font-mono mb-3 sm:mb-4 border border-slate-800">
                    told / ordered / asked + předmět + <strong>to</strong> + sloveso
                  </p>
                  <p className="text-xs sm:text-sm text-slate-400 mb-1">Teacher said, "Sit down."</p>
                  <p className="text-xs sm:text-sm font-bold text-emerald-300">Teacher told the students <span className="underline">to sit</span> down.</p>
                </div>

                <div className="bg-rose-950/20 border border-rose-800/40 p-4 sm:p-5 rounded-2xl shadow-lg">
                  <h3 className="font-bold text-rose-400 text-sm sm:text-base mb-2">Záporný rozkaz</h3>
                  <p className="text-[11px] sm:text-xs bg-slate-900 px-2.5 py-1 rounded-lg inline-block text-rose-300 font-mono mb-3 sm:mb-4 border border-slate-800">
                    told / ordered / asked + předmět + <strong>not to</strong> + sloveso
                  </p>
                  <p className="text-xs sm:text-sm text-slate-400 mb-1">Mother said, "Do not waste time."</p>
                  <p className="text-xs sm:text-sm font-bold text-rose-300">Mother told me <span className="underline">not to waste</span> time.</p>
                </div>
              </div>
              
              <div className="mt-4 sm:mt-6 border border-amber-800/40 bg-amber-950/20 p-4 sm:p-5 rounded-2xl shadow-lg">
                <h3 className="font-bold text-amber-400 text-sm sm:text-base mb-2">Žádosti (Requests s "Please")</h3>
                <p className="text-xs sm:text-sm text-slate-300 mb-2 leading-relaxed">Slovo "please" se vynechá a nahradí se slovesem jako "asked" nebo "requested".</p>
                <p className="text-xs sm:text-sm text-slate-400 mb-1">Riya said, "Please help me."</p>
                <p className="text-xs sm:text-sm font-bold text-amber-300">Riya <span className="underline">asked</span> me to help her.</p>
              </div>
            </div>
          )}

          {activeTopic === 'exceptions' && (
            <div className="animate-in fade-in duration-300 relative z-10">
              <h2 className="text-xl sm:text-2xl md:text-3xl font-bold text-white mb-4 sm:mb-6 border-b border-slate-800 pb-3 sm:pb-4 tracking-tight">Kdy se časy NEMĚNÍ (Exceptions)</h2>
              <p className="text-slate-300 text-xs sm:text-sm mb-6 leading-relaxed">Ve třech specifických případech k "posunu do minulosti" nedochází.</p>

              <div className="space-y-4">
                <div className="bg-slate-950/60 border border-slate-800 rounded-2xl p-4 sm:p-5 hover:border-slate-700 transition-colors flex flex-col sm:flex-row gap-3 sm:gap-4 items-start">
                  <div className="text-2xl sm:text-3xl shrink-0">🌍</div>
                  <div>
                    <h3 className="font-bold text-white text-sm sm:text-base">1. Všeobecná pravda (Universal Truth)</h3>
                    <p className="text-xs sm:text-sm text-slate-400 mb-2 mt-0.5">Fakta, která platí vždy.</p>
                    <p className="text-xs sm:text-sm font-mono text-slate-400">Teacher said, "The Earth moves around the Sun."</p>
                    <p className="text-xs sm:text-sm font-mono text-indigo-400 font-bold mt-1">Teacher said that the Earth moves around the Sun.</p>
                  </div>
                </div>

                <div className="bg-slate-950/60 border border-slate-800 rounded-2xl p-4 sm:p-5 hover:border-slate-700 transition-colors flex flex-col sm:flex-row gap-3 sm:gap-4 items-start">
                  <div className="text-2xl sm:text-3xl shrink-0">⏱️</div>
                  <div>
                    <h3 className="font-bold text-white text-sm sm:text-base">2. Uvozovací sloveso je v přítomnosti (Reporting Verb in Present)</h3>
                    <p className="text-xs sm:text-sm text-slate-400 mb-2 mt-0.5">Např. says, tells, asks.</p>
                    <p className="text-xs sm:text-sm font-mono text-slate-400">Riya <strong className="text-rose-400">says</strong>, "I am busy."</p>
                    <p className="text-xs sm:text-sm font-mono text-indigo-400 font-bold mt-1">Riya says that she is busy.</p>
                  </div>
                </div>

                <div className="bg-slate-950/60 border border-slate-800 rounded-2xl p-4 sm:p-5 hover:border-slate-700 transition-colors flex flex-col sm:flex-row gap-3 sm:gap-4 items-start">
                  <div className="text-2xl sm:text-3xl shrink-0">🏛️</div>
                  <div>
                    <h3 className="font-bold text-white text-sm sm:text-base">3. Fakt je stále aktuální (Fact Still True)</h3>
                    <p className="text-xs sm:text-sm text-slate-400 mb-2 mt-0.5">Něco, co je pravda v momentě, kdy to tlumočíme.</p>
                    <p className="text-xs sm:text-sm font-mono text-slate-400">Aman said, "Delhi is the capital of India."</p>
                    <p className="text-xs sm:text-sm font-mono text-indigo-400 font-bold mt-1">Aman said that Delhi is the capital of India.</p>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

// --- PROCVIČOVÁNÍ KOMPONENTA ---
function PracticeSection() {
  const [questions, setQuestions] = useState<Question[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<QuestionOption | null>(null);
  const [score, setScore] = useState(0);
  const [isFinished, setIsFinished] = useState(false);
  const [history, setHistory] = useState<HistoryItem[]>([]);
  const [speakingText, setSpeakingText] = useState<string | null>(null);
  const [showExplanation, setShowExplanation] = useState(false);
  const [expandedHistoryIndex, setExpandedHistoryIndex] = useState<number | null>(null);

  // Streak & Badge states
  const [currentStreak, setCurrentStreak] = useState(0);
  const [sessionMaxStreak, setSessionMaxStreak] = useState(0);
  const [allTimeMaxStreak, setAllTimeMaxStreak] = useState<number>(() => {
    try {
      const saved = localStorage.getItem('reported_speech_max_streak');
      return saved ? parseInt(saved, 10) : 0;
    } catch {
      return 0;
    }
  });

  const [unlockedBadges, setUnlockedBadges] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem('reported_speech_badges');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [badgeToast, setBadgeToast] = useState<{ title: string; subtitle: string; icon: string } | null>(null);

  // Uložení do localStorage
  useEffect(() => {
    try {
      localStorage.setItem('reported_speech_badges', JSON.stringify(unlockedBadges));
    } catch (e) {
      console.error(e);
    }
  }, [unlockedBadges]);

  useEffect(() => {
    try {
      localStorage.setItem('reported_speech_max_streak', allTimeMaxStreak.toString());
    } catch (e) {
      console.error(e);
    }
  }, [allTimeMaxStreak]);

  // Text-to-Speech prevod textu na rec (Web Speech API)
  const speak = (text: string, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();

    if (!('speechSynthesis' in window)) {
      alert('Váš prohlížeč nepodporuje převod textu na řeč (Web Speech API).');
      return;
    }

    if (speakingText === text) {
      window.speechSynthesis.cancel();
      setSpeakingText(null);
      return;
    }

    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = 'en-US';
    utterance.rate = 0.9;

    const voices = window.speechSynthesis.getVoices();
    const englishVoice = voices.find(v => v.lang.startsWith('en') && (v.name.includes('Natural') || v.name.includes('Google') || v.name.includes('Samantha') || v.name.includes('Daniel') || v.name.includes('US') || v.name.includes('UK')));
    if (englishVoice) {
      utterance.voice = englishVoice;
    }

    utterance.onend = () => setSpeakingText(null);
    utterance.onerror = () => setSpeakingText(null);

    setSpeakingText(text);
    window.speechSynthesis.speak(utterance);
  };

  useEffect(() => {
    return () => {
      if ('speechSynthesis' in window) {
        window.speechSynthesis.cancel();
      }
    };
  }, []);

  // Inicializace kvízu - vybere náhodných 15 vět
  const startPractice = () => {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
    }
    setSpeakingText(null);
    setShowExplanation(false);
    setExpandedHistoryIndex(null);

    const shuffledDb = [...sentencesDb].sort(() => 0.5 - Math.random());
    const selected = shuffledDb.slice(0, 15).map(q => {
      const options: QuestionOption[] = [
        { text: q.c, isCorrect: true },
        { text: q.w1, isCorrect: false },
        { text: q.w2, isCorrect: false }
      ].sort(() => 0.5 - Math.random());
      
      return {
        direct: q.d,
        options: options,
        correctText: q.c,
        explanation: getSentenceExplanation(q)
      };
    });

    setQuestions(selected);
    setCurrentIndex(0);
    setScore(0);
    setIsFinished(false);
    setSelectedAnswer(null);
    setHistory([]);
    setSessionMaxStreak(0);
  };

  // Spuštění při prvním renderu
  useEffect(() => {
    startPractice();
  }, []);

  // Helper pro konfety při odznaku nebo 100% skóre
  const triggerConfetti = (type: 'badge' | 'perfect' = 'badge') => {
    try {
      if (type === 'badge') {
        confetti({
          particleCount: 75,
          spread: 70,
          origin: { y: 0.55 },
          colors: ['#f59e0b', '#6366f1', '#ec4899', '#10b981', '#3b82f6']
        });
      } else {
        const duration = 2.2 * 1000;
        const animationEnd = Date.now() + duration;

        const interval: ReturnType<typeof setInterval> = setInterval(() => {
          const timeLeft = animationEnd - Date.now();
          if (timeLeft <= 0) {
            return clearInterval(interval);
          }
          const particleCount = 40 * (timeLeft / duration);
          confetti({
            particleCount,
            startVelocity: 30,
            spread: 360,
            ticks: 60,
            zIndex: 999,
            origin: { x: Math.random() * 0.4 + 0.1, y: Math.random() * 0.4 + 0.1 }
          });
          confetti({
            particleCount,
            startVelocity: 30,
            spread: 360,
            ticks: 60,
            zIndex: 999,
            origin: { x: Math.random() * 0.4 + 0.5, y: Math.random() * 0.4 + 0.1 }
          });
        }, 220);
      }
    } catch (e) {
      console.error(e);
    }
  };

  const handleSelect = (option: QuestionOption) => {
    if (selectedAnswer) return; // Zamezení vícenásobnému kliknutí
    setSelectedAnswer(option);
    
    if (option.isCorrect) {
      setScore(s => s + 1);
      const newStreak = currentStreak + 1;
      setCurrentStreak(newStreak);

      setSessionMaxStreak(prev => Math.max(prev, newStreak));
      setAllTimeMaxStreak(prev => Math.max(prev, newStreak));

      // Kontrola odemčení odznaků
      let hasUnlockedNewBadge = false;
      BADGES_LIST.forEach(b => {
        if (newStreak >= b.targetStreak && !unlockedBadges.includes(b.id)) {
          setUnlockedBadges(prev => [...prev, b.id]);
          setBadgeToast({
            title: b.title,
            subtitle: b.subtitle,
            icon: b.icon
          });
          hasUnlockedNewBadge = true;
          setTimeout(() => {
            setBadgeToast(null);
          }, 4500);
        }
      });

      if (hasUnlockedNewBadge) {
        triggerConfetti('badge');
      }
    } else {
      setCurrentStreak(0);
    }

    // Uložit do historie pro přehled na konci
    setHistory(prev => [...prev, {
      direct: questions[currentIndex].direct,
      userAnswer: option.text,
      isCorrect: option.isCorrect,
      correctAnswer: questions[currentIndex].correctText,
      explanation: questions[currentIndex].explanation
    }]);
  };

  const handleNext = () => {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
    }
    setSpeakingText(null);
    setShowExplanation(false);

    if (currentIndex < questions.length - 1) {
      setCurrentIndex(prev => prev + 1);
      setSelectedAnswer(null);
    } else {
      setIsFinished(true);
      if (score === questions.length) {
        triggerConfetti('perfect');
      }
    }
  };

  if (questions.length === 0) return <div className="text-center py-20 text-slate-500">Načítání cvičení...</div>;

  if (isFinished) {
    return (
      <div className="max-w-3xl mx-auto animate-in fade-in zoom-in-95 duration-500">
        {/* Giant Score Hero Bento Card */}
        <div className="bg-indigo-600 rounded-3xl p-8 sm:p-10 text-white text-center shadow-2xl shadow-indigo-500/20 border border-indigo-400/30 relative overflow-hidden mb-8">
          <div className="absolute -right-10 -bottom-10 w-48 h-48 bg-white/10 rounded-full blur-2xl pointer-events-none"></div>
          
          <div className="w-20 h-20 mx-auto bg-white/10 border border-white/20 backdrop-blur-md rounded-2xl flex items-center justify-center mb-4 shadow-inner">
            <span className="text-4xl">🏆</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-bold mb-2 tracking-tight">Cvičení dokončeno!</h2>
          <p className="text-indigo-100 mb-4 text-sm">Váš výsledek z 15 náhodně vybraných vět.</p>
          
          <div className="text-5xl sm:text-6xl font-black mb-4 flex justify-center items-end gap-2 tracking-tight">
            {score} <span className="text-2xl text-indigo-200 font-medium">/ 15</span>
          </div>

          <div className="flex items-center justify-center gap-2 sm:gap-4 mb-6 flex-wrap">
            <div className="bg-white/10 backdrop-blur-sm border border-white/20 px-3.5 py-1.5 rounded-full text-xs font-semibold text-white flex items-center gap-1.5">
              <Flame size={15} className="text-amber-300 animate-pulse" />
              <span>Série v tomto testu: <strong>{sessionMaxStreak} v řadě</strong></span>
            </div>
            <div className="bg-white/10 backdrop-blur-sm border border-white/20 px-3.5 py-1.5 rounded-full text-xs font-semibold text-white flex items-center gap-1.5">
              <Sparkles size={15} className="text-yellow-300" />
              <span>Celkový rekord: <strong>{allTimeMaxStreak} v řadě</strong></span>
            </div>
          </div>

          <button 
            id="restart-practice-btn"
            onClick={startPractice}
            className="bg-white text-indigo-700 hover:bg-slate-100 px-8 py-3.5 rounded-2xl font-bold transition-all shadow-lg inline-flex items-center gap-2 cursor-pointer active:scale-95"
          >
            <RefreshCw size={20} /> Generovat nových 15 vět
          </button>
        </div>

        {/* Badges Component in Score Summary */}
        <BadgesSummaryCard maxStreak={allTimeMaxStreak} unlockedBadges={unlockedBadges} />

        {/* Answer History Bento Review Card */}
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 shadow-xl">
          <h3 className="font-bold text-white text-lg mb-4 flex items-center gap-2">
            <CheckCircle size={20} className="text-indigo-400" /> Přehled odpovědí s výslovností
          </h3>
          <div className="space-y-3 max-h-[500px] overflow-y-auto pr-1 custom-scrollbar">
            {history.map((item, i) => {
              const isExpanded = expandedHistoryIndex === i;

              return (
                <div 
                  key={i} 
                  className={`p-4 rounded-2xl border transition-all ${
                    item.isCorrect 
                      ? 'bg-emerald-950/30 border-emerald-800/40 text-emerald-200' 
                      : 'bg-rose-950/30 border-rose-800/40 text-rose-200'
                  }`}
                >
                  <div className="flex items-center justify-between gap-2 mb-2">
                    <p className="text-xs sm:text-sm font-semibold text-slate-200">{i+1}. {item.direct}</p>
                    <button
                      onClick={() => speak(item.direct)}
                      className="px-2.5 py-1 rounded-lg bg-slate-800/90 hover:bg-slate-700 text-slate-300 hover:text-white border border-slate-700/70 cursor-pointer text-xs flex items-center gap-1.5 shrink-0 min-h-[32px]"
                      title="Přehrát přímou řeč"
                    >
                      <Volume2 size={13} className={speakingText === item.direct ? 'animate-bounce text-indigo-400' : ''} />
                      <span>Přehrát</span>
                    </button>
                  </div>
                  
                  <div className="flex items-center justify-between gap-2 text-xs sm:text-sm">
                    <div className="flex items-start gap-2">
                      {item.isCorrect 
                        ? <CheckCircle size={18} className="text-emerald-400 shrink-0 mt-0.5" /> 
                        : <XCircle size={18} className="text-rose-400 shrink-0 mt-0.5" />}
                      <span className={item.isCorrect ? 'text-emerald-300 font-medium' : 'text-rose-300 font-medium'}>
                        {item.userAnswer}
                      </span>
                    </div>
                    <button
                      onClick={() => speak(item.userAnswer)}
                      className="px-2.5 py-1 rounded-lg bg-slate-800/90 hover:bg-slate-700 text-slate-300 hover:text-white border border-slate-700/70 cursor-pointer text-xs flex items-center gap-1.5 shrink-0 min-h-[32px]"
                      title="Přehrát vaši odpověď"
                    >
                      <Volume2 size={13} className={speakingText === item.userAnswer ? 'animate-bounce text-indigo-400' : ''} />
                      <span>Přehrát</span>
                    </button>
                  </div>

                  {!item.isCorrect && (
                    <div className="text-xs text-slate-400 mt-2.5 pt-2 border-t border-rose-800/40 flex flex-col gap-2">
                      <div className="flex items-center justify-between gap-2">
                        <div className="flex items-center gap-1.5">
                          <span className="font-bold text-rose-400">Správně:</span> {item.correctAnswer}
                        </div>
                        <div className="flex items-center gap-2">
                          <button
                            id={`explain-history-btn-${i}`}
                            onClick={() => setExpandedHistoryIndex(isExpanded ? null : i)}
                            className="px-2.5 py-1 rounded-lg bg-amber-500/10 hover:bg-amber-500/20 text-amber-300 border border-amber-500/30 cursor-pointer text-xs flex items-center gap-1 font-bold transition-all min-h-[32px]"
                            title="Vysvětlit gramatické pravidlo"
                          >
                            <HelpCircle size={13} />
                            <span>{isExpanded ? 'Skrýt pravidlo' : 'Vysvětlit chybu'}</span>
                          </button>
                          <button
                            onClick={() => speak(item.correctAnswer)}
                            className="px-2.5 py-1 rounded-lg bg-slate-800/90 hover:bg-slate-700 text-slate-300 hover:text-white border border-slate-700/70 cursor-pointer text-xs flex items-center gap-1.5 shrink-0 min-h-[32px]"
                            title="Přehrát správnou odpověď"
                          >
                            <Volume2 size={13} className={speakingText === item.correctAnswer ? 'animate-bounce text-indigo-400' : ''} />
                            <span>Přehrát</span>
                          </button>
                        </div>
                      </div>

                      <AnimatePresence>
                        {isExpanded && (
                          <motion.div
                            initial={{ opacity: 0, height: 0 }}
                            animate={{ opacity: 1, height: 'auto' }}
                            exit={{ opacity: 0, height: 0 }}
                            className="mt-1 p-3 rounded-xl bg-amber-950/40 border border-amber-500/30 text-amber-200 text-xs leading-relaxed"
                          >
                            <div className="flex items-start gap-2">
                              <BookOpen size={14} className="text-amber-400 shrink-0 mt-0.5" />
                              <div>
                                <strong className="text-amber-300 block mb-0.5">Pravidlo:</strong>
                                <span>{item.explanation}</span>
                              </div>
                            </div>
                          </motion.div>
                        )}
                      </AnimatePresence>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      </div>
    );
  }

  const currentQ = questions[currentIndex];
  const progress = ((currentIndex + 1) / questions.length) * 100;

  return (
    <div className="max-w-2xl mx-auto animate-in fade-in duration-300 relative">
      {/* Toast Alert při odemčení odznaku */}
      {badgeToast && (
        <div className="mb-6 p-4 rounded-2xl bg-gradient-to-r from-amber-500 via-indigo-600 to-purple-600 text-white shadow-2xl shadow-indigo-500/30 border border-amber-300/40 flex items-center justify-between animate-in slide-in-from-top duration-300 relative overflow-hidden z-20">
          <div className="flex items-center gap-3">
            <span className="text-3xl animate-bounce">{badgeToast.icon}</span>
            <div>
              <div className="flex items-center gap-1.5">
                <Sparkles size={14} className="text-amber-300 animate-spin" />
                <span className="text-[11px] font-extrabold uppercase tracking-wider text-amber-200">Nový odznak odemčen!</span>
              </div>
              <h4 className="font-bold text-base sm:text-lg leading-tight">{badgeToast.title}</h4>
              <p className="text-xs text-indigo-100 opacity-90">{badgeToast.subtitle}</p>
            </div>
          </div>
          <button
            onClick={() => setBadgeToast(null)}
            className="p-1.5 rounded-lg hover:bg-white/20 text-white cursor-pointer transition-colors"
          >
            <X size={18} />
          </button>
        </div>
      )}

      {/* Bento Progress & Score Header Widget */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 mb-6 shadow-xl flex flex-col gap-3">
        <div className="flex justify-between items-center text-sm font-medium flex-wrap gap-2">
          <span className="text-slate-400 flex items-center gap-1.5">
            Otázka <strong className="text-white">{currentIndex + 1}</strong> z 15
          </span>
          <div className="flex items-center gap-2">
            <motion.span 
              className={`px-3 py-1 font-bold border rounded-full text-xs flex items-center gap-1.5 transition-colors ${
                currentStreak > 0
                  ? 'bg-amber-500/15 border-amber-500/30 text-amber-300'
                  : 'bg-slate-800/80 border-slate-700 text-slate-400'
              }`}
              key={`streak-badge-${currentStreak}`}
              initial={{ scale: 1 }}
              animate={currentStreak > 0 ? { scale: [1, 1.18, 1] } : { scale: 1 }}
              transition={{ duration: 0.35, ease: "easeInOut" }}
            >
              <Flame size={14} className={currentStreak > 0 ? 'text-amber-400 animate-bounce' : 'text-slate-500'} />
              <span className="flex items-center gap-1">
                Série:{' '}
                <AnimatePresence mode="wait">
                  <motion.span
                    key={currentStreak}
                    initial={{ y: -8, opacity: 0, scale: 0.7 }}
                    animate={{ y: 0, opacity: 1, scale: 1 }}
                    exit={{ y: 8, opacity: 0, scale: 0.7 }}
                    transition={{ duration: 0.22 }}
                    className="inline-block font-black"
                  >
                    {currentStreak}
                  </motion.span>
                </AnimatePresence>
              </span>
            </motion.span>

            <motion.span 
              className="px-3 py-1 bg-indigo-500/10 text-indigo-400 font-bold border border-indigo-500/20 rounded-full text-xs flex items-center gap-1"
              key={`score-badge-${score}`}
              initial={{ scale: 1 }}
              animate={score > 0 ? { scale: [1, 1.15, 1] } : { scale: 1 }}
              transition={{ duration: 0.3, ease: "easeInOut" }}
            >
              <span>Skóre:</span>
              <AnimatePresence mode="wait">
                <motion.span
                  key={score}
                  initial={{ y: -8, opacity: 0, scale: 0.7 }}
                  animate={{ y: 0, opacity: 1, scale: 1 }}
                  exit={{ y: 8, opacity: 0, scale: 0.7 }}
                  transition={{ duration: 0.22 }}
                  className="inline-block font-black text-indigo-300"
                >
                  {score}
                </motion.span>
              </AnimatePresence>
            </motion.span>
          </div>
        </div>
        <div className="h-2.5 w-full bg-slate-950 rounded-full overflow-hidden p-0.5 border border-slate-800">
          <div 
            className="h-full bg-gradient-to-r from-indigo-500 via-cyan-400 to-indigo-400 rounded-full transition-all duration-500 ease-out shadow-sm shadow-indigo-500/30" 
            style={{ width: `${progress}%` }}
          ></div>
        </div>
      </div>

      {/* Bento Question Card */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl sm:rounded-3xl shadow-2xl overflow-hidden">
        <div className="p-5 sm:p-8 md:p-10 border-b border-slate-800/80 bg-slate-950/60 text-center relative flex flex-col items-center">
          <div className="absolute inset-x-0 top-0 h-1 bg-gradient-to-r from-indigo-500 via-cyan-400 to-indigo-500"></div>
          
          <div className="flex items-center justify-center gap-2 mb-3 sm:mb-4">
            <span className="inline-block bg-indigo-500/10 border border-indigo-500/20 px-3 py-0.5 sm:px-3.5 sm:py-1 rounded-full text-[10px] sm:text-xs font-bold text-indigo-300 tracking-wider uppercase">
              Direct Speech
            </span>

            <button
              id="play-direct-speech-btn"
              onClick={(e) => speak(currentQ.direct, e)}
              className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold border transition-all cursor-pointer min-h-[32px] ${
                speakingText === currentQ.direct
                  ? 'bg-indigo-600 text-white border-indigo-400 shadow-md shadow-indigo-500/30 animate-pulse'
                  : 'bg-slate-800/80 hover:bg-slate-700 text-slate-300 border-slate-700/80 hover:text-white'
              }`}
              title="Přehrát přímou řeč"
            >
              <Volume2 size={14} className={speakingText === currentQ.direct ? 'animate-bounce' : ''} />
              <span>{speakingText === currentQ.direct ? 'Přehrává...' : 'Přehrát'}</span>
            </button>
          </div>

          <h2 className="text-xl sm:text-2xl md:text-3xl font-semibold text-slate-100 leading-tight tracking-tight">
            {currentQ.direct}
          </h2>
        </div>
        
        <div className="p-4 sm:p-6 md:p-8">
          <p className="text-[11px] sm:text-xs font-bold text-slate-400 mb-3 sm:mb-4 uppercase tracking-wider">Vyberte správnou nepřímou řeč:</p>
          <div className="space-y-2.5 sm:space-y-3">
            {currentQ.options.map((option, index) => {
              const isSelected = selectedAnswer === option;
              const isCorrectAnswer = option.isCorrect;
              
              let btnClass = "w-full text-left p-3.5 sm:p-4 md:p-5 rounded-xl sm:rounded-2xl border transition-all duration-200 flex items-center justify-between group shadow-sm min-h-[52px] ";
              
              if (!selectedAnswer) {
                btnClass += "border-slate-800 bg-slate-950/60 hover:bg-slate-800/60 hover:border-indigo-500/50 text-slate-200";
              } else if (isSelected && isCorrectAnswer) {
                btnClass += "border-2 border-emerald-500 bg-emerald-950/50 text-emerald-100 shadow-lg shadow-emerald-500/10";
              } else if (isSelected && !isCorrectAnswer) {
                btnClass += "border-2 border-rose-500 bg-rose-950/50 text-rose-100 shadow-lg shadow-rose-500/10";
              } else if (!isSelected && isCorrectAnswer) {
                // Show correct option when user picked wrongly
                btnClass += "border border-emerald-500/60 bg-emerald-950/30 text-emerald-200 opacity-90";
              } else {
                btnClass += "border border-slate-800/40 bg-slate-950/30 text-slate-500 opacity-40";
              }

              return (
                <div
                  key={index}
                  id={`option-card-${index}`}
                  onClick={() => handleSelect(option)}
                  className={`${btnClass} ${!selectedAnswer ? 'cursor-pointer' : 'cursor-default'}`}
                >
                  <span className="font-medium text-xs sm:text-sm md:text-base leading-snug flex-1 pr-2">{option.text}</span>
                  
                  <div className="flex items-center gap-2 shrink-0">
                    <button
                      type="button"
                      id={`play-option-btn-${index}`}
                      onClick={(e) => speak(option.text, e)}
                      className={`px-2.5 py-1.5 rounded-lg border text-xs font-semibold transition-all cursor-pointer flex items-center gap-1.5 min-h-[36px] ${
                        speakingText === option.text
                          ? 'bg-indigo-600 text-white border-indigo-400 shadow-md animate-pulse'
                          : 'bg-slate-900/90 hover:bg-slate-800 text-slate-300 hover:text-white border-slate-700/70'
                      }`}
                      title="Přehrát výslovnost věty"
                    >
                      <Volume2 size={14} className={speakingText === option.text ? 'animate-bounce' : ''} />
                      <span className="hidden xs:inline">{speakingText === option.text ? 'Hraje...' : 'Přehrát'}</span>
                    </button>
                    {selectedAnswer && isCorrectAnswer && <CheckCircle size={20} className="text-emerald-400 shrink-0 ml-1" />}
                    {selectedAnswer && isSelected && !isCorrectAnswer && <XCircle size={20} className="text-rose-400 shrink-0 ml-1" />}
                  </div>
                </div>
              );
            })}
          </div>

          {/* Zobrazení tlačítka 'Vysvětlit chybu' při nesprávné odpovědi */}
          {selectedAnswer && !selectedAnswer.isCorrect && (
            <div className="mt-5 pt-4 border-t border-slate-800/80 flex flex-col gap-3">
              <div className="flex items-center justify-between flex-wrap gap-2">
                <div className="flex items-center gap-2 text-rose-400 font-semibold text-xs sm:text-sm">
                  <XCircle size={18} className="shrink-0" />
                  <span>Nesprávná odpověď. Správná možnost byla zvýrazněna.</span>
                </div>
                <button
                  type="button"
                  id="explain-error-btn"
                  onClick={() => setShowExplanation(!showExplanation)}
                  className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-amber-500/15 hover:bg-amber-500/25 text-amber-300 border border-amber-500/40 text-xs sm:text-sm font-bold transition-all cursor-pointer shadow-md active:scale-95"
                >
                  <HelpCircle size={16} />
                  <span>{showExplanation ? 'Skrýt vysvětlení' : 'Vysvětlit chybu'}</span>
                </button>
              </div>

              <AnimatePresence>
                {showExplanation && (
                  <motion.div
                    initial={{ opacity: 0, height: 0, y: -6 }}
                    animate={{ opacity: 1, height: 'auto', y: 0 }}
                    exit={{ opacity: 0, height: 0, y: -6 }}
                    transition={{ duration: 0.25 }}
                    className="p-4 rounded-2xl bg-amber-950/40 border border-amber-500/30 text-amber-200 text-xs sm:text-sm leading-relaxed shadow-lg overflow-hidden"
                  >
                    <div className="flex items-start gap-3">
                      <div className="p-2 bg-amber-500/20 border border-amber-500/40 rounded-xl text-amber-300 shrink-0 mt-0.5">
                        <BookOpen size={18} />
                      </div>
                      <div>
                        <h4 className="font-bold text-amber-300 text-sm mb-1 flex items-center gap-1.5">
                          Gramatické pravidlo pro tuto větu
                        </h4>
                        <p className="text-amber-100/90 leading-relaxed">{currentQ.explanation}</p>
                      </div>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          )}

          {/* Tlačítko Další */}
          <div className={`mt-8 flex justify-end transition-opacity duration-300 ${selectedAnswer ? 'opacity-100' : 'opacity-0 pointer-events-none'}`}>
            <button 
              id="next-question-btn"
              onClick={handleNext}
              className="bg-indigo-600 hover:bg-indigo-500 text-white px-7 py-3 rounded-xl font-bold flex items-center gap-2 transition-all shadow-lg shadow-indigo-600/25 border border-indigo-400/30 cursor-pointer active:scale-95 min-h-[44px]"
            >
              {currentIndex === questions.length - 1 ? 'Vyhodnotit' : 'Další věta'} <ChevronRight size={18} />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

