
export enum ConditionalType {
  FIRST = 'first',
  SECOND = 'second'
}

export enum DifficultyLevel {
  EASY = 'easy',
  HARD = 'hard'
}

export interface Question {
  id: string;
  type: ConditionalType;
  template: string; // String with [G] placeholders
  verbs: string[]; // The infinitives for the gaps
  answers: string[]; // The correct conjugated forms for the gaps
  easyGapIndex: number; // Which gap index to show in Easy mode
  explanation: string;
}

export interface QuizResult {
  id: string;
  timestamp: number;
  score: number;
  total: number;
  difficulty: DifficultyLevel;
  date: string;
}

export interface QuizState {
  questions: Question[];
  currentScore: number;
  submitted: boolean;
  difficulty: DifficultyLevel;
  userAnswers: Record<string, string[]>; // Map question ID to array of answers
}