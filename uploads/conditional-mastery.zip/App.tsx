
import React, { useState, useEffect } from 'react';
import { 
  BookOpen, Sparkles, RefreshCw, CheckCircle2, XCircle, HelpCircle, 
  QrCode, ArrowRight, History, Trash2, Trophy, Zap, MousePointer2, ChevronLeft
} from 'lucide-react';
import { Question, ConditionalType, DifficultyLevel, QuizState, QuizResult } from './types';
import { getBalancedQuestions } from './constants';

// --- Sub-components ---

const TheoryCard: React.FC<{ title: string; color: string; formula: string; example: string; useCase: string; note?: string }> = ({ 
  title, color, formula, example, useCase, note 
}) => (
  <div className={`bg-white p-6 rounded-2xl shadow-sm border border-slate-200 border-l-4 ${color}`}>
    <h2 className={`text-xl font-bold mb-4 flex items-center gap-2`}>
      <BookOpen className="w-5 h-5" /> {title}
    </h2>
    <p className="mb-3 text-slate-700"><strong>Usage:</strong> {useCase}</p>
    <div className="bg-slate-50 p-4 rounded-xl font-mono text-sm mb-4 border border-slate-100">
      {formula}
    </div>
    <p className="italic text-slate-600 mb-2">Example: {example}</p>
    {note && <p className="text-xs text-slate-400 mt-3 flex items-center gap-1"><HelpCircle className="w-3 h-3"/> {note}</p>}
  </div>
);

const HistoryItem: React.FC<{ result: QuizResult }> = ({ result }) => {
  const percentage = Math.round((result.score / result.total) * 100);
  const isGreat = percentage >= 80;
  const isGood = percentage >= 50;

  return (
    <div className="bg-white p-4 rounded-xl border border-slate-200 flex items-center justify-between shadow-sm hover:shadow-md transition-shadow">
      <div className="flex items-center gap-4">
        <div className={`p-3 rounded-full ${isGreat ? 'bg-emerald-100 text-emerald-600' : isGood ? 'bg-amber-100 text-amber-600' : 'bg-red-100 text-red-600'}`}>
          <Trophy className="w-5 h-5" />
        </div>
        <div>
          <p className="font-bold text-slate-800">{result.score} / {result.total} pts</p>
          <div className="flex items-center gap-2">
            <span className="text-[10px] uppercase font-bold text-slate-400 border border-slate-200 px-1.5 rounded">{result.difficulty}</span>
            <span className="text-xs text-slate-500">{result.date}</span>
          </div>
        </div>
      </div>
      <div className="text-right">
        <span className={`text-lg font-black ${isGreat ? 'text-emerald-600' : isGood ? 'text-amber-600' : 'text-red-600'}`}>
          {percentage}%
        </span>
      </div>
    </div>
  );
};

// --- Main App ---

const App: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'theory' | 'practice' | 'history'>('theory');
  const [history, setHistory] = useState<QuizResult[]>([]);
  const [levelChosen, setLevelChosen] = useState(false);
  const [quiz, setQuiz] = useState<QuizState>({
    questions: getBalancedQuestions(),
    currentScore: 0,
    submitted: false,
    difficulty: DifficultyLevel.EASY,
    userAnswers: {}
  });

  const currentUrl = window.location.href;

  useEffect(() => {
    const saved = localStorage.getItem('conditional_mastery_history');
    if (saved) try { setHistory(JSON.parse(saved)); } catch (e) {}
  }, []);

  useEffect(() => {
    localStorage.setItem('conditional_mastery_history', JSON.stringify(history));
  }, [history]);

  const handleLevelChoice = (level: DifficultyLevel) => {
    setQuiz({
      questions: getBalancedQuestions(),
      difficulty: level,
      submitted: false,
      userAnswers: {},
      currentScore: 0
    });
    setLevelChosen(true);
  };

  const resetPractice = () => {
    setLevelChosen(false);
    setQuiz(prev => ({ ...prev, submitted: false, userAnswers: {}, currentScore: 0 }));
  };

  const handleInputChange = (qId: string, gapIdx: number, val: string) => {
    setQuiz(prev => {
      const answers = { ...prev.userAnswers };
      if (!answers[qId]) answers[qId] = [];
      answers[qId][gapIdx] = val;
      return { ...prev, userAnswers: answers };
    });
  };

  const checkAnswers = () => {
    let score = 0;
    quiz.questions.forEach(q => {
      const user = quiz.userAnswers[q.id] || [];
      const correct = q.answers;
      
      if (quiz.difficulty === DifficultyLevel.EASY) {
        if ((user[q.easyGapIndex] || '').trim().toLowerCase() === correct[q.easyGapIndex].toLowerCase()) {
          score++;
        }
      } else {
        const isPerfect = correct.every((ans, i) => (user[i] || '').trim().toLowerCase() === ans.toLowerCase());
        if (isPerfect) score++;
      }
    });

    const result: QuizResult = {
      id: crypto.randomUUID(),
      timestamp: Date.now(),
      score,
      total: quiz.questions.length,
      difficulty: quiz.difficulty,
      date: new Date().toLocaleString()
    };

    setQuiz(prev => ({ ...prev, currentScore: score, submitted: true }));
    setHistory(prev => [result, ...prev]);
  };

  const nextSet = () => {
    setQuiz(prev => ({
      ...prev,
      questions: getBalancedQuestions(),
      currentScore: 0,
      submitted: false,
      userAnswers: {}
    }));
  };

  const renderSentence = (q: Question) => {
    const parts = q.template.split('[G]');
    let gapCount = 0;

    return (
      <p className="text-lg leading-relaxed text-slate-800">
        {parts.map((part, i) => {
          if (i === parts.length - 1) return <span key={i}>{part}</span>;
          
          const currentGapIdx = gapCount++;
          const verb = q.verbs[currentGapIdx] || '';
          const isGapActive = quiz.difficulty === DifficultyLevel.HARD || currentGapIdx === q.easyGapIndex;
          const userVal = (quiz.userAnswers[q.id] || [])[currentGapIdx] || '';
          const isCorrect = quiz.submitted && userVal.trim().toLowerCase() === q.answers[currentGapIdx].toLowerCase();

          return (
            <React.Fragment key={i}>
              {part}
              {isGapActive ? (
                <span className="inline-block relative group mt-5 sm:mt-0">
                  <input 
                    type="text"
                    value={userVal}
                    disabled={quiz.submitted}
                    onChange={(e) => handleInputChange(q.id, currentGapIdx, e.target.value)}
                    placeholder="..."
                    className={`mx-1 border-b-2 outline-none px-2 py-0.5 min-w-[140px] text-center font-bold bg-transparent transition-all ${
                      quiz.submitted 
                        ? (isCorrect ? 'border-emerald-500 text-emerald-700' : 'border-red-500 text-red-700')
                        : 'border-slate-300 focus:border-indigo-500 text-indigo-600'
                    }`}
                  />
                  {verb && !quiz.submitted && (
                    <span className="absolute -top-3.5 left-1/2 -translate-x-1/2 text-xs text-indigo-600 font-extrabold uppercase tracking-widest opacity-0 group-focus-within:opacity-100 transition-all whitespace-nowrap">
                      {verb}
                    </span>
                  )}
                  {verb && quiz.submitted && !isCorrect && (
                     <span className="absolute -top-3.5 left-1/2 -translate-x-1/2 text-xs text-red-500 font-bold italic whitespace-nowrap">
                      ({verb})
                    </span>
                  )}
                  {verb && !quiz.submitted && (
                     <span className="absolute -top-3.5 left-1/2 -translate-x-1/2 text-xs text-slate-600 font-bold group-focus-within:hidden whitespace-nowrap">
                      ({verb})
                    </span>
                  )}
                </span>
              ) : (
                <span className="font-bold text-indigo-600 border-b-2 border-transparent px-1">{q.answers[currentGapIdx]}</span>
              )}
            </React.Fragment>
          );
        })}
      </p>
    );
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 pb-20">
      <nav className="bg-white border-b border-slate-200 sticky top-0 z-30 shadow-sm">
        <div className="max-w-4xl mx-auto px-4 flex items-center justify-between h-16">
          <div className="flex items-center gap-2 font-bold text-xl text-indigo-600">
            <Sparkles className="w-6 h-6" />
            <span>ConditionalMaster</span>
          </div>
          <div className="flex bg-slate-100 p-1 rounded-xl">
            {['theory', 'practice', 'history'].map(tab => (
              <button key={tab} onClick={() => setActiveTab(tab as any)}
                className={`px-4 py-1.5 rounded-lg text-xs sm:text-sm font-medium transition ${activeTab === tab ? 'bg-white shadow-sm text-indigo-600' : 'text-slate-500 hover:text-slate-700'}`}>
                {tab.charAt(0).toUpperCase() + tab.slice(1)}
              </button>
            ))}
          </div>
        </div>
      </nav>

      <main className="max-w-4xl mx-auto px-4 pt-8">
        {activeTab === 'theory' && (
          <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
            <header className="mb-8"><h1 className="text-3xl font-extrabold text-slate-800">Grammar Overview</h1></header>
            <div className="grid md:grid-cols-2 gap-6">
              <TheoryCard title="First Conditional" color="border-l-blue-500" formula="If + Present Simple, ... will + verb" example="If it rains, we will stay home." useCase="Probable future events." />
              <TheoryCard title="Second Conditional" color="border-l-emerald-500" formula="If + Past Simple, ... would + verb" example="If I won, I would travel." useCase="Imaginary scenarios." note="Always use 'were' for 'to be'." />
            </div>
            <div className="bg-white p-6 rounded-2xl border flex flex-col sm:flex-row items-center gap-6">
              <div className="p-2 bg-slate-50 rounded-xl"><img src={`https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=${encodeURIComponent(currentUrl)}`} className="w-20 h-20" /></div>
              <div className="flex-1 text-center sm:text-left">
                <h3 className="font-bold flex items-center gap-2 justify-center sm:justify-start"><QrCode className="w-4 h-4 text-indigo-500"/> Classroom QR</h3>
                <p className="text-xs text-slate-500 mt-1">Scan to join the exercise on your mobile.</p>
              </div>
              <button onClick={() => { setActiveTab('practice'); setLevelChosen(false); }} className="bg-indigo-600 text-white px-6 py-3 rounded-xl font-bold flex items-center gap-2">Start Practicing <ArrowRight className="w-4 h-4"/></button>
            </div>
          </div>
        )}

        {activeTab === 'practice' && (
          <div className="animate-in fade-in slide-in-from-bottom-4 duration-500">
            {!levelChosen ? (
              <div className="max-w-2xl mx-auto space-y-8 py-12">
                <div className="text-center">
                  <h2 className="text-3xl font-extrabold text-slate-800">Choose Your Level</h2>
                  <p className="text-slate-500 mt-2">Pick how challenging you want the session to be.</p>
                </div>
                
                <div className="grid sm:grid-cols-2 gap-6">
                  <button 
                    onClick={() => handleLevelChoice(DifficultyLevel.EASY)}
                    className="group bg-white p-8 rounded-3xl border-2 border-slate-100 hover:border-indigo-500 transition-all text-left shadow-sm hover:shadow-xl"
                  >
                    <div className="w-12 h-12 bg-indigo-50 text-indigo-600 rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                      <MousePointer2 className="w-6 h-6" />
                    </div>
                    <h3 className="text-xl font-bold text-slate-800">Easy Level</h3>
                    <p className="text-sm text-slate-500 mt-2 leading-relaxed">Fill in only <span className="text-indigo-600 font-bold underline">one part</span> of the conditional sentence. The other part is provided.</p>
                    <div className="mt-6 flex items-center text-indigo-600 font-bold text-sm">
                      Select Easy <ArrowRight className="w-4 h-4 ml-2" />
                    </div>
                  </button>

                  <button 
                    onClick={() => handleLevelChoice(DifficultyLevel.HARD)}
                    className="group bg-white p-8 rounded-3xl border-2 border-slate-100 hover:border-indigo-500 transition-all text-left shadow-sm hover:shadow-xl"
                  >
                    <div className="w-12 h-12 bg-amber-50 text-amber-600 rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                      <Zap className="w-6 h-6" />
                    </div>
                    <h3 className="text-xl font-bold text-slate-800">Hard Level</h3>
                    <p className="text-sm text-slate-500 mt-2 leading-relaxed">Fill in <span className="text-amber-600 font-bold underline">both parts</span> of the conditional (If-clause and Result). Full conjugation required.</p>
                    <div className="mt-6 flex items-center text-amber-600 font-bold text-sm">
                      Select Hard <ArrowRight className="w-4 h-4 ml-2" />
                    </div>
                  </button>
                </div>
              </div>
            ) : (
              <div className="space-y-6">
                <div className="bg-white rounded-2xl shadow-sm border overflow-hidden">
                  <div className="bg-slate-50 p-6 border-b flex flex-col sm:flex-row items-center justify-between gap-4">
                    <div className="flex flex-col gap-1">
                      <button 
                        onClick={resetPractice}
                        className="text-xs font-bold text-indigo-600 flex items-center gap-1 hover:underline mb-1"
                      >
                        <ChevronLeft className="w-3 h-3"/> Change Level
                      </button>
                      <div className="flex items-center gap-2">
                        <h2 className="text-xl font-bold text-slate-800">Practice Session</h2>
                        <span className={`text-[10px] px-2 py-0.5 rounded-full font-black uppercase tracking-wider ${quiz.difficulty === DifficultyLevel.HARD ? 'bg-amber-100 text-amber-700 border border-amber-200' : 'bg-indigo-100 text-indigo-700 border border-indigo-200'}`}>
                          {quiz.difficulty}
                        </span>
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      {quiz.submitted && (
                        <span className={`px-4 py-1.5 rounded-full text-sm font-bold animate-in zoom-in ${quiz.currentScore >= 8 ? 'bg-emerald-100 text-emerald-700' : (quiz.currentScore >= 5 ? 'bg-amber-100 text-amber-700' : 'bg-red-100 text-red-700')}`}>
                          Score: {quiz.currentScore}/10
                        </span>
                      )}
                      <button onClick={nextSet} className="flex items-center gap-2 bg-indigo-50 text-indigo-600 px-4 py-2 rounded-xl text-sm font-semibold hover:bg-indigo-100 transition shadow-sm">
                        <RefreshCw className="w-4 h-4"/> Next Set
                      </button>
                    </div>
                  </div>

                  <div className="p-6 space-y-12">
                    {quiz.questions.map((q, idx) => {
                      const userAnswersForQ = quiz.userAnswers[q.id] || [];
                      const isPerfect = q.answers.every((ans, i) => (userAnswersForQ[i] || '').trim().toLowerCase() === ans.toLowerCase());
                      
                      return (
                        <div key={q.id} className={`p-4 rounded-xl border transition-all ${quiz.submitted ? (isPerfect ? 'border-emerald-200 bg-emerald-50/20' : 'border-red-200 bg-red-50/20') : 'border-slate-100 hover:border-slate-200'}`}>
                          <div className="flex items-start gap-4">
                            <span className="w-6 h-6 flex items-center justify-center bg-slate-200 rounded-full text-[10px] font-bold text-slate-600 shrink-0 mt-1">{idx + 1}</span>
                            <div className="flex-1">
                              {renderSentence(q)}
                              {quiz.submitted && (
                                <div className="mt-4 flex items-start gap-2 p-3 bg-white/50 rounded-lg animate-in slide-in-from-top-2">
                                  {isPerfect ? <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0" /> : <XCircle className="w-4 h-4 text-red-500 shrink-0" />}
                                  <div className="text-xs">
                                    <p className={`font-bold ${isPerfect ? 'text-emerald-700' : 'text-red-700'}`}>{isPerfect ? 'Well done!' : `Key: ${q.answers.join(' | ')}`}</p>
                                    <p className="text-slate-500 mt-1 italic">{q.explanation}</p>
                                  </div>
                                </div>
                              )}
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>

                  <div className="bg-slate-50 p-6 border-t flex gap-4">
                    <button 
                      onClick={checkAnswers} 
                      disabled={quiz.submitted || Object.keys(quiz.userAnswers).length === 0} 
                      className="flex-1 bg-indigo-600 text-white py-4 rounded-2xl font-bold hover:bg-indigo-700 disabled:opacity-50 shadow-md shadow-indigo-100 transition-all hover:-translate-y-0.5 active:translate-y-0"
                    >
                      Check Answers
                    </button>
                    <button onClick={nextSet} className="px-8 bg-white text-slate-600 py-4 rounded-2xl font-bold border border-slate-200 hover:bg-slate-50 transition-colors">Reset</button>
                  </div>
                </div>
              </div>
            )}
          </div>
        )}

        {activeTab === 'history' && (
          <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
            <header className="flex items-center justify-between">
              <div><h1 className="text-3xl font-extrabold text-slate-800">Your Progress</h1><p className="text-sm text-slate-500">History of your practice sessions.</p></div>
              {history.length > 0 && <button onClick={() => confirm('Are you sure you want to clear your history?') && setHistory([])} className="text-red-500 text-sm font-bold bg-red-50 px-3 py-2 rounded-xl flex items-center gap-2 hover:bg-red-100 transition-colors"><Trash2 className="w-4 h-4"/> Clear All</button>}
            </header>
            {history.length === 0 ? (
              <div className="p-16 border-2 border-dashed border-slate-200 rounded-3xl text-center">
                <div className="w-16 h-16 bg-slate-100 rounded-full flex items-center justify-center mx-auto mb-4 text-slate-300">
                  <History className="w-8 h-8" />
                </div>
                <h3 className="text-lg font-bold text-slate-700">No sessions yet</h3>
                <p className="text-sm text-slate-400 mt-2">Finish an exercise to see your history here.</p>
                <button onClick={() => { setActiveTab('practice'); setLevelChosen(false); }} className="mt-6 text-indigo-600 font-bold hover:underline">Go to Practice</button>
              </div>
            ) : (
              <div className="grid gap-4">{history.map(r => <HistoryItem key={r.id} result={r} />)}</div>
            )}
          </div>
        )}
      </main>
    </div>
  );
};

export default App;
