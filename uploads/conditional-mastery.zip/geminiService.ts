
import { GoogleGenAI, Type } from "@google/genai";
import { SYSTEM_INSTRUCTION } from "./constants";
import { Question, ConditionalType } from "./types";

// Removed top-level initialization as per guidelines

export const generateNewQuestions = async (count: number = 5): Promise<Question[]> => {
  // Always initialize instance with apiKey named parameter from process.env.API_KEY
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: `Generate ${count} interactive gap-fill English grammar questions about First and Second Conditionals.`,
    config: {
      systemInstruction: SYSTEM_INSTRUCTION + " You must output ONLY a JSON array of questions.",
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.ARRAY,
        items: {
          type: Type.OBJECT,
          properties: {
            id: { type: Type.STRING },
            text: { type: Type.STRING, description: "The sentence with ___ for the gap and verb in brackets, e.g. 'If I ___ (be) tall, I would play basketball.'" },
            answer: { type: Type.STRING, description: "The correct verb form for the gap." },
            type: { type: Type.STRING, enum: Object.values(ConditionalType) },
            explanation: { type: Type.STRING, description: "A short student-friendly explanation of why this form is correct." }
          },
          required: ["id", "text", "answer", "type", "explanation"]
        }
      }
    }
  });

  try {
    const data = JSON.parse(response.text || '[]');
    return data as Question[];
  } catch (err) {
    console.error("Failed to parse AI generated questions", err);
    return [];
  }
};