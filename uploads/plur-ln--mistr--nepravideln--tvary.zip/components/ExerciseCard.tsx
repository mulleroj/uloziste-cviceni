
import React, { useState, useEffect, useRef } from 'react';
import { Question } from '../types';
import { Sparkles, ArrowRight, Info, CheckCircle, XCircle } from 'lucide-react';

interface Props {
  question: Question;
  index: number;
  total: number;
  onNext: (isCorrect: boolean, answer: string) => void;
}

export const ExerciseCard: React.FC<Props> = ({ question, index, total, onNext }) => {
  const [answer, setAnswer] = useState('');
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [isCorrect, setIsCorrect] = useState(false);
  const [showExplanation, setShowExplanation] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    setAnswer('');
    setIsSubmitted(false);
    setIsCorrect(false);
    setShowExplanation(false);
    inputRef.current?.focus();
  }, [question]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!answer.trim() || isSubmitted) return;

    const normalizedAnswer = answer.trim().toLowerCase();
    const normalizedCorrect = question.plural.toLowerCase();
    
    const correct = normalizedAnswer === normalizedCorrect;
    setIsCorrect(correct);
    setIsSubmitted(true);
    if (!correct) setShowExplanation(true);
  };

  const handleNext = () => {
    onNext(isCorrect, answer);
  };

  const progress = ((index + 1) / total) * 100;

  return (
    <div className="w-full max-w-xl mx-auto">
      {/* Progress Bar */}
      <div className="mb-6">
        <div className="flex justify-between text-sm text-gray-500 mb-2">
          <span>Otázka {index + 1} z {total}</span>
          <span>{Math.round(progress)}% hotovo</span>
        </div>
        <div className="h-2 w-full bg-gray-200 rounded-full overflow-hidden">
          <div 
            className="h-full bg-blue-500 transition-all duration-300" 
            style={{ width: `${progress}%` }}
          />
        </div>
      </div>

      <div className={`bg-white rounded-3xl p-8 shadow-2xl border-b-8 transition-all duration-300 ${
        isSubmitted 
          ? (isCorrect ? 'border-green-500 shadow-green-100' : 'border-red-500 shadow-red-100') 
          : 'border-blue-500'
      }`}>
        <div className="text-center mb-8">
          <span className="inline-block px-3 py-1 bg-blue-100 text-blue-700 rounded-full text-xs font-bold uppercase tracking-wider mb-2">
            Kategorie: {question.category}
          </span>
          <h2 className="text-4xl font-black text-gray-800 flex items-center justify-center gap-3">
            {question.singular}
            <ArrowRight className="text-blue-400 w-8 h-8" />
            <span className="text-blue-600">?</span>
          </h2>
          <p className="text-gray-500 mt-2 italic text-lg">Napište množné číslo</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="relative">
            <input
              ref={inputRef}
              type="text"
              value={answer}
              onChange={(e) => setAnswer(e.target.value)}
              disabled={isSubmitted}
              placeholder="Zadejte plurál..."
              autoComplete="off"
              className={`w-full text-2xl font-bold py-4 px-6 rounded-2xl border-4 text-center transition-all focus:outline-none focus:ring-4 focus:ring-blue-100 ${
                isSubmitted 
                  ? (isCorrect ? 'border-green-200 bg-green-50 text-green-700' : 'border-red-200 bg-red-50 text-red-700') 
                  : 'border-gray-100 focus:border-blue-400'
              }`}
            />
            {isSubmitted && (
              <div className="absolute right-4 top-1/2 -translate-y-1/2">
                {isCorrect ? (
                  <CheckCircle className="text-green-500 w-8 h-8" />
                ) : (
                  <XCircle className="text-red-500 w-8 h-8" />
                )}
              </div>
            )}
          </div>

          {!isSubmitted ? (
            <button
              type="submit"
              disabled={!answer.trim()}
              className="w-full bg-blue-600 hover:bg-blue-700 disabled:bg-gray-300 text-white font-bold py-4 rounded-2xl shadow-lg transition-all transform hover:-translate-y-1 active:scale-95 flex items-center justify-center gap-2"
            >
              Zkontrolovat
              <Sparkles className="w-5 h-5" />
            </button>
          ) : (
            <div className="space-y-4 pt-4 border-t border-gray-100">
              <div className="flex flex-col gap-4">
                {!isCorrect && (
                  <div className="bg-red-50 p-4 rounded-xl border border-red-100">
                    <p className="text-red-800 font-bold mb-1">Správně je:</p>
                    <p className="text-2xl font-black text-red-600">{question.plural}</p>
                  </div>
                )}
                
                {showExplanation && (
                  <div className="bg-blue-50 p-4 rounded-xl border border-blue-100 text-blue-800 animate-in fade-in slide-in-from-bottom-2 duration-300">
                    <p className="font-bold flex items-center gap-2 mb-1 text-sm">
                      <Info className="w-4 h-4" /> Pravidlo:
                    </p>
                    <p className="text-sm leading-relaxed">{question.explanation}</p>
                  </div>
                )}

                <button
                  type="button"
                  onClick={handleNext}
                  className="w-full bg-gray-800 hover:bg-gray-900 text-white font-bold py-4 rounded-2xl shadow-lg transition-all flex items-center justify-center gap-2"
                >
                  Další otázka
                  <ArrowRight className="w-5 h-5" />
                </button>
              </div>
            </div>
          )}
        </form>
      </div>
    </div>
  );
};
