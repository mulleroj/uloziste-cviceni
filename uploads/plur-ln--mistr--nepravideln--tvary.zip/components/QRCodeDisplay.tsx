
import React from 'react';
import { QRCodeSVG } from 'qrcode.react';

export const QRCodeDisplay: React.FC = () => {
  const currentUrl = window.location.href;

  return (
    <div className="flex flex-col items-center justify-center p-8 bg-white rounded-2xl shadow-xl border border-blue-100">
      <h2 className="text-2xl font-bold mb-4 text-blue-900">Připojte se ke cvičení</h2>
      <div className="bg-white p-4 rounded-lg shadow-inner">
        <QRCodeSVG value={currentUrl} size={200} />
      </div>
      <p className="mt-4 text-gray-600 text-center max-w-xs">
        Naskenujte kód telefonem nebo tabletem a začněte s procvičováním 50 nepravidelných plurálů.
      </p>
      <div className="mt-4 p-2 bg-blue-50 rounded text-blue-700 text-xs font-mono break-all max-w-[200px]">
        {currentUrl}
      </div>
    </div>
  );
};
