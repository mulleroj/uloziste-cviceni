
import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export async function getExplanation(singular: string, correctPlural: string, userPlural: string): Promise<string> {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `User is learning English plurals. 
      Singular word: ${singular}
      Correct plural: ${correctPlural}
      User's wrong answer: ${userPlural}
      
      Explain in Czech why the plural is "${correctPlural}". Keep it short and encouraging (max 3 sentences).`,
      config: {
        temperature: 0.7,
      }
    });
    return response.text || "Vysvětlení se nepodařilo načíst.";
  } catch (error) {
    console.error("Gemini API error:", error);
    return "Omlouváme se, vysvětlení momentálně není k dispozici.";
  }
}
