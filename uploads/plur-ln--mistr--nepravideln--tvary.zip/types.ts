
export interface Question {
  id: number;
  singular: string;
  plural: string;
  category: 'human' | 'animal' | 'latin/greek' | 'f-ending' | 'unchanging';
  explanation: string;
}

export interface UserAnswer {
  questionId: number;
  answer: string;
  isCorrect: boolean;
}

export type AppView = 'start' | 'quiz' | 'results';
