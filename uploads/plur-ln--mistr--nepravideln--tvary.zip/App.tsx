
import React, { useState, useCallback } from 'react';
import { PLURAL_QUESTIONS } from './constants';
import { AppView, UserAnswer, Question } from './types';
import { QRCodeDisplay } from './components/QRCodeDisplay';
import { ExerciseCard } from './components/ExerciseCard';
import { Trophy, RefreshCw, BookOpen, GraduationCap, PlayCircle, Star } from 'lucide-react';

const App: React.FC = () => {
  const [view, setView] = useState<AppView>('start');
  const [currentIndex, setCurrentIndex] = useState(0);
  const [userAnswers, setUserAnswers] = useState<UserAnswer[]>([]);
  const [shuffledQuestions, setShuffledQuestions] = useState<Question[]>([...PLURAL_QUESTIONS]);

  // Funkce pro náhodné zamíchání pole (Fisher-Yates shuffle)
  const shuffleArray = <T,>(array: T[]): T[] => {
    const shuffled = [...array];
    for (let i = shuffled.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
    }
    return shuffled;
  };

  const startQuiz = useCallback(() => {
    // Při každém spuštění vygenerujeme zcela nové pořadí
    const newShuffled = shuffleArray(PLURAL_QUESTIONS);
    setShuffledQuestions(newShuffled);
    setUserAnswers([]);
    setCurrentIndex(0);
    setView('quiz');
  }, []);

  const handleNext = (isCorrect: boolean, answer: string) => {
    const newAnswer: UserAnswer = {
      questionId: shuffledQuestions[currentIndex].id,
      answer,
      isCorrect,
    };
    setUserAnswers(prev => [...prev, newAnswer]);

    if (currentIndex < shuffledQuestions.length - 1) {
      setCurrentIndex(prev => prev + 1);
    } else {
      setView('results');
    }
  };

  const score = userAnswers.filter(a => a.isCorrect).length;
  const percentage = Math.round((score / PLURAL_QUESTIONS.length) * 100);

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col items-center py-12 px-4">
      {/* Header */}
      <header className="mb-12 text-center">
        <div className="flex items-center justify-center gap-3 mb-2">
          <div className="p-3 bg-blue-600 rounded-2xl shadow-lg shadow-blue-200">
            <GraduationCap className="text-white w-8 h-8" />
          </div>
          <h1 className="text-4xl font-black text-slate-800 tracking-tight">
            Plurální<span className="text-blue-600">Mistr</span>
          </h1>
        </div>
        <p className="text-slate-500 font-medium">Ovládněte 50 nejdůležitějších nepravidelných plurálů</p>
      </header>

      <main className="w-full max-w-4xl flex flex-col items-center">
        {view === 'start' && (
          <div className="grid md:grid-cols-2 gap-8 items-center w-full">
            <div className="space-y-6">
              <div className="bg-white p-8 rounded-3xl shadow-xl border border-slate-100">
                <h2 className="text-2xl font-bold text-slate-800 mb-4">Vítejte ve cvičení!</h2>
                <p className="text-slate-600 mb-6 leading-relaxed">
                  Dnes vás čeká 50 nejčastějších nepravidelných podstatných jmen v angličtině. 
                  Pořadí otázek se při každém spuštění mění, abyste se je naučili opravdu do hloubky.
                </p>
                <div className="space-y-3">
                  <div className="flex items-start gap-3 text-sm text-slate-600">
                    <div className="w-6 h-6 rounded-full bg-blue-50 text-blue-600 flex items-center justify-center font-bold flex-shrink-0">1</div>
                    <p>Množné číslo pište bez členů (např. jen "men").</p>
                  </div>
                  <div className="flex items-start gap-3 text-sm text-slate-600">
                    <div className="w-6 h-6 rounded-full bg-blue-50 text-blue-600 flex items-center justify-center font-bold flex-shrink-0">2</div>
                    <p>U každé chyby se zobrazí stručné gramatické pravidlo.</p>
                  </div>
                  <div className="flex items-start gap-3 text-sm text-slate-600">
                    <div className="w-6 h-6 rounded-full bg-blue-50 text-blue-600 flex items-center justify-center font-bold flex-shrink-0">3</div>
                    <p>Při každém "Zkusit znovu" se otázky znovu zamíchají.</p>
                  </div>
                </div>
                <button 
                  onClick={startQuiz}
                  className="w-full mt-8 bg-blue-600 hover:bg-blue-700 text-white font-black py-5 rounded-2xl shadow-xl shadow-blue-100 transition-all transform hover:-translate-y-1 active:scale-95 flex items-center justify-center gap-3 text-xl"
                >
                  <PlayCircle className="w-6 h-6" />
                  Spustit cvičení
                </button>
              </div>
            </div>
            <QRCodeDisplay />
          </div>
        )}

        {view === 'quiz' && (
          <ExerciseCard 
            question={shuffledQuestions[currentIndex]}
            index={currentIndex}
            total={shuffledQuestions.length}
            onNext={handleNext}
          />
        )}

        {view === 'results' && (
          <div className="w-full max-w-2xl bg-white rounded-3xl p-10 shadow-2xl border border-slate-100 text-center">
            <div className="w-24 h-24 bg-yellow-100 rounded-full flex items-center justify-center mx-auto mb-6">
              <Trophy className="text-yellow-500 w-12 h-12" />
            </div>
            <h2 className="text-3xl font-black text-slate-800 mb-2">Skvělý výkon!</h2>
            <p className="text-slate-500 mb-8">Dokončili jste všech 50 příkladů.</p>
            
            <div className="grid grid-cols-2 gap-4 mb-10">
              <div className="p-6 bg-blue-50 rounded-2xl border border-blue-100">
                <p className="text-blue-600 text-sm font-bold uppercase mb-1">Skóre</p>
                <p className="text-4xl font-black text-blue-900">{score} / 50</p>
              </div>
              <div className="p-6 bg-purple-50 rounded-2xl border border-purple-100">
                <p className="text-purple-600 text-sm font-bold uppercase mb-1">Úspěšnost</p>
                <p className="text-4xl font-black text-purple-900">{percentage}%</p>
              </div>
            </div>

            <div className="space-y-4">
              <button 
                onClick={startQuiz}
                className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-4 rounded-2xl shadow-lg transition-all flex items-center justify-center gap-2"
              >
                <RefreshCw className="w-5 h-5" />
                Zkusit znovu (nové pořadí)
              </button>
              <button 
                onClick={() => setView('start')}
                className="w-full bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold py-4 rounded-2xl transition-all flex items-center justify-center gap-2"
              >
                <BookOpen className="w-5 h-5" />
                Zpět na úvod
              </button>
            </div>

            {userAnswers.some(a => !a.isCorrect) && (
              <div className="mt-12 text-left">
                <h3 className="text-xl font-bold text-slate-800 mb-4 flex items-center gap-2">
                  <Star className="text-yellow-500 w-5 h-5" />
                  Kde jste chybovali:
                </h3>
                <div className="space-y-2 max-h-60 overflow-y-auto pr-2 custom-scrollbar">
                  {userAnswers.filter(a => !a.isCorrect).map((ans, i) => {
                    const q = PLURAL_QUESTIONS.find(pq => pq.id === ans.questionId);
                    return (
                      <div key={i} className="flex justify-between items-center p-3 bg-red-50 rounded-xl border border-red-100 text-sm">
                        <div>
                          <span className="font-bold text-slate-700">{q?.singular}</span>
                          <span className="mx-2 text-slate-400">→</span>
                          <span className="text-red-600 line-through mr-2">{ans.answer}</span>
                          <span className="text-green-600 font-bold">{q?.plural}</span>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}
          </div>
        )}
      </main>

      {/* Footer Decoration */}
      <footer className="mt-auto pt-12 text-slate-400 text-sm flex items-center gap-2">
        Kompletní offline verze s náhodným řazením <div className="w-1 h-1 bg-slate-300 rounded-full"></div> 2026
      </footer>

      <style>{`
        .custom-scrollbar::-webkit-scrollbar {
          width: 6px;
        }
        .custom-scrollbar::-webkit-scrollbar-track {
          background: #f1f5f9;
          border-radius: 10px;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb {
          background: #cbd5e1;
          border-radius: 10px;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb:hover {
          background: #94a3b8;
        }
      `}</style>
    </div>
  );
};

export default App;
