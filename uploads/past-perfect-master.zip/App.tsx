
import React, { useState, useEffect, useCallback } from 'react';
import { 
  Trophy, History, RefreshCw, Share2, Lightbulb, 
  BrainCircuit, BookOpen, Clock, X, ChevronRight, CheckCircle2, AlertCircle,
  QrCode
} from 'lucide-react';
import { SENTENCE_BANK } from './constants';
import { Sentence, Attempt, QuizState } from './types';
import Quiz from './components/Quiz';
import HistoryTable from './components/History';
import ShareModal from './components/ShareModal';

const App: React.FC = () => {
  const [quizState, setQuizState] = useState<QuizState>({
    questions: [],
    answers: {},
    isSubmitted: false,
    score: 0
  });
  const [history, setHistory] = useState<Attempt[]>([]);
  const [showShareModal, setShowShareModal] = useState(false);
  const [isHistoryLoading, setIsHistoryLoading] = useState(true);

  // Fisher-Yates Shuffle pro skutečnou náhodnost
  const shuffleSentences = (array: Sentence[]) => {
    const shuffled = [...array];
    for (let i = shuffled.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
    }
    return shuffled;
  };

  // Inicializace kvízu s 10 náhodnými větami z 50členné banky
  const startNewQuiz = useCallback(() => {
    const shuffledPool = shuffleSentences(SENTENCE_BANK);
    setQuizState({
      questions: shuffledPool.slice(0, 10),
      answers: {},
      isSubmitted: false,
      score: 0
    });
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, []);

  // Načtení historie z LocalStorage
  useEffect(() => {
    const saved = localStorage.getItem('past-perfect-history');
    if (saved) {
      try {
        setHistory(JSON.parse(saved));
      } catch (e) {
        console.error("Nepodařilo se načíst historii", e);
        setHistory([]);
      }
    }
    setIsHistoryLoading(false);
    startNewQuiz();
  }, [startNewQuiz]);

  const saveAttempt = (score: number) => {
    const newAttempt: Attempt = {
      id: Math.random().toString(36).substr(2, 6).toUpperCase(),
      score,
      total: 10,
      timestamp: Date.now(),
      dateStr: new Date().toLocaleString('cs-CZ', {
        day: 'numeric', month: 'numeric', hour: '2-digit', minute: '2-digit'
      })
    };
    const updatedHistory = [newAttempt, ...history].slice(0, 15);
    setHistory(updatedHistory);
    localStorage.setItem('past-perfect-history', JSON.stringify(updatedHistory));
  };

  const handleAnswerChange = (id: number, value: string) => {
    setQuizState(prev => ({
      ...prev,
      answers: { ...prev.answers, [id]: value }
    }));
  };

  const handleSubmit = () => {
    let score = 0;
    quizState.questions.forEach(q => {
      if ((quizState.answers[q.id] || "").trim().toLowerCase() === q.answer.toLowerCase()) {
        score++;
      }
    });
    setQuizState(prev => ({ ...prev, score, isSubmitted: true }));
    saveAttempt(score);
  };

  return (
    <div className="min-h-screen pb-20 selection:bg-indigo-100">
      {/* Navigace */}
      <nav className="sticky top-0 z-40 bg-white/80 backdrop-blur-md border-b border-slate-200">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="bg-indigo-600 p-2 rounded-xl shadow-indigo-200 shadow-lg">
              <BrainCircuit className="text-white" size={24} />
            </div>
            <div className="flex items-center gap-2">
              <h1 className="text-xl font-extrabold text-slate-800 tracking-tight hidden sm:block">
                PAST PERFECT <span className="text-indigo-600">MASTER</span>
              </h1>
              <button 
                onClick={() => setShowShareModal(true)}
                className="flex items-center gap-1.5 px-2 py-1 rounded-lg bg-slate-100 hover:bg-indigo-100 text-slate-500 hover:text-indigo-600 transition-all active:scale-95 border border-slate-200 hover:border-indigo-200 group"
                title="Zobrazit QR kód"
              >
                <QrCode size={16} className="group-hover:rotate-12 transition-transform" />
                <span className="text-[10px] font-bold uppercase tracking-wider hidden xs:block">QR Kód</span>
              </button>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button 
              onClick={() => setShowShareModal(true)}
              className="p-2.5 rounded-xl hover:bg-slate-100 text-slate-600 transition-all active:scale-95"
              title="Sdílet aplikaci"
            >
              <Share2 size={20} />
            </button>
            <button 
              onClick={startNewQuiz}
              className="flex items-center gap-2 bg-slate-800 hover:bg-slate-900 text-white px-4 py-2.5 rounded-xl font-semibold text-sm transition-all active:scale-95 shadow-sm"
            >
              <RefreshCw size={18} />
              <span className="hidden xs:inline">Nová sada</span>
            </button>
          </div>
        </div>
      </nav>

      {/* Hero sekce */}
      <div className="max-w-5xl mx-auto px-4 sm:px-6 pt-10 pb-6">
        <div className="bg-gradient-to-br from-indigo-700 to-indigo-900 rounded-[2.5rem] p-8 sm:p-12 text-white shadow-2xl relative overflow-hidden">
          <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-8">
            <div className="max-w-lg">
              <div className="inline-flex items-center gap-2 bg-indigo-500/30 border border-indigo-400/30 px-3 py-1 rounded-full text-xs font-bold uppercase tracking-widest mb-4">
                <BookOpen size={14} />
                Banka 50 vět
              </div>
              <h2 className="text-4xl sm:text-5xl font-black mb-4 leading-tight">
                Ovládněte čas <br/>předminulý.
              </h2>
              <p className="text-indigo-100 text-lg opacity-90 leading-relaxed">
                Procvičujte si gramatiku bezpečně a offline. Pokaždé získáte 10 náhodných vět k doplnění.
              </p>
            </div>
            
            <div className="flex flex-col gap-3">
              <div className="bg-white/10 backdrop-blur-lg border border-white/20 p-5 rounded-3xl flex items-center gap-4 min-w-[200px]">
                <div className="bg-white/20 p-3 rounded-2xl">
                  <Trophy className="text-yellow-300" size={32} />
                </div>
                <div>
                  <div className="text-xs uppercase font-bold tracking-wider text-indigo-200">Tvůj rekord</div>
                  <div className="text-2xl font-black">{history.length > 0 ? Math.max(...history.map(h => h.score)) : 0} / 10</div>
                </div>
              </div>
            </div>
          </div>
          
          <div className="absolute top-0 right-0 w-64 h-64 bg-indigo-500/20 rounded-full blur-[100px] -translate-y-1/2 translate-x-1/2"></div>
          <div className="absolute bottom-0 left-0 w-48 h-48 bg-purple-500/20 rounded-full blur-[80px] translate-y-1/2 -translate-x-1/2"></div>
        </div>
      </div>

      {/* Hlavní mřížka */}
      <main className="max-w-5xl mx-auto px-4 sm:px-6 grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-8">
          <div className="bg-amber-50 border border-amber-200 p-5 rounded-3xl flex gap-4 items-start shadow-sm">
            <div className="bg-amber-100 p-2 rounded-xl text-amber-600 mt-0.5">
              <Lightbulb size={20} />
            </div>
            <div>
              <h4 className="font-bold text-amber-900 mb-1">Rychlé pravidlo</h4>
              <p className="text-sm text-amber-800 leading-relaxed">
                Past Perfect (had + 3. tvar slovesa) používáme pro děj, který se stal <strong>před</strong> jiným dějem v minulosti.
                Příklad: <span className="font-mono bg-white/50 px-1 rounded italic text-amber-700">"The movie had started before we arrived."</span>
              </p>
            </div>
          </div>

          <Quiz 
            state={quizState} 
            onAnswerChange={handleAnswerChange}
            onSubmit={handleSubmit}
            onReset={startNewQuiz}
          />
        </div>

        {/* Boční panel s historií */}
        <div className="space-y-6">
          <div className="lg:sticky lg:top-24">
            <div className="bg-white border border-slate-200 rounded-[2rem] p-6 shadow-sm">
              <div className="flex items-center justify-between mb-6">
                <h3 className="font-bold text-slate-800 flex items-center gap-2">
                  <History size={20} className="text-slate-400" />
                  Historie pokusů
                </h3>
              </div>
              
              <HistoryTable 
                history={history} 
                isLoading={isHistoryLoading} 
              />

              {history.length > 0 && (
                <button 
                  onClick={() => {
                    if(confirm('Opravdu chcete smazat celou historii?')) {
                      localStorage.removeItem('past-perfect-history');
                      setHistory([]);
                    }
                  }}
                  className="w-full mt-6 py-2 text-xs font-bold text-slate-400 hover:text-red-500 transition-colors uppercase tracking-widest"
                >
                  Smazat historii
                </button>
              )}
            </div>

            <div className="mt-6 bg-slate-100 rounded-[2rem] p-6 border border-slate-200 relative overflow-hidden group">
              <div className="relative z-10">
                <div className="bg-white p-2 rounded-xl w-fit mb-4 shadow-sm">
                  <BookOpen className="text-indigo-600" size={24} />
                </div>
                <h4 className="font-bold text-slate-800 mb-2">Jak se učit?</h4>
                <p className="text-sm text-slate-500 leading-relaxed">
                  Zkuste si každou větu přeložit. Vždy se ptejte: „Který děj se stal dříve?“ Ten bude v předminulém čase.
                </p>
              </div>
            </div>
          </div>
        </div>
      </main>

      {showShareModal && (
        <ShareModal onClose={() => setShowShareModal(false)} />
      )}
    </div>
  );
};

export default App;
