
import { GoogleGenAI } from "@google/genai";

export const getGrammarExplanation = async (sentence: string, userAnswer: string, correctAnswer: string): Promise<string> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  const prompt = `
    Jako expert na anglickou gramatiku vysvětli stručně a jasně (v češtině), proč se v následující větě používá předminulý čas (Past Perfect).
    
    Věta: "${sentence}"
    Uživatel napsal: "${userAnswer}"
    Správná odpověď: "${correctAnswer}"
    
    Zaměř se na časovou posloupnost dějů. Vysvětlení by mělo mít maximálně 3-4 věty.
  `;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt,
      config: {
        temperature: 0.7,
        topP: 0.8,
      }
    });
    
    return response.text || "Omlouváme se, vysvětlení se nepodařilo vygenerovat.";
  } catch (error) {
    console.error("Gemini Error:", error);
    return "Nepodařilo se spojit s AI tutorem. Zkontrolujte připojení k internetu.";
  }
};
