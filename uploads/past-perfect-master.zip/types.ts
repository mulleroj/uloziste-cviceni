
export interface Sentence {
  id: number;
  base: string;
  answer: string;
  difficulty?: 'easy' | 'medium' | 'hard';
}

export interface Attempt {
  id: string;
  score: number;
  total: number;
  timestamp: number;
  dateStr: string;
}

export interface QuizState {
  questions: Sentence[];
  answers: Record<number, string>;
  isSubmitted: boolean;
  score: number;
}
