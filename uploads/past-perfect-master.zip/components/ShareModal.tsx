
import React, { useState } from 'react';
import { X, Copy, CheckCircle2, QrCode } from 'lucide-react';

interface ShareModalProps {
  onClose: () => void;
}

const ShareModal: React.FC<ShareModalProps> = ({ onClose }) => {
  const [copied, setCopied] = useState(false);
  const currentUrl = window.location.href;

  const handleCopy = () => {
    navigator.clipboard.writeText(currentUrl);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center p-4">
      {/* Backdrop */}
      <div 
        className="absolute inset-0 bg-slate-900/60 backdrop-blur-md animate-in fade-in duration-300"
        onClick={onClose}
      />
      
      {/* Modal */}
      <div className="relative bg-white rounded-[2.5rem] p-8 max-w-sm w-full shadow-2xl animate-in zoom-in-95 slide-in-from-bottom-4 duration-300">
        <button 
          onClick={onClose}
          className="absolute top-6 right-6 p-2 rounded-full hover:bg-slate-100 text-slate-400 transition-colors"
        >
          <X size={20} />
        </button>

        <div className="flex flex-col items-center text-center">
          <div className="w-16 h-16 bg-indigo-100 text-indigo-600 rounded-3xl flex items-center justify-center mb-6 shadow-indigo-50 shadow-lg">
            <QrCode size={32} />
          </div>
          
          <h3 className="text-2xl font-black text-slate-800 mb-2">Sdílet výuku</h3>
          <p className="text-slate-500 text-sm mb-8 leading-relaxed">
            Naskenujte QR kód nebo zkopírujte odkaz a sdílejte aplikaci s přáteli.
          </p>

          <div className="bg-slate-50 p-6 rounded-[2rem] mb-8 border border-slate-100 shadow-inner">
            <img 
              src={`https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=${encodeURIComponent(currentUrl)}`} 
              alt="QR Code"
              className="w-40 h-40 rounded-xl"
            />
          </div>

          <div className="w-full space-y-3">
            <button
              onClick={handleCopy}
              className={`w-full py-4 px-6 rounded-2xl font-bold transition-all flex items-center justify-center gap-3 shadow-lg active:scale-95
                ${copied 
                  ? 'bg-green-500 text-white shadow-green-100' 
                  : 'bg-indigo-600 text-white shadow-indigo-100 hover:bg-indigo-700'
                }`}
            >
              {copied ? <CheckCircle2 size={20} /> : <Copy size={20} />}
              {copied ? 'Zkopírováno!' : 'Kopírovat odkaz'}
            </button>
            <button 
              onClick={onClose}
              className="w-full py-4 px-6 rounded-2xl font-bold bg-slate-100 text-slate-600 hover:bg-slate-200 transition-all active:scale-95"
            >
              Zavřít
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ShareModal;
