
import React from 'react';
import { Clock, Loader2 } from 'lucide-react';
import { Attempt } from '../types';

interface HistoryProps {
  history: Attempt[];
  isLoading: boolean;
}

const HistoryTable: React.FC<HistoryProps> = ({ history, isLoading }) => {
  if (isLoading) {
    return (
      <div className="flex flex-col items-center justify-center py-12 gap-3 text-slate-400">
        <Loader2 className="animate-spin" size={32} />
        <p className="text-sm font-medium">Načítání historie...</p>
      </div>
    );
  }

  if (history.length === 0) {
    return (
      <div className="text-center py-12 bg-slate-50 rounded-[1.5rem] border-2 border-dashed border-slate-100 px-4">
        <p className="text-slate-400 text-sm leading-relaxed">
          Zatím zde nejsou žádné pokusy. <br/>Dokončete první cvičení!
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-3">
      {history.map((attempt) => (
        <div key={attempt.id} className="flex items-center justify-between p-4 bg-slate-50/50 hover:bg-white hover:shadow-md transition-all rounded-2xl border border-slate-100 group">
          <div className="flex flex-col gap-1">
            <div className="flex items-center gap-2 text-[10px] font-bold text-slate-400 group-hover:text-indigo-500 transition-colors uppercase tracking-wider">
              <Clock size={12} />
              {attempt.dateStr}
            </div>
            <div className="text-sm font-bold text-slate-700">Pokus č. {attempt.id.substr(0, 4)}</div>
          </div>
          <div className={`px-4 py-2 rounded-xl text-sm font-black shadow-sm ${
            attempt.score >= 8 
              ? 'bg-green-100 text-green-700' 
              : attempt.score >= 5 
                ? 'bg-indigo-100 text-indigo-700' 
                : 'bg-slate-100 text-slate-500'
          }`}>
            {attempt.score}/{attempt.total}
          </div>
        </div>
      ))}
    </div>
  );
};

export default HistoryTable;
