
import React from 'react';
import { 
  CheckCircle2, AlertCircle, RefreshCw, ChevronRight, Trophy
} from 'lucide-react';
import { Sentence, QuizState } from '../types';

interface QuizProps {
  state: QuizState;
  onAnswerChange: (id: number, value: string) => void;
  onSubmit: () => void;
  onReset: () => void;
}

const Quiz: React.FC<QuizProps> = ({ state, onAnswerChange, onSubmit, onReset }) => {
  const renderQuestion = (q: Sentence, index: number) => {
    const parts = q.base.split(/\((.*?)\)/);
    const userAnswer = (state.answers[q.id] || "").trim().toLowerCase();
    const isCorrect = userAnswer === q.answer.toLowerCase();
    
    return (
      <div key={q.id} className="group animate-in fade-in slide-in-from-bottom-2 duration-300">
        <div className={`p-6 sm:p-8 rounded-[2rem] border transition-all duration-300 ${
          !state.isSubmitted 
            ? "bg-white border-slate-200 hover:border-indigo-300 hover:shadow-xl hover:shadow-indigo-50/50" 
            : isCorrect
              ? "bg-green-50/50 border-green-200"
              : "bg-red-50/50 border-red-200"
        }`}>
          <div className="flex flex-col sm:flex-row gap-6">
            <div className={`w-10 h-10 rounded-2xl flex items-center justify-center font-bold text-sm shrink-0 shadow-sm ${
              !state.isSubmitted
                ? "bg-slate-100 text-slate-500"
                : isCorrect ? "bg-green-500 text-white" : "bg-red-500 text-white"
            }`}>
              {index + 1}
            </div>
            
            <div className="flex-grow space-y-4">
              <div className="text-lg sm:text-xl text-slate-800 leading-relaxed font-medium">
                {parts[0]}
                <input
                  type="text"
                  value={state.answers[q.id] || ""}
                  onChange={(e) => onAnswerChange(q.id, e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && !state.isSubmitted && onSubmit()}
                  disabled={state.isSubmitted}
                  placeholder={`(${parts[1]})`}
                  className={`mx-2 px-4 py-1.5 border-b-2 rounded-t-xl transition-all duration-300 outline-none w-full sm:w-auto min-w-[180px] text-center
                    ${!state.isSubmitted 
                      ? "border-slate-300 focus:border-indigo-600 bg-slate-50 focus:bg-white focus:shadow-inner" 
                      : isCorrect
                          ? "border-green-500 bg-white text-green-700 font-bold"
                          : "border-red-500 bg-white text-red-700 font-bold"
                    }
                  `}
                />
                {parts[2]}
              </div>

              {state.isSubmitted && !isCorrect && (
                <div className="flex flex-col gap-2 animate-in slide-in-from-top-1 duration-200">
                  <div className="flex items-center gap-3 text-red-600 font-semibold text-sm">
                    <AlertCircle size={18} />
                    Správná odpověď: <span className="bg-red-100 px-2 py-0.5 rounded-lg underline decoration-2 underline-offset-4 font-bold">{q.answer}</span>
                  </div>
                  <div className="text-xs text-slate-500 italic ml-7">
                    Tip: V předminulém čase vždy používáme "had" + příčestí minulé.
                  </div>
                </div>
              )}

              {state.isSubmitted && isCorrect && (
                <div className="flex items-center gap-2 text-green-600 font-semibold text-sm animate-in zoom-in-95">
                  <CheckCircle2 size={18} />
                  Správně!
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className="space-y-6 pb-12">
      <div className="space-y-6">
        {state.questions.map((q, idx) => renderQuestion(q, idx))}
      </div>

      <div className="p-8 bg-white border border-slate-200 rounded-[2.5rem] shadow-sm flex flex-col sm:flex-row items-center justify-between gap-6">
        {!state.isSubmitted ? (
          <>
            <div className="flex items-center gap-4 text-slate-400 italic text-sm">
              <ChevronRight size={18} className="text-indigo-300" />
              Zkontrolujte si překlepy
            </div>
            <button
              onClick={onSubmit}
              className="w-full sm:w-auto bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-4 px-12 rounded-2xl shadow-xl shadow-indigo-100 transition-all hover:-translate-y-1 active:scale-95 flex items-center justify-center gap-3"
            >
              <CheckCircle2 size={20} />
              Zkontrolovat výsledky
            </button>
          </>
        ) : (
          <div className="w-full flex flex-col sm:flex-row items-center justify-between gap-6">
            <div className="flex items-center gap-5 bg-indigo-50 px-6 py-4 rounded-3xl border border-indigo-100 shadow-sm w-full sm:w-auto">
              <div className={`p-3 rounded-2xl ${state.score >= 8 ? 'bg-yellow-100 text-yellow-600' : 'bg-indigo-200 text-indigo-600'}`}>
                <Trophy size={28} />
              </div>
              <div>
                <div className="text-[10px] text-indigo-400 font-bold uppercase tracking-[0.2em]">Dosažené skóre</div>
                <div className="text-3xl font-black text-slate-800 leading-none">
                  {state.score} <span className="text-indigo-200">/ 10</span>
                </div>
              </div>
            </div>
            
            <button
              onClick={onReset}
              className="w-full sm:w-auto bg-slate-800 hover:bg-slate-900 text-white font-bold py-4 px-10 rounded-2xl transition-all flex items-center justify-center gap-3 shadow-lg active:scale-95"
            >
              <RefreshCw size={20} />
              Další sada 10 vět
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default Quiz;
